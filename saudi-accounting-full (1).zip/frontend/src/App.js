import React, { useEffect } from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate, useParams } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useAuth } from "./contexts/AuthContext";

// Pages
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import ChartOfAccounts from "./pages/ChartOfAccounts";
import OpeningBalances from "./pages/OpeningBalances";
import Customers from "./pages/Customers";
import Invoices from "./pages/Invoices";
import JournalEntries from "./pages/JournalEntries";
import EasyEntries from "./pages/EasyEntries";
import ReceiptVouchers from "./pages/ReceiptVouchers";
import PaymentVouchers from "./pages/PaymentVouchers";
import Reports from "./pages/Reports";
import FinancialStatements from "./pages/FinancialStatements";
import Settings from "./pages/Settings";
import OwnerPanel from "./pages/OwnerPanel";
import TenantLogin from "./pages/TenantLogin";
import CostCenters from "./pages/CostCenters";
import Projects from "./pages/Projects";
import QuarterlyReports from "./pages/QuarterlyReports";

// Layout
import Layout from "./components/Layout";
import TenantLayout from "./components/TenantLayout";

// Tenant Protected Route Component
function TenantProtectedRoute({ children }) {
  const { isAuthenticated, tenantId } = useAuth();
  const { tenantId: urlTenantId } = useParams();
  
  // Check if user is authenticated and tenant ID matches
  if (!isAuthenticated || !tenantId) {
    return <Navigate to={`/tenant/${urlTenantId}`} replace />;
  }
  
  return children;
}

function App() {
  const { i18n } = useTranslation();
  const { isAuthenticated, loading } = useAuth();

  useEffect(() => {
    // Set document direction based on language
    document.documentElement.dir = i18n.language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = i18n.language;
  }, [i18n.language]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          {/* Owner Panel - Separate from main app */}
          <Route path="/owner" element={<OwnerPanel />} />
          
          {/* Tenant Login */}
          <Route path="/tenant/:tenantId" element={<TenantLogin />} />
          
          {/* Tenant Protected Routes - Full Dashboard Copy */}
          <Route path="/tenant/:tenantId/*" element={
            <TenantProtectedRoute>
              <TenantLayout />
            </TenantProtectedRoute>
          }>
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="chart-of-accounts" element={<ChartOfAccounts />} />
            <Route path="opening-balances" element={<OpeningBalances />} />
            <Route path="customers" element={<Customers />} />
            <Route path="invoices" element={<Invoices />} />
            <Route path="journal-entries" element={<JournalEntries />} />
            <Route path="easy-entries" element={<EasyEntries />} />
            <Route path="receipt-vouchers" element={<ReceiptVouchers />} />
            <Route path="payment-vouchers" element={<PaymentVouchers />} />
            <Route path="reports" element={<Reports />} />
            <Route path="financial-statements" element={<FinancialStatements />} />
            <Route path="quarterly-reports" element={<QuarterlyReports />} />
            <Route path="cost-centers" element={<CostCenters />} />
            <Route path="projects" element={<Projects />} />
            <Route path="settings" element={<Settings />} />
          </Route>
          
          {/* Main App Routes */}
          <Route path="/" element={isAuthenticated ? <Navigate to="/dashboard" /> : <Login />} />
          <Route path="/login" element={isAuthenticated ? <Navigate to="/dashboard" /> : <Login />} />
          
          {/* Protected Routes for Main App (Admin) */}
          <Route element={isAuthenticated ? <Layout /> : <Navigate to="/login" />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/chart-of-accounts" element={<ChartOfAccounts />} />
            <Route path="/opening-balances" element={<OpeningBalances />} />
            <Route path="/customers" element={<Customers />} />
            <Route path="/invoices" element={<Invoices />} />
            <Route path="/journal-entries" element={<JournalEntries />} />
            <Route path="/easy-entries" element={<EasyEntries />} />
            <Route path="/receipt-vouchers" element={<ReceiptVouchers />} />
            <Route path="/payment-vouchers" element={<PaymentVouchers />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/financial-statements" element={<FinancialStatements />} />
            <Route path="/quarterly-reports" element={<QuarterlyReports />} />
            <Route path="/cost-centers" element={<CostCenters />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/settings" element={<Settings />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
