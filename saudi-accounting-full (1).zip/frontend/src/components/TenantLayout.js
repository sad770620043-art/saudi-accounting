import React, { useState, useEffect } from 'react';
import { Outlet, Link, useNavigate, useLocation, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../contexts/AuthContext';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  LayoutDashboard, 
  BookOpen, 
  DollarSign, 
  Users, 
  FileText, 
  BookMarked, 
  Receipt, 
  CreditCard, 
  FileBarChart,
  Settings as SettingsIcon,
  LogOut,
  Menu,
  X,
  Globe,
  Zap,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Building2,
  FolderKanban,
  CalendarRange
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '../lib/utils';
import api from '../utils/api';

export default function TenantLayout() {
  const { t, i18n } = useTranslation();
  const { logout, user, tenantId, tenantInfo } = useAuth();
  const { tenantId: urlTenantId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [expandedMenus, setExpandedMenus] = useState(['accounting']);
  const [companySettings, setCompanySettings] = useState(null);
  const isRTL = i18n.language === 'ar';

  // Load company settings for this tenant
  useEffect(() => {
    loadCompanySettings();
  }, [tenantId, urlTenantId]);

  const loadCompanySettings = async () => {
    try {
      const res = await api.get('/company-settings');
      setCompanySettings(res.data);
    } catch (err) {
      console.error('Error loading company settings:', err);
    }
  };

  // Base path for tenant routes
  const basePath = `/tenant/${urlTenantId || tenantId}`;

  const menuSections = [
    {
      id: 'main',
      items: [
        { path: `${basePath}/dashboard`, label: 'لوحة التحكم', labelEn: 'Dashboard', icon: LayoutDashboard },
      ]
    },
    {
      id: 'accounting',
      label: 'المحاسبة',
      labelEn: 'Accounting',
      items: [
        { path: `${basePath}/easy-entries`, label: 'القيود السريعة', labelEn: 'Easy Entries', icon: Zap, highlight: true },
        { path: `${basePath}/journal-entries`, label: 'قيود اليومية', labelEn: 'Journal Entries', icon: BookMarked },
        { path: `${basePath}/chart-of-accounts`, label: 'دليل الحسابات', labelEn: 'Chart of Accounts', icon: BookOpen },
        { path: `${basePath}/opening-balances`, label: 'الأرصدة الافتتاحية', labelEn: 'Opening Balances', icon: DollarSign },
      ]
    },
    {
      id: 'sales',
      label: 'المبيعات',
      labelEn: 'Sales',
      items: [
        { path: `${basePath}/invoices`, label: 'الفواتير', labelEn: 'Invoices', icon: FileText },
        { path: `${basePath}/customers`, label: 'العملاء', labelEn: 'Customers', icon: Users },
      ]
    },
    {
      id: 'finance',
      label: 'الخزينة',
      labelEn: 'Treasury',
      items: [
        { path: `${basePath}/receipt-vouchers`, label: 'سندات القبض', labelEn: 'Receipt Vouchers', icon: Receipt },
        { path: `${basePath}/payment-vouchers`, label: 'سندات الصرف', labelEn: 'Payment Vouchers', icon: CreditCard },
      ]
    },
    {
      id: 'tracking',
      label: 'التتبع',
      labelEn: 'Tracking',
      items: [
        { path: `${basePath}/cost-centers`, label: 'مراكز التكلفة', labelEn: 'Cost Centers', icon: Building2 },
        { path: `${basePath}/projects`, label: 'المشاريع', labelEn: 'Projects', icon: FolderKanban },
      ]
    },
    {
      id: 'reports',
      label: 'التقارير',
      labelEn: 'Reports',
      items: [
        { path: `${basePath}/reports`, label: 'التقارير', labelEn: 'Reports', icon: FileBarChart },
        { path: `${basePath}/financial-statements`, label: 'القوائم المالية', labelEn: 'Financial Statements', icon: FileText },
        { path: `${basePath}/quarterly-reports`, label: 'التقارير الربعية', labelEn: 'Quarterly Reports', icon: CalendarRange },
        { path: `${basePath}/settings`, label: 'الإعدادات', labelEn: 'Settings', icon: SettingsIcon },
      ]
    }
  ];

  const handleLogout = () => {
    logout();
    toast.success('تم تسجيل الخروج بنجاح');
    navigate(`/tenant/${urlTenantId || tenantId}`);
  };

  const toggleLanguage = () => {
    const newLang = i18n.language === 'ar' ? 'en' : 'ar';
    i18n.changeLanguage(newLang);
    document.documentElement.dir = newLang === 'ar' ? 'rtl' : 'ltr';
  };

  const toggleMenu = (menuId) => {
    setExpandedMenus(prev => 
      prev.includes(menuId) 
        ? prev.filter(id => id !== menuId)
        : [...prev, menuId]
    );
  };

  const getLabel = (item) => i18n.language === 'ar' ? item.label : (item.labelEn || item.label);

  // Get company name from settings or tenant info
  const companyName = companySettings?.company_name_ar || tenantInfo?.company_name_ar || 'شركة';
  const companyNameEn = companySettings?.company_name_en || tenantInfo?.company_name_en || 'Company';

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Sidebar */}
      <aside
        className={cn(
          "bg-card border-e border-border transition-all duration-300 flex flex-col",
          sidebarOpen ? (sidebarCollapsed ? 'w-16' : 'w-64') : 'w-0 overflow-hidden'
        )}
        data-testid="tenant-sidebar"
      >
        {/* Logo */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-border">
          {!sidebarCollapsed && (
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald flex items-center justify-center">
                <Building2 className="w-5 h-5 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <h1 className="font-bold text-emerald text-sm truncate">{companyName}</h1>
                <p className="text-[10px] text-muted-foreground truncate">{companyNameEn}</p>
              </div>
            </div>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 flex-shrink-0"
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          >
            {isRTL ? (
              sidebarCollapsed ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />
            ) : (
              sidebarCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />
            )}
          </Button>
        </div>

        {/* Tenant Badge */}
        {!sidebarCollapsed && (
          <div className="px-4 py-2 border-b border-border">
            <Badge variant="outline" className="w-full justify-center text-xs">
              نسخة: {urlTenantId || tenantId}
            </Badge>
          </div>
        )}

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4">
          {menuSections.map((section) => (
            <div key={section.id} className="mb-2">
              {section.label && !sidebarCollapsed && (
                <button
                  onClick={() => toggleMenu(section.id)}
                  className="w-full flex items-center justify-between px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider hover:text-foreground"
                >
                  <span>{getLabel(section)}</span>
                  <ChevronDown className={cn(
                    "h-3 w-3 transition-transform",
                    expandedMenus.includes(section.id) && "rotate-180"
                  )} />
                </button>
              )}
              
              <div className={cn(
                "space-y-0.5 px-2",
                section.label && !expandedMenus.includes(section.id) && !sidebarCollapsed && "hidden"
              )}>
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = location.pathname === item.path;
                  
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      data-testid={`tenant-nav-${item.path.split('/').pop()}`}
                      className={cn(
                        "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200",
                        isActive 
                          ? "bg-emerald text-white shadow-sm" 
                          : "hover:bg-muted text-foreground",
                        item.highlight && !isActive && "bg-emerald/10 text-emerald font-medium",
                        sidebarCollapsed && "justify-center px-0"
                      )}
                      title={sidebarCollapsed ? getLabel(item) : undefined}
                    >
                      <Icon className={cn("h-5 w-5", item.highlight && !isActive && "text-emerald")} />
                      {!sidebarCollapsed && <span className="text-sm">{getLabel(item)}</span>}
                      {item.highlight && !sidebarCollapsed && !isActive && (
                        <span className="ms-auto text-[10px] bg-emerald text-white px-1.5 py-0.5 rounded">جديد</span>
                      )}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* Footer */}
        {!sidebarCollapsed && (
          <div className="p-3 border-t border-border space-y-2">
            <div className="flex items-center gap-2 px-2 py-2 rounded-lg bg-muted/50">
              <div className="w-8 h-8 rounded-full bg-emerald/20 flex items-center justify-center">
                <span className="text-emerald font-semibold text-sm">
                  {user?.full_name?.charAt(0) || 'A'}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{user?.full_name || 'Admin'}</p>
                <p className="text-xs text-muted-foreground">مستخدم النسخة</p>
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="flex-1"
                onClick={toggleLanguage}
                data-testid="tenant-language-toggle"
              >
                <Globe className="h-4 w-4 me-1" />
                {i18n.language === 'ar' ? 'EN' : 'عربي'}
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                className="flex-1 hover:bg-destructive hover:text-white hover:border-destructive"
                onClick={handleLogout}
                data-testid="tenant-logout-button"
              >
                <LogOut className="h-4 w-4 me-1" />
                خروج
              </Button>
            </div>
          </div>
        )}
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-border bg-card flex items-center px-4 gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            data-testid="tenant-sidebar-toggle"
            className="lg:hidden"
          >
            {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
          
          <div className="flex-1">
            <h2 className="text-lg font-semibold" data-testid="tenant-page-title">
              {menuSections.flatMap(s => s.items).find(item => item.path === location.pathname)?.label || 'لوحة التحكم'}
            </h2>
            <p className="text-xs text-muted-foreground">{companyName}</p>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2">
            <Link to={`${basePath}/easy-entries`}>
              <Button size="sm" className="bg-emerald hover:bg-emerald-hover hidden sm:flex">
                <Zap className="h-4 w-4 me-1" />
                قيد سريع
              </Button>
            </Link>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto bg-muted/30 p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
