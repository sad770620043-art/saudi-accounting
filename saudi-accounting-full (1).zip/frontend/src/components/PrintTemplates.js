import React, { useEffect, useState, useCallback } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import api from '../utils/api';
import { formatDate, formatCurrency } from '../utils/exportHelpers';

// Print CSS
const createPrintStyles = (invoiceColor, voucherColor) => `
  @media print {
    @page {
      margin: 0.8cm;
      size: A4;
    }
    
    * {
      print-color-adjust: exact !important;
      -webkit-print-color-adjust: exact !important;
      color-adjust: exact !important;
    }
    
    body {
      margin: 0;
      padding: 0;
    }
    
    .no-print {
      display: none !important;
    }
    
    .print-page {
      background: white !important;
      width: 100% !important;
      min-height: 100vh !important;
    }
    
    table {
      border-collapse: collapse !important;
      width: 100% !important;
    }
    
    th, td {
      border: 1px solid #333 !important;
      padding: 8px !important;
    }
    
    .invoice-header {
      background-color: ${invoiceColor} !important;
      color: white !important;
    }
    
    .voucher-header {
      background-color: ${voucherColor} !important;
      color: white !important;
    }
  }
`;

// Company Header Component with dynamic color
const CompanyHeader = ({ settings, title, titleEn, type = 'invoice' }) => {
  const logo = settings?.logo_base64 || settings?.logo_url;
  const color = type === 'invoice' 
    ? (settings?.invoice_color || '#006d5b') 
    : (settings?.voucher_color || '#006d5b');
  
  return (
    <div className="pb-4 mb-6" style={{ borderBottom: `3px solid ${color}` }}>
      <div className="flex items-start justify-between">
        {/* Logo */}
        <div className="w-28">
          {logo ? (
            <img src={logo} alt="Logo" className="w-28 h-28 object-contain" />
          ) : (
            <div className="w-28 h-28 border-2 border-dashed border-gray-300 rounded flex items-center justify-center text-xs text-gray-400">
              الشعار
            </div>
          )}
        </div>
        
        {/* Company Info */}
        <div className="flex-1 text-center px-4">
          <h1 className="text-2xl font-bold" style={{ color }}>
            {settings?.company_name_ar || 'اسم الشركة'}
          </h1>
          {settings?.company_name_en && (
            <h2 className="text-lg text-gray-600">{settings.company_name_en}</h2>
          )}
          <div className="mt-2 text-sm text-gray-600 space-y-0.5">
            {settings?.address_ar && <p>{settings.address_ar}</p>}
            <p>
              {settings?.phone && <span>هاتف: {settings.phone}</span>}
              {settings?.phone && settings?.email && <span> | </span>}
              {settings?.email && <span>{settings.email}</span>}
            </p>
          </div>
        </div>
        
        {/* Tax Info */}
        <div className="w-36 text-end text-sm">
          {settings?.commercial_registration && (
            <p className="text-gray-600">
              <span className="font-semibold">س.ت:</span> {settings.commercial_registration}
            </p>
          )}
          {settings?.tax_number && (
            <div className="mt-2 p-2 rounded" style={{ backgroundColor: `${color}15` }}>
              <span className="block text-xs text-gray-500">الرقم الضريبي</span>
              <span className="font-bold font-mono" style={{ color }}>{settings.tax_number}</span>
            </div>
          )}
        </div>
      </div>
      
      {/* Document Title */}
      <div className="text-center mt-4 pt-4 border-t border-gray-200">
        <h2 className="text-2xl font-bold" style={{ color }}>{title}</h2>
        {titleEn && <h3 className="text-lg text-gray-600">{titleEn}</h3>}
      </div>
    </div>
  );
};

// Print Button Component
const PrintButtons = ({ onClose, color }) => {
  const [isPrinting, setIsPrinting] = React.useState(false);

  const handlePrint = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsPrinting(true);
    
    // Small delay to ensure UI updates
    setTimeout(() => {
      try {
        window.print();
      } catch (err) {
        console.error('Print error:', err);
        alert('يرجى استخدام Ctrl+P للطباعة');
      } finally {
        setIsPrinting(false);
      }
    }, 200);
  };

  // Also allow keyboard shortcut
  React.useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
        // Let browser handle Ctrl+P naturally
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="no-print flex flex-col items-center gap-2 mb-6 p-4 bg-gray-100 rounded-lg sticky top-0 z-50">
      <div className="flex justify-center gap-3">
        <button
          type="button"
          onClick={onClose}
          className="px-6 py-2.5 border-2 border-gray-400 rounded-lg hover:bg-gray-200 font-semibold transition-colors"
          data-testid="close-print-btn"
        >
          إغلاق
        </button>
        <button
          type="button"
          onClick={handlePrint}
          disabled={isPrinting}
          className="px-8 py-2.5 text-white rounded-lg font-semibold transition-all flex items-center gap-2 cursor-pointer hover:opacity-90 active:scale-95 disabled:opacity-50"
          style={{ backgroundColor: color || '#006d5b' }}
          data-testid="print-action-btn"
        >
          {isPrinting ? (
            <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          ) : (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
            </svg>
          )}
          {isPrinting ? 'جاري الطباعة...' : 'طباعة'}
        </button>
      </div>
      <p className="text-xs text-gray-600 text-center bg-yellow-50 px-3 py-1.5 rounded border border-yellow-200">
        💡 <strong>لإخفاء رأس وتذييل الصفحة:</strong> في نافذة الطباعة ← المزيد من الإعدادات ← ألغِ تحديد "الرؤوس والتذييلات"
      </p>
    </div>
  );
};

// Generate QR Code data for ZATCA
const generateQRData = (invoice, settings) => {
  // ZATCA TLV format simplified
  const data = [
    settings?.company_name_ar || 'Company',
    settings?.tax_number || '',
    invoice.invoice_date ? new Date(invoice.invoice_date).toISOString() : '',
    String(invoice.total_amount || 0),
    String(invoice.vat_amount || 0)
  ].join('|');
  return data;
};

// Print Invoice
export const PrintInvoice = ({ invoice, customer, onClose }) => {
  const [settings, setSettings] = useState(null);

  const loadSettings = useCallback(async () => {
    try {
      const res = await api.get('/company-settings');
      setSettings(res.data);
      
      // Inject print styles
      const styleId = 'print-styles-dynamic';
      let styleEl = document.getElementById(styleId);
      if (styleEl) styleEl.remove();
      
      styleEl = document.createElement('style');
      styleEl.id = styleId;
      styleEl.textContent = createPrintStyles(
        res.data.invoice_color || '#006d5b',
        res.data.voucher_color || '#006d5b'
      );
      document.head.appendChild(styleEl);
    } catch (e) {
      console.error('Error loading settings');
    }
  }, []);

  useEffect(() => {
    loadSettings();
    // Add print-mode class to body
    document.body.classList.add('print-mode');
    return () => {
      document.body.classList.remove('print-mode');
    };
  }, [loadSettings]);

  const color = settings?.invoice_color || '#006d5b';
  const template = settings?.invoice_template || 'classic';
  const qrData = generateQRData(invoice, settings);

  // Modern Template
  if (template === 'modern') {
    return (
      <div className="fixed inset-0 bg-gray-100 z-50 overflow-auto print-container">
        <div className="max-w-4xl mx-auto p-4 print:p-0 print:max-w-none">
          <PrintButtons onClose={onClose} color={color} />
          <div className="bg-white border-2 border-gray-300 p-8 print-page print:border-0" style={{ minHeight: '297mm' }}>
            {/* Modern Header with gradient */}
            <div className="relative mb-8">
              <div className="absolute inset-0 rounded-xl" style={{ background: `linear-gradient(135deg, ${color}20 0%, ${color}05 100%)` }}></div>
              <div className="relative p-6 flex justify-between items-start">
                <div>
                  {settings?.logo_base64 || settings?.logo_url ? (
                    <img src={settings.logo_base64 || settings.logo_url} alt="Logo" className="h-20 object-contain mb-3" />
                  ) : null}
                  <h1 className="text-2xl font-bold" style={{ color }}>{settings?.company_name_ar}</h1>
                  <p className="text-gray-500">{settings?.company_name_en}</p>
                </div>
                <div className="text-left">
                  <div className="inline-block px-6 py-3 rounded-xl" style={{ backgroundColor: color }}>
                    <h2 className="text-white text-xl font-bold">فاتورة ضريبية</h2>
                    <p className="text-white/80 text-sm">TAX INVOICE</p>
                  </div>
                  <div className="mt-3 text-sm text-gray-600">
                    <p>رقم: <span className="font-bold">{invoice.invoice_number}</span></p>
                    <p>تاريخ: {formatDate(invoice.invoice_date)}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Customer + QR in modern style */}
            <div className="grid grid-cols-3 gap-6 mb-8">
              <div className="col-span-2 p-4 rounded-xl border-2" style={{ borderColor: `${color}30` }}>
                <h3 className="font-bold text-lg mb-3" style={{ color }}>معلومات العميل</h3>
                <p className="text-lg font-semibold">{customer?.customer_name || invoice.customer_code}</p>
                {customer?.tax_number && <p className="text-gray-600">الرقم الضريبي: {customer.tax_number}</p>}
                {customer?.phone && <p className="text-gray-600">الهاتف: {customer.phone}</p>}
              </div>
              <div className="flex flex-col items-center justify-center p-4 rounded-xl" style={{ backgroundColor: `${color}10` }}>
                <QRCodeSVG value={qrData} size={90} level="M" />
                <p className="text-xs mt-2" style={{ color }}>رمز ZATCA</p>
              </div>
            </div>

            {/* Items Table - Modern */}
            <div className="mb-8 rounded-xl overflow-hidden border" style={{ borderColor: `${color}30` }}>
              <table className="w-full">
                <thead>
                  <tr style={{ backgroundColor: color }}>
                    <th className="px-4 py-3 text-white text-center w-12">#</th>
                    <th className="px-4 py-3 text-white text-right">الوصف</th>
                    <th className="px-4 py-3 text-white text-center w-20">الكمية</th>
                    <th className="px-4 py-3 text-white text-right w-28">السعر</th>
                    <th className="px-4 py-3 text-white text-right w-28">الإجمالي</th>
                  </tr>
                </thead>
                <tbody>
                  {invoice.items?.map((item, index) => (
                    <tr key={index} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                      <td className="px-4 py-3 text-center">{index + 1}</td>
                      <td className="px-4 py-3">{item.description}</td>
                      <td className="px-4 py-3 text-center">{item.quantity}</td>
                      <td className="px-4 py-3 text-left font-mono" dir="ltr">{formatCurrency(item.unit_price)}</td>
                      <td className="px-4 py-3 text-left font-mono font-semibold" dir="ltr">{formatCurrency(item.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Totals - Modern */}
            <div className="flex justify-end">
              <div className="w-80 rounded-xl overflow-hidden" style={{ backgroundColor: `${color}10` }}>
                <div className="p-4 space-y-2">
                  <div className="flex justify-between"><span>المجموع الفرعي</span><span className="font-mono">{formatCurrency(invoice.subtotal)}</span></div>
                  <div className="flex justify-between"><span>ضريبة القيمة المضافة (15%)</span><span className="font-mono">{formatCurrency(invoice.vat_amount)}</span></div>
                </div>
                <div className="p-4 text-white flex justify-between text-lg font-bold" style={{ backgroundColor: color }}>
                  <span>الإجمالي</span>
                  <span className="font-mono">{formatCurrency(invoice.total_amount)}</span>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="mt-8 pt-4 border-t text-center text-sm text-gray-500">
              <p>{settings?.phone} | {settings?.email}</p>
              <p>{settings?.address_ar}</p>
              {settings?.tax_number && <p>الرقم الضريبي: {settings.tax_number}</p>}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Minimal Template
  if (template === 'minimal') {
    return (
      <div className="fixed inset-0 bg-gray-100 z-50 overflow-auto print-container">
        <div className="max-w-4xl mx-auto p-4 print:p-0 print:max-w-none">
          <PrintButtons onClose={onClose} color={color} />
          <div className="bg-white border border-gray-200 p-8 print-page print:border-0" style={{ minHeight: '297mm' }}>
            {/* Minimal Header */}
            <div className="flex justify-between items-start mb-10 pb-6 border-b-2" style={{ borderColor: color }}>
              <div>
                <h1 className="text-3xl font-light" style={{ color }}>{settings?.company_name_ar}</h1>
                <p className="text-gray-400 text-sm">{settings?.company_name_en}</p>
              </div>
              <div className="text-left">
                <h2 className="text-xl font-light mb-2">فاتورة ضريبية</h2>
                <p className="text-2xl font-mono" style={{ color }}>#{invoice.invoice_number}</p>
                <p className="text-sm text-gray-500">{formatDate(invoice.invoice_date)}</p>
              </div>
            </div>

            {/* Info Row */}
            <div className="grid grid-cols-3 gap-8 mb-10">
              <div>
                <p className="text-xs text-gray-400 uppercase mb-1">إلى</p>
                <p className="font-semibold">{customer?.customer_name || invoice.customer_code}</p>
                {customer?.tax_number && <p className="text-sm text-gray-600">{customer.tax_number}</p>}
              </div>
              <div>
                <p className="text-xs text-gray-400 uppercase mb-1">من</p>
                <p className="font-semibold">{settings?.company_name_ar}</p>
                {settings?.tax_number && <p className="text-sm text-gray-600">{settings.tax_number}</p>}
              </div>
              <div className="flex justify-end">
                <QRCodeSVG value={qrData} size={70} level="M" />
              </div>
            </div>

            {/* Items - Minimal */}
            <table className="w-full mb-10">
              <thead>
                <tr className="border-b-2" style={{ borderColor: color }}>
                  <th className="py-3 text-right text-sm font-medium text-gray-500">البند</th>
                  <th className="py-3 text-center text-sm font-medium text-gray-500 w-20">الكمية</th>
                  <th className="py-3 text-left text-sm font-medium text-gray-500 w-28">السعر</th>
                  <th className="py-3 text-left text-sm font-medium text-gray-500 w-28">المجموع</th>
                </tr>
              </thead>
              <tbody>
                {invoice.items?.map((item, index) => (
                  <tr key={index} className="border-b border-gray-100">
                    <td className="py-4">{item.description}</td>
                    <td className="py-4 text-center text-gray-600">{item.quantity}</td>
                    <td className="py-4 text-left font-mono text-gray-600" dir="ltr">{formatCurrency(item.unit_price)}</td>
                    <td className="py-4 text-left font-mono font-semibold" dir="ltr">{formatCurrency(item.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Totals - Minimal */}
            <div className="flex justify-end">
              <div className="w-64">
                <div className="flex justify-between py-2 text-gray-600"><span>المجموع</span><span>{formatCurrency(invoice.subtotal)}</span></div>
                <div className="flex justify-between py-2 text-gray-600"><span>الضريبة 15%</span><span>{formatCurrency(invoice.vat_amount)}</span></div>
                <div className="flex justify-between py-3 text-xl font-bold border-t-2 mt-2" style={{ borderColor: color, color }}>
                  <span>الإجمالي</span><span>{formatCurrency(invoice.total_amount)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Professional Template
  if (template === 'professional') {
    return (
      <div className="fixed inset-0 bg-gray-100 z-50 overflow-auto print-container">
        <div className="max-w-4xl mx-auto p-4 print:p-0 print:max-w-none">
          <PrintButtons onClose={onClose} color={color} />
          <div className="bg-white print-page print:border-0" style={{ minHeight: '297mm' }}>
            {/* Professional Header - Dark */}
            <div className="text-white p-8" style={{ backgroundColor: '#1f2937' }}>
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                  {settings?.logo_base64 || settings?.logo_url ? (
                    <img src={settings.logo_base64 || settings.logo_url} alt="Logo" className="h-16 object-contain bg-white p-2 rounded" />
                  ) : null}
                  <div>
                    <h1 className="text-2xl font-bold">{settings?.company_name_ar}</h1>
                    <p className="text-gray-400">{settings?.company_name_en}</p>
                  </div>
                </div>
                <div className="text-left">
                  <div className="text-3xl font-bold" style={{ color }}>فاتورة ضريبية</div>
                  <p className="text-gray-400">TAX INVOICE</p>
                </div>
              </div>
            </div>

            {/* Info Bar */}
            <div className="px-8 py-4 flex justify-between text-sm" style={{ backgroundColor: color }}>
              <span className="text-white">رقم الفاتورة: {invoice.invoice_number}</span>
              <span className="text-white">التاريخ: {formatDate(invoice.invoice_date)}</span>
              <span className="text-white">الرقم الضريبي: {settings?.tax_number}</span>
            </div>

            <div className="p-8">
              {/* Customer + QR */}
              <div className="grid grid-cols-3 gap-6 mb-8">
                <div className="col-span-2">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="p-4 bg-gray-50 rounded">
                      <h4 className="font-bold text-gray-700 mb-2">معلومات العميل</h4>
                      <p className="font-semibold">{customer?.customer_name || invoice.customer_code}</p>
                      {customer?.tax_number && <p className="text-sm text-gray-600">الرقم الضريبي: {customer.tax_number}</p>}
                      {customer?.phone && <p className="text-sm text-gray-600">{customer.phone}</p>}
                    </div>
                    <div className="p-4 bg-gray-50 rounded">
                      <h4 className="font-bold text-gray-700 mb-2">معلومات الشركة</h4>
                      <p className="text-sm">{settings?.address_ar}</p>
                      <p className="text-sm">{settings?.phone}</p>
                      <p className="text-sm">{settings?.email}</p>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col items-center justify-center p-4 border-2 border-gray-200 rounded">
                  <QRCodeSVG value={qrData} size={100} level="M" />
                  <p className="text-xs text-gray-500 mt-2">ZATCA QR Code</p>
                </div>
              </div>

              {/* Items Table - Professional */}
              <table className="w-full mb-8">
                <thead>
                  <tr className="bg-gray-800 text-white">
                    <th className="px-4 py-3 text-center w-12">#</th>
                    <th className="px-4 py-3 text-right">الوصف</th>
                    <th className="px-4 py-3 text-center w-20">الكمية</th>
                    <th className="px-4 py-3 text-right w-28">السعر</th>
                    <th className="px-4 py-3 text-right w-28">الإجمالي</th>
                  </tr>
                </thead>
                <tbody>
                  {invoice.items?.map((item, index) => (
                    <tr key={index} className={index % 2 === 0 ? 'bg-gray-50' : ''}>
                      <td className="px-4 py-3 text-center border-b">{index + 1}</td>
                      <td className="px-4 py-3 border-b">{item.description}</td>
                      <td className="px-4 py-3 text-center border-b">{item.quantity}</td>
                      <td className="px-4 py-3 text-left font-mono border-b" dir="ltr">{formatCurrency(item.unit_price)}</td>
                      <td className="px-4 py-3 text-left font-mono font-semibold border-b" dir="ltr">{formatCurrency(item.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Totals */}
              <div className="flex justify-end">
                <div className="w-80">
                  <div className="flex justify-between py-2 border-b"><span>المجموع الفرعي</span><span className="font-mono">{formatCurrency(invoice.subtotal)}</span></div>
                  <div className="flex justify-between py-2 border-b"><span>ضريبة القيمة المضافة (15%)</span><span className="font-mono">{formatCurrency(invoice.vat_amount)}</span></div>
                  <div className="flex justify-between py-3 text-white text-lg font-bold px-4 -mx-4" style={{ backgroundColor: color }}>
                    <span>الإجمالي المستحق</span><span className="font-mono">{formatCurrency(invoice.total_amount)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Default Classic Template

  return (
    <div className="fixed inset-0 bg-gray-100 z-50 overflow-auto print-container">
      <div className="max-w-4xl mx-auto p-4 print:p-0 print:max-w-none">
        <PrintButtons onClose={onClose} color={color} />

        <div className="bg-white border-2 border-gray-300 p-8 print-page print:border-0" style={{ minHeight: '297mm' }}>
          <CompanyHeader settings={settings} title="فاتورة ضريبية" titleEn="TAX INVOICE" type="invoice" />

          {/* Invoice Info + QR Code */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="col-span-2">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 rounded" style={{ backgroundColor: `${color}10` }}>
                  <h3 className="font-bold mb-2" style={{ color }}>معلومات الفاتورة</h3>
                  <div className="space-y-1 text-sm">
                    <p><span className="font-semibold">رقم الفاتورة:</span> {invoice.invoice_number}</p>
                    <p><span className="font-semibold">التاريخ:</span> {formatDate(invoice.invoice_date)}</p>
                  </div>
                </div>
                <div className="p-3 rounded" style={{ backgroundColor: `${color}10` }}>
                  <h3 className="font-bold mb-2" style={{ color }}>بيانات العميل</h3>
                  <div className="space-y-1 text-sm">
                    <p><span className="font-semibold">الاسم:</span> {customer?.customer_name || invoice.customer_code}</p>
                    {customer?.tax_number && <p><span className="font-semibold">الرقم الضريبي:</span> {customer.tax_number}</p>}
                    {customer?.phone && <p><span className="font-semibold">الهاتف:</span> {customer.phone}</p>}
                  </div>
                </div>
              </div>
            </div>
            
            {/* QR Code */}
            <div className="flex flex-col items-center justify-center p-3 border rounded">
              <QRCodeSVG value={qrData} size={100} level="M" />
              <p className="text-xs text-gray-500 mt-2">رمز الفاتورة الإلكترونية</p>
            </div>
          </div>

          {/* Items Table */}
          <div className="mb-6">
            <table className="w-full border-collapse">
              <thead>
                <tr className="invoice-header" style={{ backgroundColor: color, color: 'white' }}>
                  <th className="border px-3 py-2 text-center w-12">#</th>
                  <th className="border px-3 py-2 text-right">الوصف</th>
                  <th className="border px-3 py-2 text-center w-20">الكمية</th>
                  <th className="border px-3 py-2 text-right w-28">سعر الوحدة</th>
                  <th className="border px-3 py-2 text-right w-28">الإجمالي</th>
                </tr>
              </thead>
              <tbody>
                {invoice.items?.map((item, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="border px-3 py-2 text-center">{index + 1}</td>
                    <td className="border px-3 py-2">{item.description}</td>
                    <td className="border px-3 py-2 text-center">{item.quantity}</td>
                    <td className="border px-3 py-2 text-left font-mono" dir="ltr">{formatCurrency(item.unit_price)}</td>
                    <td className="border px-3 py-2 text-left font-mono font-semibold" dir="ltr">{formatCurrency(item.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div className="flex justify-end mb-6">
            <div className="w-72">
              <div className="flex justify-between py-2 border-b">
                <span>المجموع الفرعي:</span>
                <span className="font-mono" dir="ltr">{formatCurrency(invoice.subtotal)}</span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span>ضريبة القيمة المضافة ({invoice.vat_rate}%):</span>
                <span className="font-mono" dir="ltr">{formatCurrency(invoice.vat_amount)}</span>
              </div>
              <div className="flex justify-between py-3 px-3 rounded mt-2 text-white" style={{ backgroundColor: color }}>
                <span className="font-bold text-lg">الإجمالي:</span>
                <span className="font-bold text-lg font-mono" dir="ltr">{formatCurrency(invoice.total_amount)}</span>
              </div>
            </div>
          </div>

          {/* Tax Number Footer */}
          {settings?.tax_number && (
            <div className="mb-6 p-3 rounded text-center" style={{ backgroundColor: `${color}10`, border: `2px solid ${color}` }}>
              <span className="font-bold">الرقم الضريبي للمنشأة: </span>
              <span className="font-mono text-lg">{settings.tax_number}</span>
            </div>
          )}

          {/* Footer */}
          <div className="text-center pt-4 border-t-2 text-sm text-gray-500">
            <p>شكراً لتعاملكم معنا | Thank you for your business</p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Print Receipt Voucher
export const PrintReceiptVoucher = ({ voucher, onClose }) => {
  const [settings, setSettings] = useState(null);

  useEffect(() => {
    // Add print-mode class to body
    document.body.classList.add('print-mode');
    
    api.get('/company-settings').then(res => {
      setSettings(res.data);
      const styleId = 'print-styles-dynamic';
      let styleEl = document.getElementById(styleId);
      if (styleEl) styleEl.remove();
      styleEl = document.createElement('style');
      styleEl.id = styleId;
      styleEl.textContent = createPrintStyles(res.data.invoice_color || '#006d5b', res.data.voucher_color || '#006d5b');
      document.head.appendChild(styleEl);
    }).catch(() => {});
    
    return () => {
      document.body.classList.remove('print-mode');
    };
  }, []);

  const color = settings?.voucher_color || '#006d5b';

  return (
    <div className="fixed inset-0 bg-gray-100 z-50 overflow-auto print-container">
      <div className="max-w-3xl mx-auto p-4 print:p-0 print:max-w-none">
        <PrintButtons onClose={onClose} color={color} />

        <div className="bg-white border-2 border-gray-300 p-8 print-page print:border-0">
          <CompanyHeader settings={settings} title="سند قبض" titleEn="RECEIPT VOUCHER" type="voucher" />

          <div className="grid grid-cols-2 gap-6 mb-8">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <span className="font-bold min-w-[100px]">رقم السند:</span>
                <span className="flex-1 border-b-2 border-gray-300 pb-1 font-mono">{voucher.voucher_number}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-bold min-w-[100px]">التاريخ:</span>
                <span className="flex-1 border-b-2 border-gray-300 pb-1">{formatDate(voucher.voucher_date)}</span>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <span className="font-bold min-w-[100px]">المبلغ:</span>
                <span className="flex-1 border-b-2 pb-1 font-bold text-xl font-mono" style={{ color, borderColor: color }} dir="ltr">
                  {formatCurrency(voucher.amount)}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-bold min-w-[100px]">طريقة الدفع:</span>
                <span className="flex-1 border-b-2 border-gray-300 pb-1">
                  {voucher.payment_method === 'cash' ? 'نقدي' : voucher.payment_method === 'check' ? 'شيك' : 'تحويل بنكي'}
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-4 mb-8">
            <div className="flex items-center gap-3">
              <span className="font-bold min-w-[130px]">استلمنا من السيد/ة:</span>
              <span className="flex-1 border-b-2 border-gray-300 pb-1 text-lg">{voucher.received_from}</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-bold min-w-[130px]">وذلك عن:</span>
              <span className="flex-1 border-b-2 border-gray-300 pb-1">{voucher.description}</span>
            </div>
          </div>

          {/* Amount in Box */}
          <div className="mb-8 p-4 rounded text-center" style={{ backgroundColor: `${color}10`, border: `2px solid ${color}` }}>
            <span className="text-lg">المبلغ المستلم: </span>
            <span className="text-2xl font-bold font-mono" style={{ color }} dir="ltr">{formatCurrency(voucher.amount)}</span>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-2 gap-12 mt-16">
            <div className="text-center">
              <div className="border-t-2 border-gray-400 pt-3 mt-20">
                <p className="font-bold">توقيع المستلم</p>
              </div>
            </div>
            <div className="text-center">
              <div className="border-t-2 border-gray-400 pt-3 mt-20">
                <p className="font-bold">توقيع المحاسب</p>
              </div>
            </div>
          </div>

          <div className="text-center pt-6 mt-8 border-t text-sm text-gray-500">
            <p>{settings?.company_name_ar}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Print Payment Voucher
export const PrintPaymentVoucher = ({ voucher, onClose }) => {
  const [settings, setSettings] = useState(null);

  useEffect(() => {
    // Add print-mode class to body
    document.body.classList.add('print-mode');
    
    api.get('/company-settings').then(res => {
      setSettings(res.data);
      const styleId = 'print-styles-dynamic';
      let styleEl = document.getElementById(styleId);
      if (styleEl) styleEl.remove();
      styleEl = document.createElement('style');
      styleEl.id = styleId;
      styleEl.textContent = createPrintStyles(res.data.invoice_color || '#006d5b', res.data.voucher_color || '#006d5b');
      document.head.appendChild(styleEl);
    }).catch(() => {});
    
    return () => {
      document.body.classList.remove('print-mode');
    };
  }, []);

  const color = settings?.voucher_color || '#006d5b';

  return (
    <div className="fixed inset-0 bg-gray-100 z-50 overflow-auto print-container">
      <div className="max-w-3xl mx-auto p-4 print:p-0 print:max-w-none">
        <PrintButtons onClose={onClose} color={color} />

        <div className="bg-white border-2 border-gray-300 p-8 print-page print:border-0">
          <CompanyHeader settings={settings} title="سند صرف" titleEn="PAYMENT VOUCHER" type="voucher" />

          <div className="grid grid-cols-2 gap-6 mb-8">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <span className="font-bold min-w-[100px]">رقم السند:</span>
                <span className="flex-1 border-b-2 border-gray-300 pb-1 font-mono">{voucher.voucher_number}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-bold min-w-[100px]">التاريخ:</span>
                <span className="flex-1 border-b-2 border-gray-300 pb-1">{formatDate(voucher.voucher_date)}</span>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <span className="font-bold min-w-[100px]">المبلغ:</span>
                <span className="flex-1 border-b-2 pb-1 font-bold text-xl font-mono" style={{ color, borderColor: color }} dir="ltr">
                  {formatCurrency(voucher.amount)}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-bold min-w-[100px]">طريقة الدفع:</span>
                <span className="flex-1 border-b-2 border-gray-300 pb-1">
                  {voucher.payment_method === 'cash' ? 'نقدي' : voucher.payment_method === 'check' ? 'شيك' : 'تحويل بنكي'}
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-4 mb-8">
            <div className="flex items-center gap-3">
              <span className="font-bold min-w-[130px]">صرفنا للسيد/ة:</span>
              <span className="flex-1 border-b-2 border-gray-300 pb-1 text-lg">{voucher.paid_to}</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-bold min-w-[130px]">وذلك عن:</span>
              <span className="flex-1 border-b-2 border-gray-300 pb-1">{voucher.description}</span>
            </div>
          </div>

          {/* Amount in Box */}
          <div className="mb-8 p-4 rounded text-center" style={{ backgroundColor: `${color}10`, border: `2px solid ${color}` }}>
            <span className="text-lg">المبلغ المصروف: </span>
            <span className="text-2xl font-bold font-mono" style={{ color }} dir="ltr">{formatCurrency(voucher.amount)}</span>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-2 gap-12 mt-16">
            <div className="text-center">
              <div className="border-t-2 border-gray-400 pt-3 mt-20">
                <p className="font-bold">توقيع المستلم</p>
              </div>
            </div>
            <div className="text-center">
              <div className="border-t-2 border-gray-400 pt-3 mt-20">
                <p className="font-bold">توقيع المحاسب</p>
              </div>
            </div>
          </div>

          <div className="text-center pt-6 mt-8 border-t text-sm text-gray-500">
            <p>{settings?.company_name_ar}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Print Journal Entry
export const PrintJournalEntry = ({ entry, accounts, onClose }) => {
  const [settings, setSettings] = useState(null);

  useEffect(() => {
    // Add print-mode class to body
    document.body.classList.add('print-mode');
    
    api.get('/company-settings').then(res => {
      setSettings(res.data);
      const styleId = 'print-styles-dynamic';
      let styleEl = document.getElementById(styleId);
      if (styleEl) styleEl.remove();
      styleEl = document.createElement('style');
      styleEl.id = styleId;
      styleEl.textContent = createPrintStyles(res.data.invoice_color || '#006d5b', res.data.voucher_color || '#006d5b');
      document.head.appendChild(styleEl);
    }).catch(() => {});
    
    return () => {
      document.body.classList.remove('print-mode');
    };
  }, []);

  const color = settings?.voucher_color || '#006d5b';

  const getAccountName = (accountCode) => {
    const account = accounts?.find(a => a.account_code === accountCode);
    return account?.account_name_ar || '-';
  };

  return (
    <div className="fixed inset-0 bg-gray-100 z-50 overflow-auto print-container">
      <div className="max-w-4xl mx-auto p-4 print:p-0 print:max-w-none">
        <PrintButtons onClose={onClose} color={color} />

        <div className="bg-white border-2 border-gray-300 p-8 print-page print:border-0">
          <CompanyHeader settings={settings} title="قيد يومية" titleEn="JOURNAL ENTRY" type="voucher" />

          <div className="grid grid-cols-2 gap-6 mb-6">
            <div className="flex items-center gap-3">
              <span className="font-bold">رقم القيد:</span>
              <span className="border-b-2 border-gray-300 pb-1 px-3 font-mono">{entry.entry_number}</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-bold">التاريخ:</span>
              <span className="border-b-2 border-gray-300 pb-1 px-3">{formatDate(entry.entry_date)}</span>
            </div>
          </div>

          <div className="mb-6">
            <span className="font-bold">الوصف: </span>
            <span>{entry.description}</span>
          </div>

          <div className="mb-6">
            <table className="w-full border-collapse">
              <thead>
                <tr style={{ backgroundColor: color, color: 'white' }}>
                  <th className="border px-3 py-2 text-center w-12">#</th>
                  <th className="border px-3 py-2 text-right w-24">رمز الحساب</th>
                  <th className="border px-3 py-2 text-right">اسم الحساب</th>
                  <th className="border px-3 py-2 text-right">البيان</th>
                  <th className="border px-3 py-2 text-right w-28">مدين</th>
                  <th className="border px-3 py-2 text-right w-28">دائن</th>
                </tr>
              </thead>
              <tbody>
                {entry.lines?.map((line, index) => (
                  <tr key={index}>
                    <td className="border px-3 py-2 text-center">{index + 1}</td>
                    <td className="border px-3 py-2 font-mono">{line.account_code}</td>
                    <td className="border px-3 py-2">{getAccountName(line.account_code)}</td>
                    <td className="border px-3 py-2">{line.description}</td>
                    <td className="border px-3 py-2 text-left font-mono" dir="ltr">
                      {line.debit > 0 ? formatCurrency(line.debit) : '-'}
                    </td>
                    <td className="border px-3 py-2 text-left font-mono" dir="ltr">
                      {line.credit > 0 ? formatCurrency(line.credit) : '-'}
                    </td>
                  </tr>
                ))}
                <tr className="font-bold" style={{ backgroundColor: `${color}15` }}>
                  <td colSpan="4" className="border px-3 py-2 text-left">الإجمالي</td>
                  <td className="border px-3 py-2 text-left font-mono" style={{ color }} dir="ltr">{formatCurrency(entry.total_debit)}</td>
                  <td className="border px-3 py-2 text-left font-mono" style={{ color }} dir="ltr">{formatCurrency(entry.total_credit)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-3 gap-8 mt-16">
            <div className="text-center">
              <div className="border-t-2 border-gray-400 pt-3 mt-16">
                <p className="font-bold">المحاسب</p>
              </div>
            </div>
            <div className="text-center">
              <div className="border-t-2 border-gray-400 pt-3 mt-16">
                <p className="font-bold">المراجع</p>
              </div>
            </div>
            <div className="text-center">
              <div className="border-t-2 border-gray-400 pt-3 mt-16">
                <p className="font-bold">المدير المالي</p>
              </div>
            </div>
          </div>

          <div className="text-center pt-6 mt-8 border-t text-sm text-gray-500">
            <p>{settings?.company_name_ar}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
