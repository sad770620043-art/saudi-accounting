import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { Check, ChevronsUpDown, Search, Plus, X } from 'lucide-react';
import { cn } from '../lib/utils';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from './ui/popover';
import api from '../utils/api';
import { toast } from 'sonner';

// Maximum items to display for performance
const MAX_DISPLAY_ITEMS = 50;

export function AccountCombobox({ 
  accounts = [], 
  value, 
  onSelect, 
  placeholder = "اختر الحساب",
  language = 'ar',
  disabled = false,
  className = "",
  onAccountAdded = null
}) {
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [saving, setSaving] = useState(false);
  const [newAccount, setNewAccount] = useState({
    account_code: '',
    account_name_ar: '',
    account_name_en: '',
    account_type: '',
    nature: '',
    parent_code: '',
    level: 4,
    is_active: true,
    description: ''
  });
  const inputRef = useRef(null);
  const listRef = useRef(null);

  // Find the selected account
  const selectedAccount = useMemo(() => 
    accounts.find(acc => acc.account_code === value),
    [accounts, value]
  );

  // Filter and limit accounts based on search term - OPTIMIZED
  const filteredAccounts = useMemo(() => {
    if (!searchTerm.trim()) {
      // Show only first MAX_DISPLAY_ITEMS when no search
      return accounts.slice(0, MAX_DISPLAY_ITEMS);
    }
    
    const searchLower = searchTerm.toLowerCase().trim();
    const results = [];
    
    // Search efficiently - stop when we have enough results
    for (let i = 0; i < accounts.length && results.length < MAX_DISPLAY_ITEMS; i++) {
      const account = accounts[i];
      const code = account.account_code.toLowerCase();
      const nameAr = (account.account_name_ar || '').toLowerCase();
      const nameEn = (account.account_name_en || '').toLowerCase();
      
      if (code.includes(searchLower) || 
          nameAr.includes(searchLower) || 
          nameEn.includes(searchLower)) {
        results.push(account);
      }
    }
    
    return results;
  }, [accounts, searchTerm]);

  // Check if there are more results
  const hasMoreResults = useMemo(() => {
    if (!searchTerm.trim()) return accounts.length > MAX_DISPLAY_ITEMS;
    
    const searchLower = searchTerm.toLowerCase().trim();
    let count = 0;
    
    for (let i = 0; i < accounts.length; i++) {
      const account = accounts[i];
      const code = account.account_code.toLowerCase();
      const nameAr = (account.account_name_ar || '').toLowerCase();
      const nameEn = (account.account_name_en || '').toLowerCase();
      
      if (code.includes(searchLower) || nameAr.includes(searchLower) || nameEn.includes(searchLower)) {
        count++;
        if (count > MAX_DISPLAY_ITEMS) return true;
      }
    }
    return false;
  }, [accounts, searchTerm]);

  // Get parent accounts (level 1-3) for dropdown
  const parentAccounts = useMemo(() => 
    accounts.filter(acc => acc.level && acc.level <= 3),
    [accounts]
  );

  // Focus input when popover opens
  useEffect(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [open]);

  const handleSelect = useCallback((accountCode) => {
    onSelect(accountCode);
    setOpen(false);
    setSearchTerm('');
  }, [onSelect]);

  // Auto-generate code based on parent
  const handleParentChange = useCallback((parentCode) => {
    setNewAccount(prev => {
      const parent = accounts.find(a => a.account_code === parentCode);
      const parentLevel = parent?.level || 0;
      
      // Find next available code under this parent
      const childCodes = accounts
        .filter(a => a.parent_code === parentCode)
        .map(a => parseInt(a.account_code))
        .filter(n => !isNaN(n));
      
      const nextCode = childCodes.length > 0 
        ? String(Math.max(...childCodes) + 1)
        : parentCode + '01';
      
      return {
        ...prev,
        parent_code: parentCode,
        level: parentLevel + 1,
        account_code: nextCode,
        account_type: parent?.account_type || prev.account_type,
        nature: parent?.nature || prev.nature
      };
    });
  }, [accounts]);

  const handleAddNewAccount = async () => {
    if (!newAccount.account_code || !newAccount.account_name_ar) {
      toast.error('يرجى إدخال الرمز والاسم العربي');
      return;
    }
    if (!newAccount.parent_code) {
      toast.error('يرجى اختيار الحساب الرئيسي');
      return;
    }
    if (!newAccount.nature) {
      toast.error('يرجى اختيار طبيعة الحساب');
      return;
    }

    setSaving(true);
    try {
      const accountData = {
        ...newAccount,
        account_type: newAccount.account_type || 'expense',
        closing_type: ['revenue', 'expense'].includes(newAccount.account_type) ? 'income_statement' : 'balance_sheet'
      };
      
      await api.post('/accounts', accountData);
      toast.success('تم إضافة الحساب بنجاح');
      
      onSelect(newAccount.account_code);
      
      if (onAccountAdded) {
        onAccountAdded(newAccount);
      }
      
      setShowAddDialog(false);
      setNewAccount({
        account_code: '',
        account_name_ar: '',
        account_name_en: '',
        account_type: '',
        nature: '',
        parent_code: '',
        level: 4,
        is_active: true,
        description: ''
      });
      setOpen(false);
      setSearchTerm('');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'حدث خطأ أثناء إضافة الحساب');
    } finally {
      setSaving(false);
    }
  };

  const openAddDialog = () => {
    setNewAccount(prev => ({
      ...prev,
      account_name_ar: searchTerm
    }));
    setShowAddDialog(true);
  };

  const getDisplayText = () => {
    if (!selectedAccount) return placeholder;
    const name = language === 'ar' ? selectedAccount.account_name_ar : selectedAccount.account_name_en;
    return `${selectedAccount.account_code} - ${name}`;
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          disabled={disabled}
          className={cn(
            "w-full justify-between font-normal text-start",
            !value && "text-muted-foreground",
            className
          )}
          data-testid="account-combobox-trigger"
        >
          <span className="truncate">{getDisplayText()}</span>
          <ChevronsUpDown className="ms-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[420px] p-0" align="start">
        <div className="flex flex-col">
          {/* Search Input */}
          <div className="flex items-center border-b px-3 py-2">
            <Search className="me-2 h-4 w-4 shrink-0 opacity-50" />
            <input
              ref={inputRef}
              type="text"
              placeholder="ابحث برقم أو اسم الحساب..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex h-9 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              data-testid="account-search-input"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')}
                className="p-1 hover:bg-gray-100 rounded"
              >
                <X className="h-4 w-4 text-gray-400" />
              </button>
            )}
          </div>
          
          {/* Account List */}
          <div ref={listRef} className="max-h-[300px] overflow-y-auto">
            {filteredAccounts.length === 0 ? (
              <div className="py-4 text-center">
                <p className="text-sm text-muted-foreground mb-3">
                  {searchTerm ? `لا يوجد حساب "${searchTerm}"` : 'لا توجد نتائج'}
                </p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={openAddDialog}
                  className="text-emerald-600 border-emerald-300 hover:bg-emerald-50"
                >
                  <Plus className="h-4 w-4 me-1" />
                  إضافة حساب جديد
                </Button>
              </div>
            ) : (
              <div className="p-1">
                {/* Add new account button at top */}
                <div
                  onClick={openAddDialog}
                  className="flex cursor-pointer items-center gap-2 rounded-sm px-2 py-2 text-sm hover:bg-emerald-50 text-emerald-600 border-b mb-1"
                >
                  <Plus className="h-4 w-4 shrink-0" />
                  <span className="font-medium">إضافة حساب جديد</span>
                </div>
                
                {filteredAccounts.map((account) => {
                  const name = language === 'ar' ? account.account_name_ar : account.account_name_en;
                  const isSelected = value === account.account_code;
                  
                  return (
                    <div
                      key={account.account_code}
                      onClick={() => handleSelect(account.account_code)}
                      className={cn(
                        "flex cursor-pointer items-center gap-2 rounded-sm px-2 py-1.5 text-sm hover:bg-accent hover:text-accent-foreground",
                        isSelected && "bg-accent"
                      )}
                      data-testid={`account-option-${account.account_code}`}
                    >
                      <Check
                        className={cn(
                          "h-4 w-4 shrink-0",
                          isSelected ? "opacity-100" : "opacity-0"
                        )}
                      />
                      <div className="flex flex-col flex-1 min-w-0">
                        <span className="font-medium truncate text-xs">
                          {account.account_code} - {name}
                        </span>
                      </div>
                      <span className={cn(
                        "text-[10px] px-1.5 py-0.5 rounded",
                        account.account_type === 'asset' && "bg-blue-100 text-blue-700",
                        account.account_type === 'liability' && "bg-red-100 text-red-700",
                        account.account_type === 'equity' && "bg-purple-100 text-purple-700",
                        account.account_type === 'revenue' && "bg-green-100 text-green-700",
                        account.account_type === 'expense' && "bg-orange-100 text-orange-700"
                      )}>
                        {account.account_type === 'asset' && 'أصول'}
                        {account.account_type === 'liability' && 'خصوم'}
                        {account.account_type === 'equity' && 'ملكية'}
                        {account.account_type === 'revenue' && 'إيرادات'}
                        {account.account_type === 'expense' && 'مصروفات'}
                      </span>
                    </div>
                  );
                })}
                
                {/* Show hint if more results available */}
                {hasMoreResults && (
                  <div className="text-center py-2 text-xs text-muted-foreground border-t mt-1">
                    اكتب للبحث عن المزيد من الحسابات...
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </PopoverContent>

      {/* Add New Account Dialog - UPDATED DESIGN */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader className="border-b pb-4">
            <DialogTitle className="text-xl font-bold text-right">إنشاء حساب جديد</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {/* Parent Account */}
            <div className="flex items-center gap-4">
              <Label className="w-32 text-right font-medium">حساب رئيسي *</Label>
              <Select 
                value={newAccount.parent_code} 
                onValueChange={handleParentChange}
              >
                <SelectTrigger className="flex-1" data-testid="new-account-parent">
                  <SelectValue placeholder="حساب رئيسي" />
                </SelectTrigger>
                <SelectContent className="max-h-[300px]">
                  {parentAccounts.slice(0, 100).map(acc => (
                    <SelectItem key={acc.account_code} value={acc.account_code}>
                      {acc.account_code} - {acc.account_name_ar}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Nature */}
            <div className="flex items-center gap-4">
              <Label className="w-32 text-right font-medium">طبيعة الحساب *</Label>
              <Select 
                value={newAccount.nature} 
                onValueChange={(val) => setNewAccount({...newAccount, nature: val})}
              >
                <SelectTrigger className="flex-1" data-testid="new-account-nature">
                  <SelectValue placeholder="يرجى الاختيار" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="debit">مدين</SelectItem>
                  <SelectItem value="credit">دائن</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Deferral Code (Optional) */}
            <div className="flex items-center gap-4">
              <Label className="w-32 text-right font-medium">كود التأجيل</Label>
              <Select 
                value={newAccount.closing_type || ''} 
                onValueChange={(val) => setNewAccount({...newAccount, closing_type: val})}
              >
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="يرجى الاختيار" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="balance_sheet">قائمة المركز المالي</SelectItem>
                  <SelectItem value="income_statement">قائمة الدخل</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* English Name */}
            <div className="flex items-center gap-4">
              <Label className="w-32 text-right font-medium">الاسم الانجليزي *</Label>
              <Input
                value={newAccount.account_name_en}
                onChange={(e) => setNewAccount({...newAccount, account_name_en: e.target.value})}
                placeholder="Account Name"
                className="flex-1"
                data-testid="new-account-name-en"
              />
            </div>

            {/* Arabic Name */}
            <div className="flex items-center gap-4">
              <Label className="w-32 text-right font-medium">الاسم العربي *</Label>
              <Input
                value={newAccount.account_name_ar}
                onChange={(e) => setNewAccount({...newAccount, account_name_ar: e.target.value})}
                placeholder="اسم الحساب"
                className="flex-1"
                data-testid="new-account-name-ar"
              />
            </div>

            {/* Code */}
            <div className="flex items-center gap-4">
              <Label className="w-32 text-right font-medium">الرمز *</Label>
              <Input
                value={newAccount.account_code}
                onChange={(e) => setNewAccount({...newAccount, account_code: e.target.value})}
                placeholder="رمز الحساب"
                className="flex-1"
                data-testid="new-account-code"
              />
            </div>

            {/* Description */}
            <div className="flex items-start gap-4">
              <Label className="w-32 text-right font-medium pt-2">الوصف</Label>
              <Textarea
                value={newAccount.description || ''}
                onChange={(e) => setNewAccount({...newAccount, description: e.target.value})}
                placeholder="وصف الحساب (اختياري)"
                className="flex-1 min-h-[80px]"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex justify-start gap-2 pt-4 border-t">
              <Button 
                onClick={handleAddNewAccount}
                disabled={saving}
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-6"
                data-testid="save-new-account-btn"
              >
                {saving ? 'جاري الحفظ...' : 'متابعة'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setShowAddDialog(false)}
                className="px-6"
              >
                <X className="h-4 w-4 me-1" />
                إلغاء
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Popover>
  );
}

// Export for customers as well
export function CustomerCombobox({ 
  customers = [], 
  value, 
  onSelect, 
  placeholder = "اختر العميل",
  disabled = false,
  className = ""
}) {
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const inputRef = useRef(null);

  const selectedCustomer = customers.find(c => c.customer_code === value);

  const filteredCustomers = useMemo(() => {
    if (!searchTerm.trim()) return customers.slice(0, 50);
    
    const searchLower = searchTerm.toLowerCase();
    return customers.filter(customer => {
      const code = customer.customer_code.toLowerCase();
      const name = (customer.customer_name || '').toLowerCase();
      const phone = (customer.phone || '').toLowerCase();
      
      return code.includes(searchLower) || 
             name.includes(searchLower) || 
             phone.includes(searchLower);
    }).slice(0, 50);
  }, [customers, searchTerm]);

  useEffect(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [open]);

  const handleSelect = (customerCode) => {
    onSelect(customerCode);
    setOpen(false);
    setSearchTerm('');
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          disabled={disabled}
          className={cn(
            "w-full justify-between font-normal text-start",
            !value && "text-muted-foreground",
            className
          )}
          data-testid="customer-combobox-trigger"
        >
          <span className="truncate">
            {selectedCustomer ? selectedCustomer.customer_name : placeholder}
          </span>
          <ChevronsUpDown className="ms-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[350px] p-0" align="start">
        <div className="flex flex-col">
          <div className="flex items-center border-b px-3 py-2">
            <Search className="me-2 h-4 w-4 shrink-0 opacity-50" />
            <input
              ref={inputRef}
              type="text"
              placeholder="ابحث بالاسم أو رقم الهاتف..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex h-9 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              data-testid="customer-search-input"
            />
          </div>
          
          <div className="max-h-[300px] overflow-y-auto">
            {filteredCustomers.length === 0 ? (
              <div className="py-6 text-center text-sm text-muted-foreground">
                لا توجد نتائج
              </div>
            ) : (
              <div className="p-1">
                {filteredCustomers.map((customer) => {
                  const isSelected = value === customer.customer_code;
                  
                  return (
                    <div
                      key={customer.customer_code}
                      onClick={() => handleSelect(customer.customer_code)}
                      className={cn(
                        "flex cursor-pointer items-center gap-2 rounded-sm px-2 py-2 text-sm hover:bg-accent hover:text-accent-foreground",
                        isSelected && "bg-accent"
                      )}
                      data-testid={`customer-option-${customer.customer_code}`}
                    >
                      <Check
                        className={cn(
                          "h-4 w-4 shrink-0",
                          isSelected ? "opacity-100" : "opacity-0"
                        )}
                      />
                      <div className="flex flex-col flex-1 min-w-0">
                        <span className="font-medium truncate">
                          {customer.customer_name}
                        </span>
                        {customer.phone && (
                          <span className="text-xs text-muted-foreground">
                            {customer.phone}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
