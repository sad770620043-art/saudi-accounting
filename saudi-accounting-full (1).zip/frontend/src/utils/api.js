import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const api = axios.create({
  baseURL: API,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  
  // Add X-Tenant-ID header for multi-tenant support
  const tenantId = localStorage.getItem('tenant_id');
  if (tenantId) {
    config.headers['X-Tenant-ID'] = tenantId;
  }
  
  return config;
});

// Helper to set tenant context
export const setTenantContext = (tenantId) => {
  if (tenantId) {
    localStorage.setItem('tenant_id', tenantId);
  } else {
    localStorage.removeItem('tenant_id');
  }
};

// Helper to clear tenant context
export const clearTenantContext = () => {
  localStorage.removeItem('tenant_id');
};

// Helper to get current tenant ID
export const getTenantId = () => {
  return localStorage.getItem('tenant_id');
};

export default api;