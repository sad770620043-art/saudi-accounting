import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../utils/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card } from '../components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { toast } from 'sonner';
import { Plus, Edit, Trash2, Search, Building2 } from 'lucide-react';

export default function Customers() {
  const { t } = useTranslation();
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentCustomer, setCurrentCustomer] = useState({
    customer_code: '',
    customer_name: '',
    tax_number: '',
    phone: '',
    email: '',
    address: '',
    is_active: true
  });

  useEffect(() => {
    loadCustomers();
  }, []);

  const loadCustomers = async () => {
    try {
      const response = await api.get('/customers');
      setCustomers(response.data);
    } catch (error) {
      toast.error(t('error'));
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editMode) {
        await api.put(`/customers/${currentCustomer.customer_code}`, currentCustomer);
      } else {
        await api.post('/customers', currentCustomer);
      }
      toast.success(t('successfullySaved'));
      setDialogOpen(false);
      loadCustomers();
      resetForm();
    } catch (error) {
      toast.error(error.response?.data?.detail || t('error'));
    }
  };

  const handleDelete = async (code) => {
    if (window.confirm(t('areYouSure'))) {
      try {
        await api.delete(`/customers/${code}`);
        toast.success(t('successfullyDeleted'));
        loadCustomers();
      } catch (error) {
        toast.error(t('error'));
      }
    }
  };

  const resetForm = () => {
    setCurrentCustomer({
      customer_code: '',
      customer_name: '',
      tax_number: '',
      phone: '',
      email: '',
      address: '',
      is_active: true
    });
    setEditMode(false);
  };

  const openEditDialog = (customer) => {
    setCurrentCustomer({
      ...customer,
      tax_number: customer.tax_number || ''
    });
    setEditMode(true);
    setDialogOpen(true);
  };

  // Filter customers
  const filteredCustomers = customers.filter(customer => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      customer.customer_code.toLowerCase().includes(term) ||
      customer.customer_name.toLowerCase().includes(term) ||
      (customer.tax_number || '').toLowerCase().includes(term) ||
      (customer.phone || '').toLowerCase().includes(term)
    );
  });

  if (loading) {
    return <div className="text-center py-12">{t('loading')}</div>;
  }

  return (
    <div className="space-y-6" data-testid="customers-container">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">{t('customers')}</h1>
          <p className="text-sm text-muted-foreground">{customers.length} عميل</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald hover:bg-emerald-hover" onClick={resetForm} data-testid="add-customer-button">
              <Plus className="h-4 w-4 me-2" />
              {t('addCustomer')}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                {editMode ? t('editCustomer') : t('addCustomer')}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>رمز العميل *</Label>
                  <Input
                    value={currentCustomer.customer_code}
                    onChange={(e) => setCurrentCustomer({...currentCustomer, customer_code: e.target.value})}
                    required
                    disabled={editMode}
                    placeholder="مثال: C001"
                    className="font-mono"
                    data-testid="customer-code-input"
                  />
                </div>
                <div>
                  <Label>الرقم الضريبي (VAT)</Label>
                  <Input
                    value={currentCustomer.tax_number}
                    onChange={(e) => setCurrentCustomer({...currentCustomer, tax_number: e.target.value})}
                    placeholder="مثال: 300012345600003"
                    className="font-mono"
                    data-testid="customer-tax-number-input"
                  />
                </div>
              </div>
              
              <div>
                <Label>اسم العميل *</Label>
                <Input
                  value={currentCustomer.customer_name}
                  onChange={(e) => setCurrentCustomer({...currentCustomer, customer_name: e.target.value})}
                  required
                  placeholder="اسم الشركة أو العميل"
                  data-testid="customer-name-input"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>{t('phone')}</Label>
                  <Input
                    value={currentCustomer.phone}
                    onChange={(e) => setCurrentCustomer({...currentCustomer, phone: e.target.value})}
                    placeholder="+966 5X XXX XXXX"
                    data-testid="customer-phone-input"
                  />
                </div>
                <div>
                  <Label>{t('email')}</Label>
                  <Input
                    type="email"
                    value={currentCustomer.email}
                    onChange={(e) => setCurrentCustomer({...currentCustomer, email: e.target.value})}
                    placeholder="email@example.com"
                    data-testid="customer-email-input"
                  />
                </div>
              </div>
              
              <div>
                <Label>{t('address')}</Label>
                <Input
                  value={currentCustomer.address}
                  onChange={(e) => setCurrentCustomer({...currentCustomer, address: e.target.value})}
                  placeholder="العنوان الكامل"
                  data-testid="customer-address-input"
                />
              </div>
              
              <div className="flex justify-end gap-2 pt-4 border-t">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  {t('cancel')}
                </Button>
                <Button type="submit" className="bg-emerald hover:bg-emerald-hover" data-testid="save-customer-button">
                  {t('save')}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card className="p-4">
        <div className="relative">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="بحث بالاسم أو الرمز أو الرقم الضريبي..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="ps-9"
            data-testid="search-customers-input"
          />
        </div>
      </Card>

      <Card className="border border-border/60">
        <div className="overflow-x-auto">
          <table className="w-full" data-testid="customers-table">
            <thead className="bg-muted">
              <tr>
                <th className="px-4 py-3 text-start">رمز العميل</th>
                <th className="px-4 py-3 text-start">اسم العميل</th>
                <th className="px-4 py-3 text-start">الرقم الضريبي</th>
                <th className="px-4 py-3 text-start">{t('phone')}</th>
                <th className="px-4 py-3 text-start">{t('email')}</th>
                <th className="px-4 py-3 text-start">{t('actions')}</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.map((customer) => (
                <tr key={customer.customer_code} className="border-b border-border hover:bg-muted/30" data-testid={`customer-row-${customer.customer_code}`}>
                  <td className="px-4 py-3 font-mono">{customer.customer_code}</td>
                  <td className="px-4 py-3 font-medium">{customer.customer_name}</td>
                  <td className="px-4 py-3 font-mono text-sm">{customer.tax_number || '-'}</td>
                  <td className="px-4 py-3">{customer.phone || '-'}</td>
                  <td className="px-4 py-3">{customer.email || '-'}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <Button size="icon" variant="ghost" onClick={() => openEditDialog(customer)} data-testid={`edit-customer-${customer.customer_code}`}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => handleDelete(customer.customer_code)} data-testid={`delete-customer-${customer.customer_code}`}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredCustomers.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              {searchTerm ? 'لا توجد نتائج للبحث' : t('noData')}
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
