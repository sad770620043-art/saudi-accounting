import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../utils/api';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { toast } from 'sonner';
import { Plus, Trash2, Eye, Printer, Search } from 'lucide-react';
import { formatDate } from '../utils/exportHelpers';
import { PrintJournalEntry } from '../components/PrintTemplates';
import { AccountCombobox } from '../components/AccountCombobox';

export default function JournalEntries() {
  const { t, i18n } = useTranslation();
  const [entries, setEntries] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState(null);
  const [printEntry, setPrintEntry] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [loadingNextNumber, setLoadingNextNumber] = useState(false);
  
  const [newEntry, setNewEntry] = useState({
    entry_number: '',
    entry_date: formatDate(new Date()),
    description: '',
    lines: [
      { account_code: '', description: '', debit: 0, credit: 0 }
    ]
  });

  useEffect(() => {
    loadEntries();
    loadAccounts();
  }, []);

  const loadEntries = async () => {
    try {
      const response = await api.get('/journal-entries');
      setEntries(response.data);
    } catch (error) {
      toast.error(t('error'));
    } finally {
      setLoading(false);
    }
  };

  const loadAccounts = async () => {
    try {
      const response = await api.get('/accounts');
      setAccounts(response.data);
    } catch (error) {
      console.error('Error loading accounts');
    }
  };

  const loadNextEntryNumber = async () => {
    setLoadingNextNumber(true);
    try {
      const response = await api.get('/journal-entries/next-number');
      setNewEntry(prev => ({ ...prev, entry_number: response.data.next_number }));
    } catch (error) {
      console.error('Error loading next entry number');
    } finally {
      setLoadingNextNumber(false);
    }
  };

  const handleOpenDialog = () => {
    resetForm();
    loadNextEntryNumber();
    setDialogOpen(true);
  };

  // Handle when a new account is added from within the form
  const handleAccountAdded = (newAccount) => {
    // Add the new account to the local state immediately
    setAccounts(prev => [...prev, newAccount]);
  };

  const addLine = () => {
    setNewEntry({
      ...newEntry,
      lines: [...newEntry.lines, { account_code: '', description: '', debit: 0, credit: 0 }]
    });
  };

  const removeLine = (index) => {
    if (newEntry.lines.length > 1) {
      const newLines = newEntry.lines.filter((_, i) => i !== index);
      setNewEntry({ ...newEntry, lines: newLines });
    }
  };

  const updateLine = (index, field, value) => {
    const newLines = [...newEntry.lines];
    newLines[index][field] = value;
    setNewEntry({ ...newEntry, lines: newLines });
  };

  const calculateTotals = () => {
    const totalDebit = newEntry.lines.reduce((sum, line) => sum + (parseFloat(line.debit) || 0), 0);
    const totalCredit = newEntry.lines.reduce((sum, line) => sum + (parseFloat(line.credit) || 0), 0);
    return { totalDebit, totalCredit };
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { totalDebit, totalCredit } = calculateTotals();
    
    // Validate all lines have account selected
    const invalidLines = newEntry.lines.filter(line => !line.account_code);
    if (invalidLines.length > 0) {
      toast.error('يجب اختيار حساب لكل بند');
      return;
    }
    
    if (Math.abs(totalDebit - totalCredit) > 0.01) {
      toast.error('المدين والدائن يجب أن يكونا متساويين');
      return;
    }

    try {
      await api.post('/journal-entries', {
        ...newEntry,
        total_debit: totalDebit,
        total_credit: totalCredit,
        entry_date: new Date(newEntry.entry_date).toISOString()
      });
      toast.success(t('successfullySaved'));
      setDialogOpen(false);
      loadEntries();
      resetForm();
    } catch (error) {
      toast.error(error.response?.data?.detail || t('error'));
    }
  };

  const resetForm = () => {
    setNewEntry({
      entry_number: '',
      entry_date: formatDate(new Date()),
      description: '',
      lines: [{ account_code: '', description: '', debit: 0, credit: 0 }]
    });
  };

  const viewEntry = (entry) => {
    setSelectedEntry(entry);
    setViewDialogOpen(true);
  };

  const getAccountName = (accountCode) => {
    const account = accounts.find(a => a.account_code === accountCode);
    if (!account) return accountCode;
    return i18n.language === 'ar' ? account.account_name_ar : account.account_name_en;
  };

  // Filter entries based on search term
  const filteredEntries = entries.filter(entry => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      entry.entry_number?.toLowerCase().includes(term) ||
      entry.description?.toLowerCase().includes(term) ||
      formatDate(entry.entry_date).includes(term)
    );
  });

  const { totalDebit, totalCredit } = calculateTotals();

  if (printEntry) {
    return <PrintJournalEntry entry={printEntry} accounts={accounts} onClose={() => setPrintEntry(null)} />;
  }
  if (loading) {
    return <div className="text-center py-12">{t('loading')}</div>;
  }

  return (
    <div className="space-y-6" data-testid="journal-entries-container">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">{t('journalEntries')}</h1>
        
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald hover:bg-emerald-hover" onClick={handleOpenDialog} data-testid="add-journal-entry-button">
              <Plus className="h-4 w-4 me-2" />
              {t('addJournalEntry')}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{t('addJournalEntry')}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>{t('entryNumber')}</Label>
                  <Input
                    value={loadingNextNumber ? 'جاري التحميل...' : newEntry.entry_number}
                    readOnly
                    className="bg-muted"
                    data-testid="entry-number-input"
                  />
                  <p className="text-xs text-muted-foreground mt-1">يتم توليد الرقم تلقائياً</p>
                </div>
                <div>
                  <Label>{t('entryDate')}</Label>
                  <Input
                    type="date"
                    value={newEntry.entry_date}
                    onChange={(e) => setNewEntry({...newEntry, entry_date: e.target.value})}
                    required
                    data-testid="entry-date-input"
                  />
                </div>
              </div>
              
              <div>
                <Label>{t('description')}</Label>
                <Input
                  value={newEntry.description}
                  onChange={(e) => setNewEntry({...newEntry, description: e.target.value})}
                  required
                  data-testid="entry-description-input"
                />
              </div>

              <div className="border-t pt-4">
                <div className="flex justify-between items-center mb-3">
                  <h3 className="font-semibold">{t('items')}</h3>
                  <Button type="button" variant="outline" size="sm" onClick={addLine} data-testid="add-line-button">
                    <Plus className="h-4 w-4 me-2" />
                    {t('addLine')}
                  </Button>
                </div>

                <div className="space-y-3">
                  {newEntry.lines.map((line, index) => (
                    <div key={index} className="grid grid-cols-12 gap-2 p-3 border rounded-md bg-muted/30" data-testid={`entry-line-${index}`}>
                      <div className="col-span-4">
                        <Label className="text-xs text-muted-foreground mb-1 block">{t('accountCode')}</Label>
                        <AccountCombobox
                          accounts={accounts}
                          value={line.account_code}
                          onSelect={(value) => updateLine(index, 'account_code', value)}
                          placeholder={t('accountCode')}
                          language={i18n.language}
                          onAccountAdded={handleAccountAdded}
                        />
                      </div>
                      <div className="col-span-3">
                        <Label className="text-xs text-muted-foreground mb-1 block">{t('description')}</Label>
                        <Input
                          placeholder={t('description')}
                          value={line.description}
                          onChange={(e) => updateLine(index, 'description', e.target.value)}
                        />
                      </div>
                      <div className="col-span-2">
                        <Label className="text-xs text-muted-foreground mb-1 block">{t('debit')}</Label>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="0.00"
                          value={line.debit || ''}
                          onChange={(e) => updateLine(index, 'debit', parseFloat(e.target.value) || 0)}
                          className="text-end"
                        />
                      </div>
                      <div className="col-span-2">
                        <Label className="text-xs text-muted-foreground mb-1 block">{t('credit')}</Label>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="0.00"
                          value={line.credit || ''}
                          onChange={(e) => updateLine(index, 'credit', parseFloat(e.target.value) || 0)}
                          className="text-end"
                        />
                      </div>
                      <div className="col-span-1 flex items-end pb-1">
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeLine(index)}
                          disabled={newEntry.lines.length === 1}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-4 p-3 bg-muted rounded-md">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <span className="font-semibold">{t('totalDebit')}: </span>
                      <span className="text-lg" data-testid="total-debit">{totalDebit.toFixed(2)} SAR</span>
                    </div>
                    <div>
                      <span className="font-semibold">{t('totalCredit')}: </span>
                      <span className="text-lg" data-testid="total-credit">{totalCredit.toFixed(2)} SAR</span>
                    </div>
                  </div>
                  {Math.abs(totalDebit - totalCredit) > 0.01 && (
                    <div className="mt-2 text-destructive text-sm font-medium">
                      المدين والدائن غير متساويين! الفرق: {Math.abs(totalDebit - totalCredit).toFixed(2)} SAR
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  {t('cancel')}
                </Button>
                <Button type="submit" className="bg-emerald hover:bg-emerald-hover" data-testid="save-entry-button">
                  {t('save')}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search Bar */}
      <Card className="p-4">
        <div className="relative">
          <Search className="absolute start-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="بحث بالرقم أو الوصف..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="ps-10"
            data-testid="search-entries-input"
          />
        </div>
      </Card>

      <Card className="border border-border/60">
        <div className="overflow-x-auto">
          <table className="w-full" data-testid="entries-table">
            <thead className="bg-muted">
              <tr>
                <th className="px-4 py-3 text-start">{t('entryNumber')}</th>
                <th className="px-4 py-3 text-start">{t('entryDate')}</th>
                <th className="px-4 py-3 text-start">{t('description')}</th>
                <th className="px-4 py-3 text-end">{t('totalDebit')}</th>
                <th className="px-4 py-3 text-end">{t('totalCredit')}</th>
                <th className="px-4 py-3 text-start">{t('actions')}</th>
              </tr>
            </thead>
            <tbody>
              {filteredEntries.map((entry) => (
                <tr key={entry.entry_number} className="border-b border-border hover:bg-muted/30" data-testid={`entry-row-${entry.entry_number}`}>
                  <td className="px-4 py-3">{entry.entry_number}</td>
                  <td className="px-4 py-3">{formatDate(entry.entry_date)}</td>
                  <td className="px-4 py-3">{entry.description}</td>
                  <td className="px-4 py-3 text-end">{entry.total_debit?.toFixed(2)}</td>
                  <td className="px-4 py-3 text-end">{entry.total_credit?.toFixed(2)}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <Button size="icon" variant="ghost" onClick={() => viewEntry(entry)} data-testid={`view-entry-${entry.entry_number}`}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => setPrintEntry(entry)} data-testid={`print-entry-${entry.entry_number}`}>
                        <Printer className="h-4 w-4 text-emerald" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredEntries.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              {searchTerm ? 'لا توجد نتائج للبحث' : t('noData')}
            </div>
          )}
        </div>
      </Card>

      {/* View Entry Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>عرض القيد - {selectedEntry?.entry_number}</DialogTitle>
          </DialogHeader>
          {selectedEntry && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="font-semibold">رقم القيد: </span>
                  {selectedEntry.entry_number}
                </div>
                <div>
                  <span className="font-semibold">التاريخ: </span>
                  {formatDate(selectedEntry.entry_date)}
                </div>
              </div>
              <div>
                <span className="font-semibold">الوصف: </span>
                {selectedEntry.description}
              </div>
              <div>
                <h4 className="font-semibold mb-2">البنود:</h4>
                <table className="w-full border">
                  <thead className="bg-muted">
                    <tr>
                      <th className="px-3 py-2 text-start">رمز الحساب</th>
                      <th className="px-3 py-2 text-start">اسم الحساب</th>
                      <th className="px-3 py-2 text-start">الوصف</th>
                      <th className="px-3 py-2 text-end">مدين</th>
                      <th className="px-3 py-2 text-end">دائن</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedEntry.lines?.map((line, idx) => (
                      <tr key={idx} className="border-b">
                        <td className="px-3 py-2">{line.account_code}</td>
                        <td className="px-3 py-2">{getAccountName(line.account_code)}</td>
                        <td className="px-3 py-2">{line.description}</td>
                        <td className="px-3 py-2 text-end">{line.debit?.toFixed(2)}</td>
                        <td className="px-3 py-2 text-end">{line.credit?.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
