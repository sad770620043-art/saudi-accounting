import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../utils/api';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { toast } from 'sonner';
import { Plus, Trash2, Save, RotateCcw, FileText, Paperclip, Copy, History, ChevronDown, Search, Check, X } from 'lucide-react';
import { formatDate, formatCurrency } from '../utils/exportHelpers';
import { cn } from '../lib/utils';

// Inline Account Search Component for table cells
function AccountSearchCell({ accounts, value, onChange, language }) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const inputRef = useRef(null);
  const dropdownRef = useRef(null);

  const selectedAccount = accounts.find(a => a.account_code === value);
  
  const filteredAccounts = accounts.filter(account => {
    if (!search) return true;
    const s = search.toLowerCase();
    return account.account_code.toLowerCase().includes(s) ||
           account.account_name_ar.toLowerCase().includes(s) ||
           account.account_name_en.toLowerCase().includes(s);
  });

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (accountCode) => {
    onChange(accountCode);
    setIsOpen(false);
    setSearch('');
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <div
        className="flex items-center gap-1 min-h-[36px] px-2 py-1 border rounded cursor-pointer hover:border-emerald bg-background"
        onClick={() => setIsOpen(!isOpen)}
      >
        {selectedAccount ? (
          <span className="text-sm truncate">
            {selectedAccount.account_code} - {language === 'ar' ? selectedAccount.account_name_ar : selectedAccount.account_name_en}
          </span>
        ) : (
          <span className="text-sm text-muted-foreground">اختر الحساب...</span>
        )}
        <ChevronDown className="h-4 w-4 ms-auto text-muted-foreground" />
      </div>
      
      {isOpen && (
        <div className="absolute z-50 mt-1 w-[350px] bg-popover border rounded-md shadow-lg">
          <div className="p-2 border-b">
            <div className="relative">
              <Search className="absolute start-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                ref={inputRef}
                type="text"
                placeholder="ابحث بالرقم أو الاسم..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full ps-8 pe-2 py-2 text-sm border rounded focus:outline-none focus:ring-1 focus:ring-emerald"
                autoFocus
              />
            </div>
          </div>
          <div className="max-h-[250px] overflow-y-auto">
            {filteredAccounts.length === 0 ? (
              <div className="p-4 text-center text-sm text-muted-foreground">لا توجد نتائج</div>
            ) : (
              filteredAccounts.map((account) => (
                <div
                  key={account.account_code}
                  className={cn(
                    "flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-muted text-sm",
                    value === account.account_code && "bg-emerald/10"
                  )}
                  onClick={() => handleSelect(account.account_code)}
                >
                  {value === account.account_code && <Check className="h-4 w-4 text-emerald" />}
                  <span className="font-medium">{account.account_code}</span>
                  <span className="text-muted-foreground">-</span>
                  <span className="truncate">{language === 'ar' ? account.account_name_ar : account.account_name_en}</span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function EasyEntries() {
  const { t, i18n } = useTranslation();
  const [accounts, setAccounts] = useState([]);
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  // Entry form state
  const [entryData, setEntryData] = useState({
    entry_number: '',
    entry_date: formatDate(new Date()),
    reference: '',
    description: '',
    lines: [
      { account_code: '', description: '', cost_center: '', debit: '', credit: '' },
      { account_code: '', description: '', cost_center: '', debit: '', credit: '' }
    ]
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [accountsRes, entriesRes] = await Promise.all([
        api.get('/accounts'),
        api.get('/journal-entries')
      ]);
      setAccounts(accountsRes.data);
      setEntries(entriesRes.data);
      
      // Generate next entry number
      const lastEntry = entriesRes.data[entriesRes.data.length - 1];
      const nextNum = lastEntry ? parseInt(lastEntry.entry_number.replace(/\D/g, '')) + 1 : 1;
      setEntryData(prev => ({
        ...prev,
        entry_number: `JE${String(nextNum).padStart(4, '0')}`
      }));
    } catch (error) {
      toast.error('حدث خطأ في تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  const addLine = () => {
    setEntryData(prev => ({
      ...prev,
      lines: [...prev.lines, { account_code: '', description: '', cost_center: '', debit: '', credit: '' }]
    }));
  };

  const removeLine = (index) => {
    if (entryData.lines.length > 2) {
      setEntryData(prev => ({
        ...prev,
        lines: prev.lines.filter((_, i) => i !== index)
      }));
    }
  };

  const updateLine = (index, field, value) => {
    setEntryData(prev => {
      const newLines = [...prev.lines];
      newLines[index] = { ...newLines[index], [field]: value };
      
      // Auto clear the opposite field when entering a value
      if (field === 'debit' && value) {
        newLines[index].credit = '';
      } else if (field === 'credit' && value) {
        newLines[index].debit = '';
      }
      
      return { ...prev, lines: newLines };
    });
  };

  const calculateTotals = () => {
    const totalDebit = entryData.lines.reduce((sum, line) => sum + (parseFloat(line.debit) || 0), 0);
    const totalCredit = entryData.lines.reduce((sum, line) => sum + (parseFloat(line.credit) || 0), 0);
    const difference = totalDebit - totalCredit;
    return { totalDebit, totalCredit, difference, isBalanced: Math.abs(difference) < 0.01 };
  };

  const handleSave = async () => {
    const { totalDebit, totalCredit, isBalanced } = calculateTotals();
    
    // Validation
    const filledLines = entryData.lines.filter(l => l.account_code && (l.debit || l.credit));
    if (filledLines.length < 2) {
      toast.error('يجب إدخال بندين على الأقل');
      return;
    }
    
    if (!isBalanced) {
      toast.error('القيد غير متوازن - المدين لا يساوي الدائن');
      return;
    }

    if (!entryData.entry_number || !entryData.entry_date) {
      toast.error('يجب إدخال رقم القيد والتاريخ');
      return;
    }

    setSaving(true);
    try {
      await api.post('/journal-entries', {
        entry_number: entryData.entry_number,
        entry_date: new Date(entryData.entry_date).toISOString(),
        reference: entryData.reference,
        description: entryData.description,
        lines: filledLines.map(l => ({
          account_code: l.account_code,
          description: l.description,
          debit: parseFloat(l.debit) || 0,
          credit: parseFloat(l.credit) || 0
        })),
        total_debit: totalDebit,
        total_credit: totalCredit
      });
      
      toast.success('تم حفظ القيد بنجاح');
      
      // Reset form and generate new number
      const nextNum = parseInt(entryData.entry_number.replace(/\D/g, '')) + 1;
      setEntryData({
        entry_number: `JE${String(nextNum).padStart(4, '0')}`,
        entry_date: formatDate(new Date()),
        reference: '',
        description: '',
        lines: [
          { account_code: '', description: '', cost_center: '', debit: '', credit: '' },
          { account_code: '', description: '', cost_center: '', debit: '', credit: '' }
        ]
      });
      
      loadData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'حدث خطأ في حفظ القيد');
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    const currentNum = entryData.entry_number;
    setEntryData({
      entry_number: currentNum,
      entry_date: formatDate(new Date()),
      reference: '',
      description: '',
      lines: [
        { account_code: '', description: '', cost_center: '', debit: '', credit: '' },
        { account_code: '', description: '', cost_center: '', debit: '', credit: '' }
      ]
    });
  };

  const { totalDebit, totalCredit, difference, isBalanced } = calculateTotals();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-xl text-muted-foreground">جاري التحميل...</div>
      </div>
    );
  }

  return (
    <div className="space-y-4" data-testid="easy-entries-page">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">القيود السريعة</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleReset}>
            <RotateCcw className="h-4 w-4 me-1" />
            مسح
          </Button>
          <Button 
            className="bg-emerald hover:bg-emerald-hover" 
            size="sm" 
            onClick={handleSave}
            disabled={saving || !isBalanced}
            data-testid="save-entry-btn"
          >
            <Save className="h-4 w-4 me-1" />
            {saving ? 'جاري الحفظ...' : 'حفظ القيد'}
          </Button>
        </div>
      </div>

      {/* Entry Header Card */}
      <Card className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-1 block">رقم القيد</label>
            <Input
              value={entryData.entry_number}
              onChange={(e) => setEntryData(prev => ({ ...prev, entry_number: e.target.value }))}
              className="font-mono"
              data-testid="entry-number"
            />
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-1 block">التاريخ</label>
            <Input
              type="date"
              value={entryData.entry_date}
              onChange={(e) => setEntryData(prev => ({ ...prev, entry_date: e.target.value }))}
              data-testid="entry-date"
            />
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-1 block">المرجع</label>
            <Input
              value={entryData.reference}
              onChange={(e) => setEntryData(prev => ({ ...prev, reference: e.target.value }))}
              placeholder="رقم الفاتورة، السند..."
            />
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-1 block">الوصف</label>
            <Input
              value={entryData.description}
              onChange={(e) => setEntryData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="وصف القيد..."
            />
          </div>
        </div>
      </Card>

      {/* Entry Lines Table */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full" data-testid="entry-lines-table">
            <thead className="bg-muted/50">
              <tr>
                <th className="w-10 px-2 py-3 text-center text-xs font-medium text-muted-foreground">#</th>
                <th className="min-w-[280px] px-2 py-3 text-start text-xs font-medium text-muted-foreground">الحساب</th>
                <th className="min-w-[180px] px-2 py-3 text-start text-xs font-medium text-muted-foreground">البيان</th>
                <th className="w-[120px] px-2 py-3 text-center text-xs font-medium text-muted-foreground">مركز التكلفة</th>
                <th className="w-[140px] px-2 py-3 text-center text-xs font-medium text-muted-foreground">مدين</th>
                <th className="w-[140px] px-2 py-3 text-center text-xs font-medium text-muted-foreground">دائن</th>
                <th className="w-12 px-2 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {entryData.lines.map((line, index) => (
                <tr key={index} className="border-b border-border hover:bg-muted/30" data-testid={`line-${index}`}>
                  <td className="px-2 py-2 text-center text-sm text-muted-foreground">{index + 1}</td>
                  <td className="px-2 py-2">
                    <AccountSearchCell
                      accounts={accounts}
                      value={line.account_code}
                      onChange={(val) => updateLine(index, 'account_code', val)}
                      language={i18n.language}
                    />
                  </td>
                  <td className="px-2 py-2">
                    <Input
                      value={line.description}
                      onChange={(e) => updateLine(index, 'description', e.target.value)}
                      placeholder="البيان..."
                      className="h-9"
                    />
                  </td>
                  <td className="px-2 py-2">
                    <Input
                      value={line.cost_center}
                      onChange={(e) => updateLine(index, 'cost_center', e.target.value)}
                      placeholder="-"
                      className="h-9 text-center"
                    />
                  </td>
                  <td className="px-2 py-2">
                    <Input
                      type="number"
                      step="0.01"
                      value={line.debit}
                      onChange={(e) => updateLine(index, 'debit', e.target.value)}
                      placeholder="0.00"
                      className="h-9 text-center font-mono"
                      dir="ltr"
                    />
                  </td>
                  <td className="px-2 py-2">
                    <Input
                      type="number"
                      step="0.01"
                      value={line.credit}
                      onChange={(e) => updateLine(index, 'credit', e.target.value)}
                      placeholder="0.00"
                      className="h-9 text-center font-mono"
                      dir="ltr"
                    />
                  </td>
                  <td className="px-2 py-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => removeLine(index)}
                      disabled={entryData.lines.length <= 2}
                    >
                      <X className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-muted/30">
              <tr>
                <td colSpan="4" className="px-2 py-3">
                  <Button variant="ghost" size="sm" onClick={addLine} className="text-emerald hover:text-emerald-hover">
                    <Plus className="h-4 w-4 me-1" />
                    إضافة سطر
                  </Button>
                </td>
                <td className="px-2 py-3">
                  <div className="text-center">
                    <span className="text-xs text-muted-foreground block">إجمالي المدين</span>
                    <span className="font-bold font-mono text-lg" dir="ltr">{formatCurrency(totalDebit)}</span>
                  </div>
                </td>
                <td className="px-2 py-3">
                  <div className="text-center">
                    <span className="text-xs text-muted-foreground block">إجمالي الدائن</span>
                    <span className="font-bold font-mono text-lg" dir="ltr">{formatCurrency(totalCredit)}</span>
                  </div>
                </td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
        
        {/* Balance Status */}
        <div className={cn(
          "px-4 py-3 border-t flex items-center justify-between",
          isBalanced ? "bg-green-50 dark:bg-green-950" : "bg-red-50 dark:bg-red-950"
        )}>
          <div className="flex items-center gap-2">
            {isBalanced ? (
              <>
                <Check className="h-5 w-5 text-green-600" />
                <span className="text-green-700 dark:text-green-400 font-medium">القيد متوازن</span>
              </>
            ) : (
              <>
                <X className="h-5 w-5 text-red-600" />
                <span className="text-red-700 dark:text-red-400 font-medium">
                  القيد غير متوازن - الفرق: <span className="font-mono" dir="ltr">{formatCurrency(Math.abs(difference))}</span>
                </span>
              </>
            )}
          </div>
        </div>
      </Card>

      {/* Recent Entries */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold flex items-center gap-2">
            <History className="h-5 w-5" />
            آخر القيود
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50">
              <tr>
                <th className="px-3 py-2 text-start">رقم القيد</th>
                <th className="px-3 py-2 text-start">التاريخ</th>
                <th className="px-3 py-2 text-start">الوصف</th>
                <th className="px-3 py-2 text-end">المدين</th>
                <th className="px-3 py-2 text-end">الدائن</th>
              </tr>
            </thead>
            <tbody>
              {entries.slice(-5).reverse().map((entry) => (
                <tr key={entry.entry_number} className="border-b hover:bg-muted/30">
                  <td className="px-3 py-2 font-mono">{entry.entry_number}</td>
                  <td className="px-3 py-2">{formatDate(entry.entry_date)}</td>
                  <td className="px-3 py-2 truncate max-w-[200px]">{entry.description}</td>
                  <td className="px-3 py-2 text-end font-mono" dir="ltr">{formatCurrency(entry.total_debit)}</td>
                  <td className="px-3 py-2 text-end font-mono" dir="ltr">{formatCurrency(entry.total_credit)}</td>
                </tr>
              ))}
              {entries.length === 0 && (
                <tr>
                  <td colSpan="5" className="px-3 py-8 text-center text-muted-foreground">
                    لا توجد قيود سابقة
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
