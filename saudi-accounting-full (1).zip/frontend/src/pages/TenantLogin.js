import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import api, { setTenantContext } from '../utils/api';
import { useAuth } from '../contexts/AuthContext';

export default function TenantLogin() {
  const { tenantId } = useParams();
  const navigate = useNavigate();
  const { login, setTenant } = useAuth();
  const [tenantInfo, setTenantInfo] = useState(null);
  const [loginData, setLoginData] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [loginLoading, setLoginLoading] = useState(false);

  useEffect(() => {
    loadTenantInfo();
  }, [tenantId]);

  const loadTenantInfo = async () => {
    try {
      const res = await api.get('/tenant/info', {
        headers: { 'X-Tenant-ID': tenantId }
      });
      setTenantInfo(res.data);
      
      // Check if license is expired
      if (res.data.license_expiry) {
        const expiry = new Date(res.data.license_expiry);
        if (expiry < new Date()) {
          setError('انتهت صلاحية الترخيص. يرجى التواصل مع مزود الخدمة.');
        }
      }
    } catch (err) {
      if (err.response?.status === 404) {
        setError('النسخة غير موجودة');
      } else if (err.response?.status === 403) {
        setError(err.response?.data?.detail || 'النسخة معطلة أو منتهية الصلاحية');
      } else {
        setError('حدث خطأ في الاتصال');
      }
    }
    setLoading(false);
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoginLoading(true);
    
    try {
      const res = await api.post('/tenant/login', loginData, {
        headers: { 'X-Tenant-ID': tenantId }
      });
      
      // Set tenant context for all future API calls
      setTenantContext(tenantId);
      
      // Store token and tenant info using AuthContext
      login(res.data.token, {
        username: res.data.username,
        full_name: res.data.full_name
      }, {
        tenant_id: tenantId,
        ...tenantInfo
      });
      
      // Redirect to tenant dashboard
      navigate(`/tenant/${tenantId}/dashboard`);
    } catch (err) {
      setError(err.response?.data?.detail || 'بيانات الدخول غير صحيحة');
    }
    setLoginLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald"></div>
      </div>
    );
  }

  if (!tenantInfo && error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <h2 className="text-xl font-bold text-red-600 mb-2">خطأ</h2>
            <p className="text-gray-600">{error}</p>
            <Button 
              className="mt-4" 
              variant="outline"
              onClick={() => navigate('/')}
            >
              العودة للصفحة الرئيسية
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald/5 via-white to-blue-50 flex items-center justify-center p-4" dir="rtl">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center pb-2">
          {/* Company Logo or Icon */}
          <div className="mx-auto w-20 h-20 bg-gradient-to-br from-emerald to-emerald-hover rounded-2xl flex items-center justify-center mb-4 shadow-lg">
            <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>
          </div>
          
          <CardTitle className="text-2xl font-bold">{tenantInfo?.company_name_ar}</CardTitle>
          <p className="text-muted-foreground">{tenantInfo?.company_name_en}</p>
          
          <div className="mt-2">
            <span className="inline-block px-3 py-1 bg-emerald/10 text-emerald rounded-full text-sm">
              النظام المحاسبي السعودي
            </span>
          </div>
        </CardHeader>
        
        <CardContent className="pt-4">
          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm text-center mb-4">
              {error}
            </div>
          )}
          
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label>اسم المستخدم</Label>
              <Input
                data-testid="tenant-username-input"
                value={loginData.username}
                onChange={(e) => setLoginData({...loginData, username: e.target.value})}
                placeholder="admin"
                required
                className="mt-1"
              />
            </div>
            
            <div>
              <Label>كلمة المرور</Label>
              <Input
                data-testid="tenant-password-input"
                type="password"
                value={loginData.password}
                onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                required
                className="mt-1"
              />
            </div>
            
            <Button 
              type="submit" 
              className="w-full bg-emerald hover:bg-emerald-hover"
              disabled={loginLoading}
              data-testid="tenant-login-button"
            >
              {loginLoading ? (
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              ) : (
                <>
                  <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                  </svg>
                  تسجيل الدخول
                </>
              )}
            </Button>
          </form>
          
          <div className="mt-6 pt-4 border-t text-center text-sm text-muted-foreground">
            <p>نسخة رقم: <code className="bg-gray-100 px-2 py-0.5 rounded">{tenantId}</code></p>
            {tenantInfo?.license_expiry && (
              <p className="mt-1">
                صلاحية الترخيص: {new Date(tenantInfo.license_expiry).toLocaleDateString('ar-SA')}
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
