import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Badge } from '../components/ui/badge';
import api, { setTenantContext } from '../utils/api';
import { useAuth } from '../contexts/AuthContext';

// Statistics Card Component
const StatCard = ({ title, value, icon, color, subtext }) => (
  <Card className="relative overflow-hidden">
    <div className={`absolute top-0 right-0 w-24 h-24 ${color} opacity-10 rounded-full -mr-8 -mt-8`}></div>
    <CardContent className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">{title}</p>
          <p className="text-3xl font-bold mt-1">{value}</p>
          {subtext && <p className="text-xs text-muted-foreground mt-1">{subtext}</p>}
        </div>
        <div className={`p-3 rounded-full ${color}`}>
          {icon}
        </div>
      </div>
    </CardContent>
  </Card>
);

// Tenant Form Component
const TenantForm = ({ tenant, onSave, onClose }) => {
  const [formData, setFormData] = useState(tenant || {
    company_name_ar: '',
    company_name_en: '',
    contact_person: '',
    phone: '',
    email: '',
    license_type: 'standard',
    license_expiry: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    max_users: 5,
    features: [],
    notes: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await onSave(formData);
  };

  const featureOptions = [
    { id: 'invoices', label: 'الفواتير' },
    { id: 'vouchers', label: 'السندات' },
    { id: 'reports', label: 'التقارير' },
    { id: 'financial_statements', label: 'القوائم المالية' },
    { id: 'multi_users', label: 'تعدد المستخدمين' },
    { id: 'export', label: 'التصدير' },
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>اسم الشركة (عربي) *</Label>
          <Input
            value={formData.company_name_ar}
            onChange={(e) => setFormData({...formData, company_name_ar: e.target.value})}
            required
          />
        </div>
        <div>
          <Label>اسم الشركة (إنجليزي)</Label>
          <Input
            value={formData.company_name_en}
            onChange={(e) => setFormData({...formData, company_name_en: e.target.value})}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>الشخص المسؤول *</Label>
          <Input
            value={formData.contact_person}
            onChange={(e) => setFormData({...formData, contact_person: e.target.value})}
            required
          />
        </div>
        <div>
          <Label>رقم الهاتف *</Label>
          <Input
            value={formData.phone}
            onChange={(e) => setFormData({...formData, phone: e.target.value})}
            required
          />
        </div>
      </div>

      <div>
        <Label>البريد الإلكتروني *</Label>
        <Input
          type="email"
          value={formData.email}
          onChange={(e) => setFormData({...formData, email: e.target.value})}
          required
        />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label>نوع الترخيص</Label>
          <Select
            value={formData.license_type}
            onValueChange={(value) => setFormData({...formData, license_type: value})}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="standard">عادي (Standard)</SelectItem>
              <SelectItem value="premium">مميز (Premium)</SelectItem>
              <SelectItem value="enterprise">مؤسسات (Enterprise)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>تاريخ انتهاء الترخيص *</Label>
          <Input
            type="date"
            value={formData.license_expiry}
            onChange={(e) => setFormData({...formData, license_expiry: e.target.value})}
            required
          />
        </div>
        <div>
          <Label>الحد الأقصى للمستخدمين</Label>
          <Input
            type="number"
            min="1"
            value={formData.max_users}
            onChange={(e) => setFormData({...formData, max_users: parseInt(e.target.value)})}
          />
        </div>
      </div>

      <div>
        <Label>الميزات المتاحة</Label>
        <div className="flex flex-wrap gap-2 mt-2">
          {featureOptions.map((feature) => (
            <label key={feature.id} className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.features?.includes(feature.id)}
                onChange={(e) => {
                  if (e.target.checked) {
                    setFormData({...formData, features: [...(formData.features || []), feature.id]});
                  } else {
                    setFormData({...formData, features: formData.features?.filter(f => f !== feature.id)});
                  }
                }}
                className="rounded"
              />
              <span className="text-sm">{feature.label}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <Label>ملاحظات</Label>
        <textarea
          className="w-full border rounded-lg p-2 min-h-[80px]"
          value={formData.notes}
          onChange={(e) => setFormData({...formData, notes: e.target.value})}
        />
      </div>

      <div className="flex justify-end gap-2 pt-4 border-t">
        <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
        <Button type="submit" className="bg-emerald hover:bg-emerald-hover">
          {tenant ? 'تحديث' : 'إضافة نسخة جديدة'}
        </Button>
      </div>
    </form>
  );
};

// Tenant Details Component - لعرض والتحكم ببيانات النسخة
const TenantDetails = ({ tenant, onClose }) => {
  const [activeTab, setActiveTab] = useState('invoices');
  const [data, setData] = useState({ invoices: [], vouchers: [], entries: [], customers: [] });
  const [loading, setLoading] = useState(true);
  const [editItem, setEditItem] = useState(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(null);

  useEffect(() => {
    loadTenantData();
  }, []);

  const loadTenantData = async () => {
    setLoading(true);
    try {
      const [invoicesRes, receiptsRes, paymentsRes, entriesRes, customersRes] = await Promise.all([
        api.get('/invoices'),
        api.get('/receipt-vouchers'),
        api.get('/payment-vouchers'),
        api.get('/journal-entries'),
        api.get('/customers')
      ]);
      setData({
        invoices: invoicesRes.data || [],
        receipts: receiptsRes.data || [],
        payments: paymentsRes.data || [],
        entries: entriesRes.data || [],
        customers: customersRes.data || []
      });
    } catch (err) {
      console.error('Error loading tenant data');
    }
    setLoading(false);
  };

  const handleDelete = async (type, id) => {
    try {
      const endpoints = {
        invoices: `/invoices/${id}`,
        receipts: `/receipt-vouchers/${id}`,
        payments: `/payment-vouchers/${id}`,
        entries: `/journal-entries/${id}`,
        customers: `/customers/${id}`
      };
      await api.delete(endpoints[type]);
      loadTenantData();
      setShowDeleteConfirm(null);
    } catch (err) {
      alert('حدث خطأ في الحذف');
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(amount || 0);
  };

  const formatDate = (date) => {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('ar-SA');
  };

  return (
    <div className="space-y-4">
      {/* Tenant Header */}
      <div className="bg-gradient-to-r from-emerald/10 to-blue-500/10 p-4 rounded-lg">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-xl font-bold">{tenant.company_name_ar}</h3>
            <p className="text-sm text-muted-foreground">{tenant.company_name_en}</p>
            <p className="text-sm mt-1">
              <Badge variant="outline" className="ml-2">{tenant.tenant_id}</Badge>
              <span className="text-muted-foreground">{tenant.email}</span>
            </p>
          </div>
          <div className="text-left">
            <Badge className={tenant.is_active ? 'bg-green-500' : 'bg-red-500'}>
              {tenant.is_active ? 'نشط' : 'معطل'}
            </Badge>
            <p className="text-sm mt-1">انتهاء الترخيص: {tenant.license_expiry}</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-5 gap-2">
        <div className="bg-blue-50 p-3 rounded-lg text-center">
          <p className="text-2xl font-bold text-blue-600">{data.invoices?.length || 0}</p>
          <p className="text-xs text-blue-600">فاتورة</p>
        </div>
        <div className="bg-green-50 p-3 rounded-lg text-center">
          <p className="text-2xl font-bold text-green-600">{data.receipts?.length || 0}</p>
          <p className="text-xs text-green-600">سند قبض</p>
        </div>
        <div className="bg-red-50 p-3 rounded-lg text-center">
          <p className="text-2xl font-bold text-red-600">{data.payments?.length || 0}</p>
          <p className="text-xs text-red-600">سند صرف</p>
        </div>
        <div className="bg-purple-50 p-3 rounded-lg text-center">
          <p className="text-2xl font-bold text-purple-600">{data.entries?.length || 0}</p>
          <p className="text-xs text-purple-600">قيد</p>
        </div>
        <div className="bg-orange-50 p-3 rounded-lg text-center">
          <p className="text-2xl font-bold text-orange-600">{data.customers?.length || 0}</p>
          <p className="text-xs text-orange-600">عميل</p>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="invoices">الفواتير</TabsTrigger>
          <TabsTrigger value="receipts">سندات القبض</TabsTrigger>
          <TabsTrigger value="payments">سندات الصرف</TabsTrigger>
          <TabsTrigger value="entries">القيود</TabsTrigger>
          <TabsTrigger value="customers">العملاء</TabsTrigger>
        </TabsList>

        {loading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald"></div>
          </div>
        ) : (
          <>
            {/* Invoices Tab */}
            <TabsContent value="invoices" className="mt-4">
              <div className="border rounded-lg overflow-hidden max-h-[300px] overflow-y-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="p-2 text-right">رقم الفاتورة</th>
                      <th className="p-2 text-right">التاريخ</th>
                      <th className="p-2 text-right">العميل</th>
                      <th className="p-2 text-right">المبلغ</th>
                      <th className="p-2 text-center">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.invoices?.map((inv) => (
                      <tr key={inv.invoice_id} className="border-t hover:bg-gray-50">
                        <td className="p-2">{inv.invoice_number}</td>
                        <td className="p-2">{formatDate(inv.invoice_date)}</td>
                        <td className="p-2">{inv.customer_code}</td>
                        <td className="p-2 font-mono">{formatCurrency(inv.total_amount)}</td>
                        <td className="p-2 text-center">
                          <Button size="sm" variant="ghost" className="text-red-500 h-7 px-2"
                            onClick={() => setShowDeleteConfirm({ type: 'invoices', id: inv.invoice_id, name: inv.invoice_number })}>
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                          </Button>
                        </td>
                      </tr>
                    ))}
                    {data.invoices?.length === 0 && (
                      <tr><td colSpan={5} className="p-4 text-center text-muted-foreground">لا توجد فواتير</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            {/* Receipts Tab */}
            <TabsContent value="receipts" className="mt-4">
              <div className="border rounded-lg overflow-hidden max-h-[300px] overflow-y-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="p-2 text-right">رقم السند</th>
                      <th className="p-2 text-right">التاريخ</th>
                      <th className="p-2 text-right">البيان</th>
                      <th className="p-2 text-right">المبلغ</th>
                      <th className="p-2 text-center">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.receipts?.map((v) => (
                      <tr key={v.voucher_id} className="border-t hover:bg-gray-50">
                        <td className="p-2">{v.voucher_number}</td>
                        <td className="p-2">{formatDate(v.voucher_date)}</td>
                        <td className="p-2">{v.description}</td>
                        <td className="p-2 font-mono text-green-600">{formatCurrency(v.amount)}</td>
                        <td className="p-2 text-center">
                          <Button size="sm" variant="ghost" className="text-red-500 h-7 px-2"
                            onClick={() => setShowDeleteConfirm({ type: 'receipts', id: v.voucher_id, name: v.voucher_number })}>
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                          </Button>
                        </td>
                      </tr>
                    ))}
                    {data.receipts?.length === 0 && (
                      <tr><td colSpan={5} className="p-4 text-center text-muted-foreground">لا توجد سندات قبض</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            {/* Payments Tab */}
            <TabsContent value="payments" className="mt-4">
              <div className="border rounded-lg overflow-hidden max-h-[300px] overflow-y-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="p-2 text-right">رقم السند</th>
                      <th className="p-2 text-right">التاريخ</th>
                      <th className="p-2 text-right">البيان</th>
                      <th className="p-2 text-right">المبلغ</th>
                      <th className="p-2 text-center">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.payments?.map((v) => (
                      <tr key={v.voucher_id} className="border-t hover:bg-gray-50">
                        <td className="p-2">{v.voucher_number}</td>
                        <td className="p-2">{formatDate(v.voucher_date)}</td>
                        <td className="p-2">{v.description}</td>
                        <td className="p-2 font-mono text-red-600">{formatCurrency(v.amount)}</td>
                        <td className="p-2 text-center">
                          <Button size="sm" variant="ghost" className="text-red-500 h-7 px-2"
                            onClick={() => setShowDeleteConfirm({ type: 'payments', id: v.voucher_id, name: v.voucher_number })}>
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                          </Button>
                        </td>
                      </tr>
                    ))}
                    {data.payments?.length === 0 && (
                      <tr><td colSpan={5} className="p-4 text-center text-muted-foreground">لا توجد سندات صرف</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            {/* Entries Tab */}
            <TabsContent value="entries" className="mt-4">
              <div className="border rounded-lg overflow-hidden max-h-[300px] overflow-y-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="p-2 text-right">رقم القيد</th>
                      <th className="p-2 text-right">التاريخ</th>
                      <th className="p-2 text-right">البيان</th>
                      <th className="p-2 text-right">المدين</th>
                      <th className="p-2 text-right">الدائن</th>
                      <th className="p-2 text-center">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.entries?.map((e) => (
                      <tr key={e.entry_id} className="border-t hover:bg-gray-50">
                        <td className="p-2">{e.entry_number}</td>
                        <td className="p-2">{formatDate(e.entry_date)}</td>
                        <td className="p-2">{e.description}</td>
                        <td className="p-2 font-mono">{formatCurrency(e.lines?.reduce((sum, l) => sum + (l.debit || 0), 0))}</td>
                        <td className="p-2 font-mono">{formatCurrency(e.lines?.reduce((sum, l) => sum + (l.credit || 0), 0))}</td>
                        <td className="p-2 text-center">
                          <Button size="sm" variant="ghost" className="text-red-500 h-7 px-2"
                            onClick={() => setShowDeleteConfirm({ type: 'entries', id: e.entry_id, name: e.entry_number })}>
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                          </Button>
                        </td>
                      </tr>
                    ))}
                    {data.entries?.length === 0 && (
                      <tr><td colSpan={6} className="p-4 text-center text-muted-foreground">لا توجد قيود</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            {/* Customers Tab */}
            <TabsContent value="customers" className="mt-4">
              <div className="border rounded-lg overflow-hidden max-h-[300px] overflow-y-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="p-2 text-right">اسم العميل</th>
                      <th className="p-2 text-right">الهاتف</th>
                      <th className="p-2 text-right">البريد</th>
                      <th className="p-2 text-right">الرقم الضريبي</th>
                      <th className="p-2 text-center">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.customers?.map((c) => (
                      <tr key={c.customer_id} className="border-t hover:bg-gray-50">
                        <td className="p-2 font-semibold">{c.customer_name}</td>
                        <td className="p-2">{c.phone || '-'}</td>
                        <td className="p-2">{c.email || '-'}</td>
                        <td className="p-2 font-mono">{c.tax_number || '-'}</td>
                        <td className="p-2 text-center">
                          <Button size="sm" variant="ghost" className="text-red-500 h-7 px-2"
                            onClick={() => setShowDeleteConfirm({ type: 'customers', id: c.customer_id, name: c.customer_name })}>
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                          </Button>
                        </td>
                      </tr>
                    ))}
                    {data.customers?.length === 0 && (
                      <tr><td colSpan={5} className="p-4 text-center text-muted-foreground">لا يوجد عملاء</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </TabsContent>
          </>
        )}
      </Tabs>

      {/* Delete Confirmation Dialog */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-sm w-full mx-4">
            <h3 className="text-lg font-bold text-red-600 mb-2">تأكيد الحذف</h3>
            <p className="text-muted-foreground mb-4">
              هل أنت متأكد من حذف "{showDeleteConfirm.name}"؟ لا يمكن التراجع عن هذا الإجراء.
            </p>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowDeleteConfirm(null)}>إلغاء</Button>
              <Button variant="destructive" onClick={() => handleDelete(showDeleteConfirm.type, showDeleteConfirm.id)}>
                حذف
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="flex justify-end pt-4 border-t">
        <Button variant="outline" onClick={onClose}>إغلاق</Button>
      </div>
    </div>
  );
};

// Main Component
export default function OwnerPanel() {
  const navigate = useNavigate();
  const { login, setTenant } = useAuth();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loginData, setLoginData] = useState({ username: '', password: '' });
  const [loginError, setLoginError] = useState('');
  const [tenants, setTenants] = useState([]);
  const [statistics, setStatistics] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingTenant, setEditingTenant] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewingTenant, setViewingTenant] = useState(null);

  // Check if already logged in
  useEffect(() => {
    const token = localStorage.getItem('owner_token');
    if (token) {
      setIsAuthenticated(true);
    }
  }, []);

  // Function to enter tenant dashboard as super admin
  const handleEnterTenantDashboard = async (tenant) => {
    try {
      // Login as admin for this tenant using default credentials
      const res = await api.post('/tenant/login', {
        username: 'admin',
        password: 'admin123'
      }, {
        headers: { 'X-Tenant-ID': tenant.tenant_id }
      });
      
      // Set tenant context
      setTenantContext(tenant.tenant_id);
      
      // Update auth context with tenant info
      login(res.data.token, {
        username: res.data.username,
        full_name: res.data.full_name
      }, {
        tenant_id: tenant.tenant_id,
        ...tenant
      });
      
      // Navigate to tenant dashboard
      navigate(`/tenant/${tenant.tenant_id}/dashboard`);
    } catch (err) {
      alert('فشل الدخول للنسخة: ' + (err.response?.data?.detail || 'خطأ غير معروف'));
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoginError('');
    try {
      const res = await api.post('/super-admin/login', loginData);
      localStorage.setItem('owner_token', res.data.token);
      setIsAuthenticated(true);
    } catch (err) {
      setLoginError('بيانات الدخول غير صحيحة');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('owner_token');
    setIsAuthenticated(false);
  };

  const loadTenants = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get('/super-admin/tenants');
      setTenants(res.data);
    } catch (err) {
      console.error('Error loading tenants');
    }
    setLoading(false);
  }, []);

  const loadStatistics = useCallback(async () => {
    try {
      const res = await api.get('/super-admin/statistics');
      setStatistics(res.data);
    } catch (err) {
      console.error('Error loading statistics');
    }
  }, []);

  const [licenseAlerts, setLicenseAlerts] = useState(null);

  const loadLicenseAlerts = useCallback(async () => {
    try {
      const res = await api.get('/super-admin/license-alerts');
      setLicenseAlerts(res.data);
    } catch (err) {
      console.error('Error loading license alerts');
    }
  }, []);

  useEffect(() => {
    if (isAuthenticated) {
      loadTenants();
      loadStatistics();
      loadLicenseAlerts();
    }
  }, [isAuthenticated, loadTenants, loadStatistics, loadLicenseAlerts]);

  const handleSaveTenant = async (formData) => {
    try {
      if (editingTenant) {
        await api.put(`/super-admin/tenants/${editingTenant.tenant_id}`, formData);
      } else {
        await api.post('/super-admin/tenants', formData);
      }
      setShowAddDialog(false);
      setEditingTenant(null);
      loadTenants();
      loadStatistics();
    } catch (err) {
      alert(err.response?.data?.detail || 'حدث خطأ');
    }
  };

  const handleToggleStatus = async (tenantId) => {
    try {
      await api.put(`/super-admin/tenants/${tenantId}/toggle-status`);
      loadTenants();
      loadStatistics();
    } catch (err) {
      alert('حدث خطأ');
    }
  };

  const handleExtendLicense = async (tenantId, days) => {
    try {
      await api.put(`/super-admin/tenants/${tenantId}/extend-license?days=${days}`);
      loadTenants();
    } catch (err) {
      alert('حدث خطأ');
    }
  };

  const handleDeleteTenant = async (tenantId) => {
    if (!window.confirm('هل أنت متأكد من حذف هذه النسخة؟ لا يمكن التراجع عن هذا الإجراء.')) return;
    try {
      await api.delete(`/super-admin/tenants/${tenantId}`);
      loadTenants();
      loadStatistics();
    } catch (err) {
      alert('حدث خطأ');
    }
  };

  const filteredTenants = tenants.filter(t => 
    t.company_name_ar?.includes(searchTerm) ||
    t.company_name_en?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.tenant_id?.includes(searchTerm) ||
    t.email?.includes(searchTerm)
  );

  // Login Screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-emerald rounded-full flex items-center justify-center mb-4">
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            <CardTitle className="text-2xl">لوحة تحكم المالك</CardTitle>
            <p className="text-muted-foreground">Owner Control Panel</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              {loginError && (
                <div className="bg-red-100 text-red-700 p-3 rounded-lg text-sm text-center">
                  {loginError}
                </div>
              )}
              <div>
                <Label>اسم المستخدم</Label>
                <Input
                  value={loginData.username}
                  onChange={(e) => setLoginData({...loginData, username: e.target.value})}
                  placeholder="owner"
                  required
                />
              </div>
              <div>
                <Label>كلمة المرور</Label>
                <Input
                  type="password"
                  value={loginData.password}
                  onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                  required
                />
              </div>
              <Button type="submit" className="w-full bg-emerald hover:bg-emerald-hover">
                دخول
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Main Dashboard
  return (
    <div className="min-h-screen bg-gray-100" dir="rtl">
      {/* Header */}
      <header className="bg-gray-900 text-white py-4 px-6">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
            </div>
            <div>
              <h1 className="text-xl font-bold">لوحة تحكم المالك</h1>
              <p className="text-gray-400 text-sm">إدارة نسخ النظام المحاسبي</p>
            </div>
          </div>
          <Button variant="ghost" onClick={handleLogout} className="text-white hover:bg-gray-800">
            <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
            </svg>
            خروج
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6">
        {/* Statistics */}
        {statistics && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatCard
              title="إجمالي النسخ"
              value={statistics.total_tenants}
              color="bg-blue-500"
              icon={<svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>}
            />
            <StatCard
              title="النسخ النشطة"
              value={statistics.active_tenants}
              color="bg-green-500"
              icon={<svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
            />
            <StatCard
              title="منتهية الصلاحية"
              value={statistics.expired_tenants}
              color="bg-red-500"
              icon={<svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
            />
            <StatCard
              title="تنتهي قريباً"
              value={statistics.expiring_soon}
              subtext="خلال 30 يوم"
              color="bg-yellow-500"
              icon={<svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>}
            />
          </div>
        )}

        {/* License Alerts Section */}
        {licenseAlerts && licenseAlerts.total_alerts > 0 && (
          <Card className="mb-6 border-orange-200 bg-orange-50/50">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-orange-500 rounded-lg">
                    <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                    </svg>
                  </div>
                  <div>
                    <CardTitle className="text-lg">تنبيهات التراخيص</CardTitle>
                    <p className="text-sm text-muted-foreground">
                      {licenseAlerts.critical > 0 && <span className="text-red-600 font-medium">{licenseAlerts.critical} منتهية</span>}
                      {licenseAlerts.critical > 0 && licenseAlerts.high > 0 && ' • '}
                      {licenseAlerts.high > 0 && <span className="text-orange-600 font-medium">{licenseAlerts.high} تنتهي خلال 7 أيام</span>}
                      {(licenseAlerts.critical > 0 || licenseAlerts.high > 0) && licenseAlerts.medium > 0 && ' • '}
                      {licenseAlerts.medium > 0 && <span className="text-yellow-600 font-medium">{licenseAlerts.medium} تنتهي خلال 30 يوم</span>}
                    </p>
                  </div>
                </div>
                <Badge variant="outline" className="bg-orange-100 text-orange-700 border-orange-300">
                  {licenseAlerts.total_alerts} تنبيه
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {licenseAlerts.alerts.map((alert, idx) => (
                  <div 
                    key={idx}
                    className={`flex items-center justify-between p-3 rounded-lg ${
                      alert.severity === 'critical' ? 'bg-red-100 border border-red-200' :
                      alert.severity === 'high' ? 'bg-orange-100 border border-orange-200' :
                      'bg-yellow-100 border border-yellow-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${
                        alert.severity === 'critical' ? 'bg-red-500 animate-pulse' :
                        alert.severity === 'high' ? 'bg-orange-500' :
                        'bg-yellow-500'
                      }`} />
                      <div>
                        <p className="font-medium">{alert.company_name_ar}</p>
                        <p className="text-sm text-muted-foreground">{alert.tenant_id}</p>
                      </div>
                    </div>
                    <div className="text-left">
                      <p className={`text-sm font-medium ${
                        alert.severity === 'critical' ? 'text-red-700' :
                        alert.severity === 'high' ? 'text-orange-700' :
                        'text-yellow-700'
                      }`}>
                        {alert.message_ar}
                      </p>
                      <p className="text-xs text-muted-foreground">انتهاء: {alert.license_expiry}</p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="ms-2"
                      onClick={() => handleExtendLicense(alert.tenant_id, 30)}
                    >
                      تجديد 30 يوم
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Main Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>إدارة النسخ</CardTitle>
            <div className="flex gap-2">
              <Input
                placeholder="بحث..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64"
              />
              <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-emerald hover:bg-emerald-hover">
                    <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                    إضافة نسخة جديدة
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>{editingTenant ? 'تعديل النسخة' : 'إضافة نسخة جديدة'}</DialogTitle>
                  </DialogHeader>
                  <TenantForm
                    tenant={editingTenant}
                    onSave={handleSaveTenant}
                    onClose={() => { setShowAddDialog(false); setEditingTenant(null); }}
                  />
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald"></div>
              </div>
            ) : filteredTenants.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <svg className="w-16 h-16 mx-auto mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
                <p>لا توجد نسخ حالياً</p>
                <p className="text-sm">اضغط على "إضافة نسخة جديدة" للبدء</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-gray-50">
                      <th className="py-3 px-4 text-right">رقم النسخة</th>
                      <th className="py-3 px-4 text-right">الشركة</th>
                      <th className="py-3 px-4 text-right">المسؤول</th>
                      <th className="py-3 px-4 text-right">نوع الترخيص</th>
                      <th className="py-3 px-4 text-right">تاريخ الانتهاء</th>
                      <th className="py-3 px-4 text-right">الحالة</th>
                      <th className="py-3 px-4 text-center">الإجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredTenants.map((tenant) => (
                      <tr key={tenant.tenant_id} className="border-b hover:bg-gray-50">
                        <td className="py-3 px-4">
                          <code className="bg-gray-100 px-2 py-1 rounded text-sm">{tenant.tenant_id}</code>
                        </td>
                        <td className="py-3 px-4">
                          <div>
                            <p className="font-semibold">{tenant.company_name_ar}</p>
                            <p className="text-sm text-muted-foreground">{tenant.email}</p>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <p>{tenant.contact_person}</p>
                          <p className="text-sm text-muted-foreground">{tenant.phone}</p>
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant={
                            tenant.license_type === 'enterprise' ? 'default' :
                            tenant.license_type === 'premium' ? 'secondary' : 'outline'
                          }>
                            {tenant.license_type === 'enterprise' ? 'مؤسسات' :
                             tenant.license_type === 'premium' ? 'مميز' : 'عادي'}
                          </Badge>
                        </td>
                        <td className="py-3 px-4">
                          <div>
                            <p>{tenant.license_expiry}</p>
                            {tenant.is_expired ? (
                              <Badge variant="destructive" className="text-xs">منتهي</Badge>
                            ) : tenant.days_remaining <= 30 ? (
                              <Badge variant="warning" className="text-xs bg-yellow-100 text-yellow-800">
                                متبقي {tenant.days_remaining} يوم
                              </Badge>
                            ) : (
                              <Badge variant="success" className="text-xs bg-green-100 text-green-800">ساري</Badge>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant={tenant.is_active ? 'success' : 'secondary'}
                                 className={tenant.is_active ? 'bg-green-100 text-green-800' : ''}>
                            {tenant.is_active ? 'نشط' : 'معطل'}
                          </Badge>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex justify-center gap-1">
                            <Button
                              size="sm"
                              variant="default"
                              className="bg-emerald hover:bg-emerald-hover text-white h-7 px-2"
                              onClick={() => handleEnterTenantDashboard(tenant)}
                              title="دخول للوحة التحكم"
                              data-testid={`enter-tenant-${tenant.tenant_id}`}
                            >
                              <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                              </svg>
                              دخول
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setViewingTenant(tenant)}
                              title="عرض البيانات"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                              </svg>
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => { setEditingTenant(tenant); setShowAddDialog(true); }}
                              title="تعديل"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                              </svg>
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleToggleStatus(tenant.tenant_id)}
                              title={tenant.is_active ? 'تعطيل' : 'تفعيل'}
                            >
                              {tenant.is_active ? (
                                <svg className="w-4 h-4 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                                </svg>
                              ) : (
                                <svg className="w-4 h-4 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                              )}
                            </Button>
                            <Select onValueChange={(days) => handleExtendLicense(tenant.tenant_id, parseInt(days))}>
                              <SelectTrigger className="w-8 h-8 p-0 border-0">
                                <svg className="w-4 h-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                                </svg>
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="30">تمديد 30 يوم</SelectItem>
                                <SelectItem value="90">تمديد 90 يوم</SelectItem>
                                <SelectItem value="180">تمديد 6 أشهر</SelectItem>
                                <SelectItem value="365">تمديد سنة</SelectItem>
                              </SelectContent>
                            </Select>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleDeleteTenant(tenant.tenant_id)}
                              title="حذف"
                            >
                              <svg className="w-4 h-4 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                              </svg>
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Tenant Details Dialog */}
        <Dialog open={!!viewingTenant} onOpenChange={(open) => !open && setViewingTenant(null)}>
          <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <svg className="w-6 h-6 text-emerald" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
                عرض بيانات النسخة
              </DialogTitle>
            </DialogHeader>
            {viewingTenant && (
              <TenantDetails tenant={viewingTenant} onClose={() => setViewingTenant(null)} />
            )}
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
