import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../utils/api';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { toast } from 'sonner';
import { Plus, Trash2, Eye, Printer, Search } from 'lucide-react';
import { formatDate, formatCurrency } from '../utils/exportHelpers';
import { PrintInvoice } from '../components/PrintTemplates';
import { CustomerCombobox } from '../components/AccountCombobox';

export default function Invoices() {
  const { t } = useTranslation();
  const [invoices, setInvoices] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [printInvoice, setPrintInvoice] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [newInvoice, setNewInvoice] = useState({
    invoice_number: '',
    invoice_date: formatDate(new Date()),
    customer_code: '',
    items: [{ description: '', quantity: 1, unit_price: 0, total: 0 }],
    vat_rate: 15,
    notes: ''
  });

  useEffect(() => {
    loadInvoices();
    loadCustomers();
  }, []);

  const loadInvoices = async () => {
    try {
      const response = await api.get('/invoices');
      setInvoices(response.data);
    } catch (error) {
      toast.error(t('error'));
    } finally {
      setLoading(false);
    }
  };

  const loadCustomers = async () => {
    try {
      const response = await api.get('/customers');
      setCustomers(response.data);
    } catch (error) {
      console.error('Error loading customers');
    }
  };

  const addItem = () => {
    setNewInvoice({
      ...newInvoice,
      items: [...newInvoice.items, { description: '', quantity: 1, unit_price: 0, total: 0 }]
    });
  };

  const removeItem = (index) => {
    if (newInvoice.items.length > 1) {
      const newItems = newInvoice.items.filter((_, i) => i !== index);
      setNewInvoice({ ...newInvoice, items: newItems });
    }
  };

  const updateItem = (index, field, value) => {
    const newItems = [...newInvoice.items];
    newItems[index][field] = value;
    if (field === 'quantity' || field === 'unit_price') {
      const qty = parseFloat(newItems[index].quantity) || 0;
      const price = parseFloat(newItems[index].unit_price) || 0;
      newItems[index].total = qty * price;
    }
    setNewInvoice({ ...newInvoice, items: newItems });
  };

  const calculateTotals = () => {
    const subtotal = newInvoice.items.reduce((sum, item) => sum + (item.total || 0), 0);
    const vat_amount = subtotal * (newInvoice.vat_rate / 100);
    const total_amount = subtotal + vat_amount;
    return { subtotal, vat_amount, total_amount };
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!newInvoice.customer_code) {
      toast.error('يجب اختيار العميل');
      return;
    }
    
    const { subtotal, vat_amount, total_amount } = calculateTotals();
    try {
      await api.post('/invoices', {
        ...newInvoice,
        invoice_date: new Date(newInvoice.invoice_date).toISOString(),
        subtotal, vat_amount, total_amount
      });
      toast.success(t('successfullySaved'));
      setDialogOpen(false);
      loadInvoices();
      resetForm();
    } catch (error) {
      toast.error(error.response?.data?.detail || t('error'));
    }
  };

  const resetForm = () => {
    setNewInvoice({
      invoice_number: '',
      invoice_date: formatDate(new Date()),
      customer_code: '',
      items: [{ description: '', quantity: 1, unit_price: 0, total: 0 }],
      vat_rate: 15,
      notes: ''
    });
  };

  const viewInvoice = (invoice) => {
    setSelectedInvoice(invoice);
    setViewDialogOpen(true);
  };

  const getCustomerName = (customerCode) => {
    const customer = customers.find(c => c.customer_code === customerCode);
    return customer?.customer_name || customerCode;
  };

  // Filter invoices based on search term
  const filteredInvoices = invoices.filter(invoice => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    const customerName = getCustomerName(invoice.customer_code).toLowerCase();
    return (
      invoice.invoice_number?.toLowerCase().includes(term) ||
      customerName.includes(term) ||
      formatDate(invoice.invoice_date).includes(term)
    );
  });

  const { subtotal, vat_amount, total_amount } = calculateTotals();

  if (loading) return <div className="text-center py-12">{t('loading')}</div>;
  if (printInvoice) {
    const customer = customers.find(c => c.customer_code === printInvoice.customer_code);
    return <PrintInvoice invoice={printInvoice} customer={customer} onClose={() => setPrintInvoice(null)} />;
  }

  return (
    <div className="space-y-6" data-testid="invoices-container">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">{t('invoices')}</h1>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald hover:bg-emerald-hover" onClick={resetForm} data-testid="add-invoice-button">
              <Plus className="h-4 w-4 me-2" />{t('addInvoice')}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>{t('addInvoice')}</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>{t('invoiceNumber')}</Label>
                  <Input 
                    value={newInvoice.invoice_number} 
                    onChange={(e) => setNewInvoice({...newInvoice, invoice_number: e.target.value})} 
                    required 
                    data-testid="invoice-number-input" 
                  />
                </div>
                <div>
                  <Label>{t('invoiceDate')}</Label>
                  <Input 
                    type="date" 
                    value={newInvoice.invoice_date} 
                    onChange={(e) => setNewInvoice({...newInvoice, invoice_date: e.target.value})} 
                    required 
                    data-testid="invoice-date-input" 
                  />
                </div>
              </div>
              
              <div>
                <Label>{t('customer')}</Label>
                <CustomerCombobox
                  customers={customers}
                  value={newInvoice.customer_code}
                  onSelect={(value) => setNewInvoice({...newInvoice, customer_code: value})}
                  placeholder="اختر العميل"
                />
              </div>
              
              <div className="border-t pt-4">
                <div className="flex justify-between items-center mb-3">
                  <h3 className="font-semibold">{t('items')}</h3>
                  <Button type="button" variant="outline" size="sm" onClick={addItem} data-testid="add-item-button">
                    <Plus className="h-4 w-4 me-2" />{t('addItem')}
                  </Button>
                </div>
                <div className="space-y-3">
                  {newInvoice.items.map((item, index) => (
                    <div key={index} className="grid grid-cols-12 gap-2 p-3 border rounded-md bg-muted/30">
                      <div className="col-span-5">
                        <Label className="text-xs text-muted-foreground mb-1 block">{t('description')}</Label>
                        <Input 
                          placeholder={t('description')} 
                          value={item.description} 
                          onChange={(e) => updateItem(index, 'description', e.target.value)} 
                          required 
                        />
                      </div>
                      <div className="col-span-2">
                        <Label className="text-xs text-muted-foreground mb-1 block">{t('quantity')}</Label>
                        <Input 
                          type="number" 
                          step="0.01" 
                          placeholder="1" 
                          value={item.quantity || ''} 
                          onChange={(e) => updateItem(index, 'quantity', parseFloat(e.target.value) || 0)} 
                          required 
                          className="text-end"
                        />
                      </div>
                      <div className="col-span-2">
                        <Label className="text-xs text-muted-foreground mb-1 block">{t('unitPrice')}</Label>
                        <Input 
                          type="number" 
                          step="0.01" 
                          placeholder="0.00" 
                          value={item.unit_price || ''} 
                          onChange={(e) => updateItem(index, 'unit_price', parseFloat(e.target.value) || 0)} 
                          required 
                          className="text-end"
                        />
                      </div>
                      <div className="col-span-2">
                        <Label className="text-xs text-muted-foreground mb-1 block">{t('total')}</Label>
                        <Input 
                          type="number" 
                          step="0.01" 
                          value={item.total.toFixed(2)} 
                          disabled 
                          className="bg-muted text-end" 
                        />
                      </div>
                      <div className="col-span-1 flex items-end pb-1">
                        <Button type="button" variant="ghost" size="icon" onClick={() => removeItem(index)} disabled={newInvoice.items.length === 1}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 p-4 bg-muted rounded-md space-y-2">
                  <div className="flex justify-between"><span>{t('subtotal')}:</span><span className="font-semibold">{formatCurrency(subtotal)}</span></div>
                  <div className="flex justify-between"><span>{t('vat')} ({newInvoice.vat_rate}%):</span><span className="font-semibold">{formatCurrency(vat_amount)}</span></div>
                  <div className="flex justify-between text-lg border-t pt-2"><span className="font-bold">{t('totalAmount')}:</span><span className="font-bold text-emerald">{formatCurrency(total_amount)}</span></div>
                </div>
              </div>
              
              <div>
                <Label>{t('notes')}</Label>
                <Input value={newInvoice.notes} onChange={(e) => setNewInvoice({...newInvoice, notes: e.target.value})} />
              </div>
              
              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>{t('cancel')}</Button>
                <Button type="submit" className="bg-emerald hover:bg-emerald-hover">{t('save')}</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search Bar */}
      <Card className="p-4">
        <div className="relative">
          <Search className="absolute start-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="بحث برقم الفاتورة أو اسم العميل..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="ps-10"
            data-testid="search-invoices-input"
          />
        </div>
      </Card>

      <Card className="border border-border/60">
        <div className="overflow-x-auto">
          <table className="w-full" data-testid="invoices-table">
            <thead className="bg-muted">
              <tr>
                <th className="px-4 py-3 text-start">{t('invoiceNumber')}</th>
                <th className="px-4 py-3 text-start">{t('invoiceDate')}</th>
                <th className="px-4 py-3 text-start">{t('customer')}</th>
                <th className="px-4 py-3 text-end">{t('totalAmount')}</th>
                <th className="px-4 py-3 text-start">{t('actions')}</th>
              </tr>
            </thead>
            <tbody>
              {filteredInvoices.map((invoice) => (
                <tr key={invoice.invoice_number} className="border-b border-border hover:bg-muted/30" data-testid={`invoice-row-${invoice.invoice_number}`}>
                  <td className="px-4 py-3">{invoice.invoice_number}</td>
                  <td className="px-4 py-3">{formatDate(invoice.invoice_date)}</td>
                  <td className="px-4 py-3">{getCustomerName(invoice.customer_code)}</td>
                  <td className="px-4 py-3 text-end">{formatCurrency(invoice.total_amount)}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <Button size="icon" variant="ghost" onClick={() => viewInvoice(invoice)} data-testid={`view-invoice-${invoice.invoice_number}`}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => setPrintInvoice(invoice)} data-testid={`print-invoice-${invoice.invoice_number}`}>
                        <Printer className="h-4 w-4 text-emerald" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredInvoices.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              {searchTerm ? 'لا توجد نتائج للبحث' : t('noData')}
            </div>
          )}
        </div>
      </Card>

      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader><DialogTitle>فاتورة - {selectedInvoice?.invoice_number}</DialogTitle></DialogHeader>
          {selectedInvoice && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div><span className="font-semibold">رقم الفاتورة: </span>{selectedInvoice.invoice_number}</div>
                <div><span className="font-semibold">التاريخ: </span>{formatDate(selectedInvoice.invoice_date)}</div>
                <div className="col-span-2"><span className="font-semibold">العميل: </span>{getCustomerName(selectedInvoice.customer_code)}</div>
              </div>
              <div>
                <h4 className="font-semibold mb-2">البنود:</h4>
                <table className="w-full border">
                  <thead className="bg-muted">
                    <tr>
                      <th className="px-3 py-2 text-start">الوصف</th>
                      <th className="px-3 py-2 text-end">الكمية</th>
                      <th className="px-3 py-2 text-end">سعر الوحدة</th>
                      <th className="px-3 py-2 text-end">الإجمالي</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedInvoice.items?.map((item, idx) => (
                      <tr key={idx} className="border-b">
                        <td className="px-3 py-2">{item.description}</td>
                        <td className="px-3 py-2 text-end">{item.quantity}</td>
                        <td className="px-3 py-2 text-end">{formatCurrency(item.unit_price)}</td>
                        <td className="px-3 py-2 text-end">{formatCurrency(item.total)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="p-4 bg-muted rounded-md space-y-2">
                <div className="flex justify-between"><span>المجموع الفرعي:</span><span>{formatCurrency(selectedInvoice.subtotal)}</span></div>
                <div className="flex justify-between"><span>ضريبة القيمة المضافة ({selectedInvoice.vat_rate}%):</span><span>{formatCurrency(selectedInvoice.vat_amount)}</span></div>
                <div className="flex justify-between text-lg font-bold border-t pt-2"><span>المبلغ الإجمالي:</span><span className="text-emerald">{formatCurrency(selectedInvoice.total_amount)}</span></div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
