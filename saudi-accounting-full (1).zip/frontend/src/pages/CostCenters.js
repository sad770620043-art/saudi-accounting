import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../utils/api';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { toast } from 'sonner';
import { Plus, Edit, Trash2, Building2, Search } from 'lucide-react';

export default function CostCenters() {
  const { t, i18n } = useTranslation();
  const [centers, setCenters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [currentCenter, setCurrentCenter] = useState({
    center_code: '',
    center_name_ar: '',
    center_name_en: '',
    parent_code: '',
    description: '',
    is_active: true
  });

  useEffect(() => {
    loadCenters();
  }, []);

  const loadCenters = async () => {
    try {
      const response = await api.get('/cost-centers');
      setCenters(response.data);
    } catch (error) {
      toast.error('حدث خطأ في تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editMode) {
        await api.put(`/cost-centers/${currentCenter.center_code}`, currentCenter);
        toast.success('تم تحديث مركز التكلفة بنجاح');
      } else {
        await api.post('/cost-centers', currentCenter);
        toast.success('تم إنشاء مركز التكلفة بنجاح');
      }
      setDialogOpen(false);
      loadCenters();
      resetForm();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'حدث خطأ');
    }
  };

  const handleEdit = (center) => {
    setCurrentCenter(center);
    setEditMode(true);
    setDialogOpen(true);
  };

  const handleDelete = async (centerCode) => {
    if (!confirm('هل أنت متأكد من حذف مركز التكلفة؟')) return;
    try {
      await api.delete(`/cost-centers/${centerCode}`);
      toast.success('تم حذف مركز التكلفة بنجاح');
      loadCenters();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'حدث خطأ');
    }
  };

  const resetForm = () => {
    setCurrentCenter({
      center_code: '',
      center_name_ar: '',
      center_name_en: '',
      parent_code: '',
      description: '',
      is_active: true
    });
    setEditMode(false);
  };

  const filteredCenters = centers.filter(center => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      center.center_code.toLowerCase().includes(term) ||
      center.center_name_ar.toLowerCase().includes(term) ||
      (center.center_name_en || '').toLowerCase().includes(term)
    );
  });

  if (loading) {
    return <div className="text-center py-12">جاري التحميل...</div>;
  }

  return (
    <div className="space-y-6" data-testid="cost-centers-container">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <Building2 className="h-8 w-8 text-emerald" />
          <div>
            <h1 className="text-2xl font-bold">مراكز التكلفة</h1>
            <p className="text-sm text-muted-foreground">{centers.length} مركز تكلفة</p>
          </div>
        </div>
        
        <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) resetForm(); }}>
          <DialogTrigger asChild>
            <Button className="bg-emerald hover:bg-emerald-hover" data-testid="add-cost-center-btn">
              <Plus className="h-4 w-4 me-2" />
              إضافة مركز تكلفة
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editMode ? 'تعديل مركز التكلفة' : 'إضافة مركز تكلفة جديد'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>رمز مركز التكلفة *</Label>
                  <Input
                    value={currentCenter.center_code}
                    onChange={(e) => setCurrentCenter({...currentCenter, center_code: e.target.value})}
                    required
                    disabled={editMode}
                    placeholder="CC001"
                    data-testid="center-code-input"
                  />
                </div>
                <div>
                  <Label>مركز التكلفة الرئيسي</Label>
                  <Input
                    value={currentCenter.parent_code}
                    onChange={(e) => setCurrentCenter({...currentCenter, parent_code: e.target.value})}
                    placeholder="اختياري"
                  />
                </div>
              </div>
              
              <div>
                <Label>الاسم بالعربي *</Label>
                <Input
                  value={currentCenter.center_name_ar}
                  onChange={(e) => setCurrentCenter({...currentCenter, center_name_ar: e.target.value})}
                  required
                  placeholder="قسم المبيعات"
                  data-testid="center-name-ar-input"
                />
              </div>
              
              <div>
                <Label>الاسم بالإنجليزي</Label>
                <Input
                  value={currentCenter.center_name_en}
                  onChange={(e) => setCurrentCenter({...currentCenter, center_name_en: e.target.value})}
                  placeholder="Sales Department"
                />
              </div>
              
              <div>
                <Label>الوصف</Label>
                <Input
                  value={currentCenter.description}
                  onChange={(e) => setCurrentCenter({...currentCenter, description: e.target.value})}
                  placeholder="وصف مركز التكلفة"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  إلغاء
                </Button>
                <Button type="submit" className="bg-emerald hover:bg-emerald-hover" data-testid="save-center-btn">
                  {editMode ? 'تحديث' : 'حفظ'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card className="p-4">
        <div className="relative">
          <Search className="absolute start-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="بحث بالرمز أو الاسم..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="ps-10"
            data-testid="search-centers-input"
          />
        </div>
      </Card>

      {/* Table */}
      <Card className="border border-border/60">
        <div className="overflow-x-auto">
          <table className="w-full" data-testid="cost-centers-table">
            <thead className="bg-muted">
              <tr>
                <th className="px-4 py-3 text-start">الرمز</th>
                <th className="px-4 py-3 text-start">الاسم بالعربي</th>
                <th className="px-4 py-3 text-start">الاسم بالإنجليزي</th>
                <th className="px-4 py-3 text-start">المركز الرئيسي</th>
                <th className="px-4 py-3 text-start">الحالة</th>
                <th className="px-4 py-3 text-start">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filteredCenters.map((center) => (
                <tr key={center.center_code} className="border-b border-border hover:bg-muted/30" data-testid={`center-row-${center.center_code}`}>
                  <td className="px-4 py-3 font-medium">{center.center_code}</td>
                  <td className="px-4 py-3">{center.center_name_ar}</td>
                  <td className="px-4 py-3 text-muted-foreground">{center.center_name_en || '-'}</td>
                  <td className="px-4 py-3">{center.parent_code || '-'}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded-full text-xs ${center.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                      {center.is_active ? 'نشط' : 'غير نشط'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <Button size="icon" variant="ghost" onClick={() => handleEdit(center)} data-testid={`edit-center-${center.center_code}`}>
                        <Edit className="h-4 w-4 text-blue-500" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => handleDelete(center.center_code)} data-testid={`delete-center-${center.center_code}`}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredCenters.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              {searchTerm ? 'لا توجد نتائج للبحث' : 'لا توجد مراكز تكلفة. ابدأ بإضافة مركز جديد.'}
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
