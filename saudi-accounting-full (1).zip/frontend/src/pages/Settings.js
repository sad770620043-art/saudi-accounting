import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../utils/api';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { toast } from 'sonner';
import { Download, Upload, UserPlus, Trash2, Key, ImagePlus, Building2, Palette } from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

// Predefined color options
const COLOR_OPTIONS = [
  { name: 'أخضر زمردي', value: '#006d5b', nameEn: 'Emerald' },
  { name: 'أزرق', value: '#1e40af', nameEn: 'Blue' },
  { name: 'أحمر', value: '#b91c1c', nameEn: 'Red' },
  { name: 'بنفسجي', value: '#7c3aed', nameEn: 'Purple' },
  { name: 'برتقالي', value: '#c2410c', nameEn: 'Orange' },
  { name: 'رمادي داكن', value: '#374151', nameEn: 'Dark Gray' },
  { name: 'ذهبي', value: '#b45309', nameEn: 'Gold' },
  { name: 'أزرق سماوي', value: '#0891b2', nameEn: 'Cyan' },
];

// Template options for invoices and vouchers
const INVOICE_TEMPLATES = [
  { id: 'classic', name: 'كلاسيكي', nameEn: 'Classic', description: 'تصميم تقليدي أنيق' },
  { id: 'modern', name: 'عصري', nameEn: 'Modern', description: 'تصميم حديث وجذاب' },
  { id: 'minimal', name: 'بسيط', nameEn: 'Minimal', description: 'تصميم نظيف وبسيط' },
  { id: 'professional', name: 'احترافي', nameEn: 'Professional', description: 'تصميم رسمي للشركات' },
];

const VOUCHER_TEMPLATES = [
  { id: 'classic', name: 'كلاسيكي', nameEn: 'Classic', description: 'تصميم تقليدي' },
  { id: 'modern', name: 'عصري', nameEn: 'Modern', description: 'تصميم حديث' },
  { id: 'compact', name: 'مضغوط', nameEn: 'Compact', description: 'تصميم موجز' },
];

export default function Settings() {
  const { t } = useTranslation();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [passwordDialogOpen, setPasswordDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const fileInputRef = useRef(null);
  const logoInputRef = useRef(null);
  
  const [newUser, setNewUser] = useState({
    username: '',
    password: '',
    full_name: ''
  });
  
  const [passwordData, setPasswordData] = useState({
    new_password: '',
    confirm_password: ''
  });

  const [companySettings, setCompanySettings] = useState({
    company_name_ar: '',
    company_name_en: '',
    commercial_registration: '',
    tax_number: '',
    address_ar: '',
    address_en: '',
    phone: '',
    email: '',
    logo_url: '',
    logo_base64: '',
    primary_color: '#006d5b',
    invoice_color: '#006d5b',
    voucher_color: '#006d5b',
    invoice_template: 'classic',
    voucher_template: 'classic',
    license_expiry: '',
    app_version: '1.0.0'
  });

  const [logoPreview, setLogoPreview] = useState(null);

  useEffect(() => {
    loadUsers();
    loadCompanySettings();
  }, []);

  const loadUsers = async () => {
    try {
      const response = await api.get('/users');
      setUsers(response.data);
    } catch (error) {
      toast.error(t('error'));
    }
  };

  const loadCompanySettings = async () => {
    try {
      const response = await api.get('/company-settings');
      setCompanySettings(prev => ({
        ...prev,
        ...response.data,
        primary_color: response.data.primary_color || '#006d5b',
        invoice_color: response.data.invoice_color || '#006d5b',
        voucher_color: response.data.voucher_color || '#006d5b',
        invoice_template: response.data.invoice_template || 'classic',
        voucher_template: response.data.voucher_template || 'classic',
        license_expiry: response.data.license_expiry || '',
        app_version: response.data.app_version || '1.0.0'
      }));
      if (response.data.logo_base64) {
        setLogoPreview(response.data.logo_base64);
      } else if (response.data.logo_url) {
        setLogoPreview(response.data.logo_url);
      }
    } catch (error) {
      console.error('Error loading company settings');
    }
  };

  const handleLogoUpload = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('يرجى اختيار ملف صورة');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      toast.error('حجم الصورة يجب أن يكون أقل من 2 ميجابايت');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target.result;
      setLogoPreview(base64);
      setCompanySettings(prev => ({
        ...prev,
        logo_base64: base64,
        logo_url: ''
      }));
    };
    reader.readAsDataURL(file);
    event.target.value = '';
  };

  const removeLogo = () => {
    setLogoPreview(null);
    setCompanySettings(prev => ({
      ...prev,
      logo_base64: '',
      logo_url: ''
    }));
  };

  const exportBackup = async () => {
    setLoading(true);
    try {
      const url = `${BACKEND_URL}/api/backup/export`;
      window.open(url, '_blank');
      toast.success('تم تصدير النسخة الاحتياطية بنجاح');
    } catch (error) {
      toast.error('فشل تصدير النسخة الاحتياطية');
    } finally {
      setLoading(false);
    }
  };

  const importBackup = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!window.confirm('تحذير: سيتم استبدال جميع البيانات الحالية. هل أنت متأكد؟')) {
      event.target.value = '';
      return;
    }

    setLoading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      await api.post('/backup/import', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      toast.success('تم استيراد النسخة الاحتياطية بنجاح');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'فشل استيراد النسخة الاحتياطية');
    } finally {
      setLoading(false);
      event.target.value = '';
    }
  };

  const handleCreateUser = async (e) => {
    e.preventDefault();
    
    if (newUser.password.length < 6) {
      toast.error('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
      return;
    }

    try {
      await api.post('/users', newUser);
      toast.success('تم إضافة المستخدم بنجاح');
      setDialogOpen(false);
      loadUsers();
      setNewUser({ username: '', password: '', full_name: '' });
    } catch (error) {
      toast.error(error.response?.data?.detail || 'فشل إضافة المستخدم');
    }
  };

  const handleDeleteUser = async (username) => {
    if (!window.confirm(`هل أنت متأكد من حذف المستخدم ${username}؟`)) return;

    try {
      await api.delete(`/users/${username}`);
      toast.success('تم حذف المستخدم بنجاح');
      loadUsers();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'فشل حذف المستخدم');
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    
    if (passwordData.new_password !== passwordData.confirm_password) {
      toast.error('كلمات المرور غير متطابقة');
      return;
    }

    if (passwordData.new_password.length < 6) {
      toast.error('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
      return;
    }

    try {
      await api.put(`/users/${selectedUser}/password`, {
        new_password: passwordData.new_password
      });
      toast.success('تم تغيير كلمة المرور بنجاح');
      setPasswordDialogOpen(false);
      setPasswordData({ new_password: '', confirm_password: '' });
    } catch (error) {
      toast.error(error.response?.data?.detail || 'فشل تغيير كلمة المرور');
    }
  };

  const handleSaveCompanySettings = async (e) => {
    e.preventDefault();
    try {
      await api.post('/company-settings', companySettings);
      toast.success('تم حفظ معلومات الشركة بنجاح');
    } catch (error) {
      toast.error('فشل حفظ معلومات الشركة');
    }
  };

  const ColorPicker = ({ label, value, onChange, description }) => (
    <div className="space-y-2">
      <Label>{label}</Label>
      <div className="flex flex-wrap gap-2">
        {COLOR_OPTIONS.map((color) => (
          <button
            key={color.value}
            type="button"
            onClick={() => onChange(color.value)}
            className={`w-10 h-10 rounded-lg border-2 transition-all ${
              value === color.value ? 'border-gray-900 scale-110 shadow-lg' : 'border-gray-300 hover:border-gray-500'
            }`}
            style={{ backgroundColor: color.value }}
            title={color.name}
          />
        ))}
        <div className="flex items-center gap-2">
          <input
            type="color"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-10 h-10 rounded cursor-pointer border-2 border-gray-300"
            title="اختر لون مخصص"
          />
          <span className="text-xs text-muted-foreground">مخصص</span>
        </div>
      </div>
      {description && <p className="text-xs text-muted-foreground">{description}</p>}
      <div className="flex items-center gap-2 mt-2">
        <div className="w-6 h-6 rounded" style={{ backgroundColor: value }}></div>
        <span className="font-mono text-sm">{value}</span>
      </div>
    </div>
  );

  return (
    <div className="space-y-6" data-testid="settings-container">
      <h1 className="text-2xl font-bold">{t('settings')}</h1>

      <Tabs defaultValue="company" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="company" data-testid="company-tab">معلومات الشركة</TabsTrigger>
          <TabsTrigger value="appearance" data-testid="appearance-tab">المظهر والقوالب</TabsTrigger>
          <TabsTrigger value="license" data-testid="license-tab">الترخيص</TabsTrigger>
          <TabsTrigger value="users" data-testid="users-tab">المستخدمين</TabsTrigger>
          <TabsTrigger value="backup" data-testid="backup-tab">النسخ الاحتياطي</TabsTrigger>
        </TabsList>

        {/* Company Settings Tab */}
        <TabsContent value="company" className="space-y-4">
          <Card className="p-6 border border-border/60">
            <div className="flex items-center gap-2 mb-6">
              <Building2 className="h-6 w-6 text-emerald" />
              <h2 className="text-xl font-semibold">معلومات الشركة</h2>
            </div>
            
            <form onSubmit={handleSaveCompanySettings} className="space-y-6">
              {/* Logo Section */}
              <div className="p-4 border-2 border-dashed border-border rounded-lg bg-muted/30">
                <Label className="text-base font-semibold mb-3 block">شعار الشركة</Label>
                <div className="flex items-center gap-6">
                  <div className="w-32 h-32 border rounded-lg bg-white flex items-center justify-center overflow-hidden">
                    {logoPreview ? (
                      <img src={logoPreview} alt="Company Logo" className="w-full h-full object-contain" />
                    ) : (
                      <div className="text-center text-muted-foreground">
                        <ImagePlus className="h-8 w-8 mx-auto mb-1" />
                        <span className="text-xs">لا يوجد شعار</span>
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <input ref={logoInputRef} type="file" accept="image/*" onChange={handleLogoUpload} style={{ display: 'none' }} />
                    <div className="space-y-2">
                      <Button type="button" variant="outline" onClick={() => logoInputRef.current?.click()}>
                        <Upload className="h-4 w-4 me-2" />
                        رفع شعار جديد
                      </Button>
                      {logoPreview && (
                        <Button type="button" variant="outline" className="text-destructive hover:text-destructive" onClick={removeLogo}>
                          <Trash2 className="h-4 w-4 me-2" />
                          إزالة الشعار
                        </Button>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      يظهر الشعار على الفواتير والسندات والقيود المطبوعة
                    </p>
                  </div>
                </div>
              </div>

              {/* Company Names */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>اسم الشركة (عربي) *</Label>
                  <Input
                    value={companySettings.company_name_ar}
                    onChange={(e) => setCompanySettings({...companySettings, company_name_ar: e.target.value})}
                    required
                    placeholder="مثال: شركة الأفق للتجارة"
                  />
                </div>
                <div>
                  <Label>اسم الشركة (إنجليزي)</Label>
                  <Input
                    value={companySettings.company_name_en}
                    onChange={(e) => setCompanySettings({...companySettings, company_name_en: e.target.value})}
                    placeholder="e.g. Al-Ofuq Trading Co."
                  />
                </div>
              </div>

              {/* Registration Numbers */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>رقم السجل التجاري</Label>
                  <Input
                    value={companySettings.commercial_registration}
                    onChange={(e) => setCompanySettings({...companySettings, commercial_registration: e.target.value})}
                    placeholder="مثال: 1010123456"
                  />
                </div>
                <div>
                  <Label>الرقم الضريبي (VAT) *</Label>
                  <Input
                    value={companySettings.tax_number}
                    onChange={(e) => setCompanySettings({...companySettings, tax_number: e.target.value})}
                    placeholder="مثال: 300012345600003"
                    className="font-mono"
                  />
                </div>
              </div>

              {/* Addresses */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>العنوان (عربي)</Label>
                  <Input
                    value={companySettings.address_ar}
                    onChange={(e) => setCompanySettings({...companySettings, address_ar: e.target.value})}
                    placeholder="مثال: الرياض - حي العليا"
                  />
                </div>
                <div>
                  <Label>العنوان (إنجليزي)</Label>
                  <Input
                    value={companySettings.address_en}
                    onChange={(e) => setCompanySettings({...companySettings, address_en: e.target.value})}
                    placeholder="e.g. Riyadh - Olaya District"
                  />
                </div>
              </div>

              {/* Contact */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>الهاتف</Label>
                  <Input
                    value={companySettings.phone}
                    onChange={(e) => setCompanySettings({...companySettings, phone: e.target.value})}
                    placeholder="مثال: +966 11 123 4567"
                  />
                </div>
                <div>
                  <Label>البريد الإلكتروني</Label>
                  <Input
                    type="email"
                    value={companySettings.email}
                    onChange={(e) => setCompanySettings({...companySettings, email: e.target.value})}
                    placeholder="info@company.com"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-4 border-t">
                <Button type="submit" className="bg-emerald hover:bg-emerald-hover">
                  حفظ معلومات الشركة
                </Button>
              </div>
            </form>
          </Card>
        </TabsContent>

        {/* Appearance Settings Tab */}
        <TabsContent value="appearance" className="space-y-4">
          <Card className="p-6 border border-border/60">
            <div className="flex items-center gap-2 mb-6">
              <Palette className="h-6 w-6 text-emerald" />
              <h2 className="text-xl font-semibold">المظهر وألوان الطباعة</h2>
            </div>
            
            <form onSubmit={handleSaveCompanySettings} className="space-y-8">
              <ColorPicker
                label="لون الفواتير"
                value={companySettings.invoice_color}
                onChange={(color) => setCompanySettings({...companySettings, invoice_color: color})}
                description="يُستخدم في عناوين وجداول الفواتير المطبوعة"
              />
              
              <ColorPicker
                label="لون السندات (قبض / صرف)"
                value={companySettings.voucher_color}
                onChange={(color) => setCompanySettings({...companySettings, voucher_color: color})}
                description="يُستخدم في عناوين سندات القبض والصرف المطبوعة"
              />

              {/* Invoice Template Selection */}
              <div className="space-y-3">
                <Label className="text-base font-semibold">قالب الفاتورة</Label>
                <p className="text-sm text-muted-foreground">اختر تصميم الفاتورة المناسب لنشاطك</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {INVOICE_TEMPLATES.map((template) => (
                    <div
                      key={template.id}
                      onClick={() => setCompanySettings({...companySettings, invoice_template: template.id})}
                      className={`cursor-pointer p-4 rounded-lg border-2 transition-all hover:shadow-md ${
                        companySettings.invoice_template === template.id
                          ? 'border-emerald bg-emerald/5'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="text-center">
                        <div className={`w-full h-20 mb-2 rounded border ${
                          template.id === 'classic' ? 'bg-gradient-to-b from-gray-100 to-white' :
                          template.id === 'modern' ? 'bg-gradient-to-br from-blue-50 to-purple-50' :
                          template.id === 'minimal' ? 'bg-white border-dashed' :
                          'bg-gradient-to-r from-gray-800 to-gray-600'
                        }`}>
                          <div className="h-4 m-2 rounded" style={{ backgroundColor: companySettings.invoice_color, opacity: 0.7 }}></div>
                          <div className="flex gap-1 mx-2">
                            <div className="h-2 flex-1 bg-gray-200 rounded"></div>
                            <div className="h-2 w-8 bg-gray-300 rounded"></div>
                          </div>
                        </div>
                        <h4 className="font-semibold text-sm">{template.name}</h4>
                        <p className="text-xs text-muted-foreground">{template.description}</p>
                      </div>
                      {companySettings.invoice_template === template.id && (
                        <div className="text-center mt-2">
                          <span className="text-xs bg-emerald text-white px-2 py-0.5 rounded-full">محدد</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Voucher Template Selection */}
              <div className="space-y-3">
                <Label className="text-base font-semibold">قالب السندات</Label>
                <p className="text-sm text-muted-foreground">اختر تصميم سندات القبض والصرف</p>
                <div className="grid grid-cols-3 gap-3">
                  {VOUCHER_TEMPLATES.map((template) => (
                    <div
                      key={template.id}
                      onClick={() => setCompanySettings({...companySettings, voucher_template: template.id})}
                      className={`cursor-pointer p-4 rounded-lg border-2 transition-all hover:shadow-md ${
                        companySettings.voucher_template === template.id
                          ? 'border-emerald bg-emerald/5'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="text-center">
                        <div className={`w-full h-16 mb-2 rounded border ${
                          template.id === 'classic' ? 'bg-gradient-to-b from-gray-100 to-white' :
                          template.id === 'modern' ? 'bg-gradient-to-br from-green-50 to-blue-50' :
                          'bg-gray-50'
                        }`}>
                          <div className="h-3 m-2 rounded" style={{ backgroundColor: companySettings.voucher_color, opacity: 0.7 }}></div>
                        </div>
                        <h4 className="font-semibold text-sm">{template.name}</h4>
                        <p className="text-xs text-muted-foreground">{template.description}</p>
                      </div>
                      {companySettings.voucher_template === template.id && (
                        <div className="text-center mt-2">
                          <span className="text-xs bg-emerald text-white px-2 py-0.5 rounded-full">محدد</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Preview */}
              <div className="p-4 border rounded-lg bg-muted/30">
                <Label className="text-base font-semibold mb-4 block">معاينة الألوان</Label>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-white rounded border">
                    <div className="text-center mb-2" style={{ color: companySettings.invoice_color }}>
                      <h3 className="font-bold text-lg">فاتورة ضريبية</h3>
                    </div>
                    <div className="h-8 rounded" style={{ backgroundColor: companySettings.invoice_color }}></div>
                  </div>
                  <div className="p-4 bg-white rounded border">
                    <div className="text-center mb-2" style={{ color: companySettings.voucher_color }}>
                      <h3 className="font-bold text-lg">سند قبض / صرف</h3>
                    </div>
                    <div className="h-8 rounded" style={{ backgroundColor: companySettings.voucher_color }}></div>
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-4 border-t">
                <Button type="submit" className="bg-emerald hover:bg-emerald-hover">
                  حفظ الإعدادات
                </Button>
              </div>
            </form>
          </Card>
        </TabsContent>

        {/* License & Updates Tab */}
        <TabsContent value="license" className="space-y-4">
          <Card className="p-6 border border-border/60">
            <div className="flex items-center gap-2 mb-6">
              <Key className="h-6 w-6 text-emerald" />
              <h2 className="text-xl font-semibold">الترخيص والتحديثات</h2>
            </div>
            
            <form onSubmit={handleSaveCompanySettings} className="space-y-6">
              {/* App Version */}
              <div className="p-4 bg-gradient-to-r from-emerald/10 to-blue-500/10 rounded-lg border">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-lg">النظام المحاسبي السعودي</h3>
                    <p className="text-sm text-muted-foreground">Saudi Unified Accounting System</p>
                  </div>
                  <div className="text-left">
                    <span className="inline-block px-3 py-1 bg-emerald text-white rounded-full text-sm font-semibold">
                      الإصدار {companySettings.app_version || '1.0.0'}
                    </span>
                  </div>
                </div>
              </div>

              {/* License Expiry */}
              <div className="space-y-3">
                <Label className="text-base font-semibold">تاريخ انتهاء الترخيص</Label>
                <div className="flex gap-4 items-end">
                  <div className="flex-1">
                    <Input
                      type="date"
                      value={companySettings.license_expiry || ''}
                      onChange={(e) => setCompanySettings({...companySettings, license_expiry: e.target.value})}
                      className="w-full"
                    />
                  </div>
                  {companySettings.license_expiry && (
                    <div className={`px-4 py-2 rounded-lg text-sm font-semibold ${
                      new Date(companySettings.license_expiry) > new Date() 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-red-100 text-red-700'
                    }`}>
                      {new Date(companySettings.license_expiry) > new Date() ? (
                        <>
                          <span>✓ ساري</span>
                          <span className="block text-xs">
                            متبقي {Math.ceil((new Date(companySettings.license_expiry) - new Date()) / (1000 * 60 * 60 * 24))} يوم
                          </span>
                        </>
                      ) : (
                        <span>⚠ منتهي الصلاحية</span>
                      )}
                    </div>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  حدد تاريخ انتهاء ترخيص البرنامج للعميل
                </p>
              </div>

              {/* Version Update */}
              <div className="space-y-3">
                <Label className="text-base font-semibold">رقم الإصدار</Label>
                <div className="flex gap-2">
                  <Input
                    value={companySettings.app_version || '1.0.0'}
                    onChange={(e) => setCompanySettings({...companySettings, app_version: e.target.value})}
                    placeholder="1.0.0"
                    className="w-40"
                  />
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={() => {
                      const parts = (companySettings.app_version || '1.0.0').split('.');
                      parts[2] = String(parseInt(parts[2] || '0') + 1);
                      setCompanySettings({...companySettings, app_version: parts.join('.')});
                    }}
                  >
                    ترقية طفيفة
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={() => {
                      const parts = (companySettings.app_version || '1.0.0').split('.');
                      parts[1] = String(parseInt(parts[1] || '0') + 1);
                      parts[2] = '0';
                      setCompanySettings({...companySettings, app_version: parts.join('.')});
                    }}
                  >
                    ترقية متوسطة
                  </Button>
                </div>
              </div>

              {/* Update Log */}
              <div className="space-y-3">
                <Label className="text-base font-semibold">سجل التحديثات</Label>
                <div className="border rounded-lg divide-y max-h-60 overflow-y-auto">
                  <div className="p-3 bg-emerald/5">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-emerald">الإصدار 1.0.0</span>
                      <span className="text-xs text-muted-foreground">مارس 2026</span>
                    </div>
                    <ul className="text-sm text-muted-foreground mt-1 list-disc list-inside">
                      <li>القوائم المالية (الدخل، المركز المالي، التدفقات النقدية)</li>
                      <li>قوالب متعددة للفواتير والسندات</li>
                      <li>رمز QR متوافق مع ZATCA</li>
                      <li>ألوان قابلة للتخصيص</li>
                    </ul>
                  </div>
                  <div className="p-3">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">الإصدار 0.9.0</span>
                      <span className="text-xs text-muted-foreground">فبراير 2026</span>
                    </div>
                    <ul className="text-sm text-muted-foreground mt-1 list-disc list-inside">
                      <li>القيود السريعة (Easy Entries)</li>
                      <li>ميزان المراجعة المتقدم</li>
                      <li>الأرصدة الافتتاحية</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-4 border-t">
                <Button type="submit" className="bg-emerald hover:bg-emerald-hover">
                  حفظ إعدادات الترخيص
                </Button>
              </div>
            </form>
          </Card>
        </TabsContent>

        {/* User Management Tab */}
        <TabsContent value="users" className="space-y-4">
          <Card className="p-6 border border-border/60">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">إدارة المستخدمين</h2>
              
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-emerald hover:bg-emerald-hover">
                    <UserPlus className="h-4 w-4 me-2" />
                    إضافة مستخدم
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>إضافة مستخدم جديد</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleCreateUser} className="space-y-4">
                    <div>
                      <Label>اسم المستخدم</Label>
                      <Input value={newUser.username} onChange={(e) => setNewUser({...newUser, username: e.target.value})} required />
                    </div>
                    <div>
                      <Label>الاسم الكامل</Label>
                      <Input value={newUser.full_name} onChange={(e) => setNewUser({...newUser, full_name: e.target.value})} required />
                    </div>
                    <div>
                      <Label>كلمة المرور</Label>
                      <Input type="password" value={newUser.password} onChange={(e) => setNewUser({...newUser, password: e.target.value})} required minLength={6} />
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
                      <Button type="submit" className="bg-emerald hover:bg-emerald-hover">حفظ</Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted">
                  <tr>
                    <th className="px-4 py-3 text-start">اسم المستخدم</th>
                    <th className="px-4 py-3 text-start">الاسم الكامل</th>
                    <th className="px-4 py-3 text-start">تاريخ الإنشاء</th>
                    <th className="px-4 py-3 text-start">الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user.username} className="border-b border-border hover:bg-muted/30">
                      <td className="px-4 py-3">{user.username}</td>
                      <td className="px-4 py-3">{user.full_name}</td>
                      <td className="px-4 py-3">{new Date(user.created_at).toLocaleDateString('ar-SA')}</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-2">
                          <Dialog open={passwordDialogOpen && selectedUser === user.username} onOpenChange={(open) => {
                            setPasswordDialogOpen(open);
                            if (open) setSelectedUser(user.username);
                          }}>
                            <DialogTrigger asChild>
                              <Button size="icon" variant="ghost"><Key className="h-4 w-4" /></Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>تغيير كلمة المرور - {user.username}</DialogTitle>
                              </DialogHeader>
                              <form onSubmit={handleChangePassword} className="space-y-4">
                                <div>
                                  <Label>كلمة المرور الجديدة</Label>
                                  <Input type="password" value={passwordData.new_password} onChange={(e) => setPasswordData({...passwordData, new_password: e.target.value})} required minLength={6} />
                                </div>
                                <div>
                                  <Label>تأكيد كلمة المرور</Label>
                                  <Input type="password" value={passwordData.confirm_password} onChange={(e) => setPasswordData({...passwordData, confirm_password: e.target.value})} required minLength={6} />
                                </div>
                                <div className="flex justify-end gap-2">
                                  <Button type="button" variant="outline" onClick={() => setPasswordDialogOpen(false)}>إلغاء</Button>
                                  <Button type="submit" className="bg-emerald hover:bg-emerald-hover">حفظ</Button>
                                </div>
                              </form>
                            </DialogContent>
                          </Dialog>
                          
                          {user.username !== 'admin' && (
                            <Button size="icon" variant="ghost" onClick={() => handleDeleteUser(user.username)}>
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </TabsContent>

        {/* Backup Tab */}
        <TabsContent value="backup" className="space-y-4">
          <Card className="p-6 border border-border/60">
            <h2 className="text-xl font-semibold mb-4">النسخ الاحتياطي واستعادة البيانات</h2>
            
            <div className="space-y-4">
              <div className="border-b pb-4">
                <h3 className="font-medium mb-2">تصدير نسخة احتياطية</h3>
                <p className="text-sm text-muted-foreground mb-3">احفظ نسخة احتياطية من جميع بياناتك</p>
                <Button onClick={exportBackup} disabled={loading} className="bg-emerald hover:bg-emerald-hover">
                  <Download className="h-4 w-4 me-2" />
                  تصدير
                </Button>
              </div>

              <div>
                <h3 className="font-medium mb-2">استيراد نسخة احتياطية</h3>
                <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3 mb-3">
                  <p className="text-sm text-yellow-800">⚠️ تحذير: سيتم استبدال جميع البيانات الحالية</p>
                </div>
                <input ref={fileInputRef} type="file" accept=".json" onChange={importBackup} style={{ display: 'none' }} />
                <Button onClick={() => fileInputRef.current?.click()} disabled={loading} variant="outline">
                  <Upload className="h-4 w-4 me-2" />
                  اختر ملف
                </Button>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
