import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../utils/api';
import { saveAs } from 'file-saver';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Label } from '../components/ui/label';
import { FileText, Download, Printer, RefreshCw, Share2 } from 'lucide-react';
import { toast } from 'sonner';
import { formatCurrency } from '../utils/exportHelpers';

// WhatsApp Share Helper
const shareViaWhatsApp = (text) => {
  const encodedText = encodeURIComponent(text);
  const whatsappUrl = `https://wa.me/?text=${encodedText}`;
  const newWindow = window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  if (!newWindow || newWindow.closed || typeof newWindow.closed === 'undefined') {
    window.location.href = whatsappUrl;
  }
  toast.success('جاري فتح WhatsApp...');
};

export default function Reports() {
  const { t, i18n } = useTranslation();
  const [fiscalYear, setFiscalYear] = useState('2025');
  const [selectedAccount, setSelectedAccount] = useState('');
  const [accounts, setAccounts] = useState([]);
  const [trialBalance, setTrialBalance] = useState(null);
  const [accountStatement, setAccountStatement] = useState(null);
  const [generalLedger, setGeneralLedger] = useState(null);
  const [loading, setLoading] = useState(false);
  const [downloading, setDownloading] = useState(null);

  useEffect(() => {
    loadAccounts();
  }, []);

  const loadAccounts = async () => {
    try {
      const response = await api.get('/accounts');
      setAccounts(response.data);
    } catch (error) {
      toast.error(t('error'));
    }
  };

  const loadTrialBalance = async () => {
    setLoading(true);
    try {
      const response = await api.get(`/reports/trial-balance?fiscal_year=${fiscalYear}`);
      setTrialBalance(response.data);
    } catch (error) {
      toast.error(t('error'));
    } finally {
      setLoading(false);
    }
  };

  const loadAccountStatement = async () => {
    if (!selectedAccount) {
      toast.error('يرجى اختيار حساب');
      return;
    }
    setLoading(true);
    try {
      const response = await api.get(`/reports/account-statement/${selectedAccount}?fiscal_year=${fiscalYear}`);
      setAccountStatement(response.data);
    } catch (error) {
      toast.error(t('error'));
    } finally {
      setLoading(false);
    }
  };

  const loadGeneralLedger = async () => {
    setLoading(true);
    try {
      const response = await api.get(`/reports/general-ledger?fiscal_year=${fiscalYear}`);
      setGeneralLedger(response.data);
    } catch (error) {
      toast.error(t('error'));
    } finally {
      setLoading(false);
    }
  };

  const downloadReport = async (reportType, format, accountCode = '') => {
    const key = `${reportType}-${format}`;
    setDownloading(key);
    try {
      let url = `/reports/export/${reportType}/${format}`;
      if (accountCode) {
        url += `/${accountCode}`;
      }
      url += `?fiscal_year=${fiscalYear}`;
      
      const response = await api.get(url, { responseType: 'blob' });
      
      const mimeTypes = {
        pdf: 'application/pdf',
        excel: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        word: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
      };
      
      const extensions = { pdf: 'pdf', excel: 'xlsx', word: 'docx' };
      const blob = new Blob([response.data], { type: mimeTypes[format] });
      saveAs(blob, `${reportType}_${fiscalYear}.${extensions[format]}`);
      
      toast.success('تم التحميل بنجاح');
    } catch (error) {
      console.error('Download error:', error);
      toast.error('حدث خطأ في التحميل');
    } finally {
      setDownloading(null);
    }
  };

  const printReport = () => {
    window.print();
  };

  // Generate WhatsApp share text for Trial Balance
  const shareTrialBalance = () => {
    if (!trialBalance) {
      toast.error('يرجى إنشاء التقرير أولاً');
      return;
    }
    
    const text = `📊 *ميزان المراجعة*
📅 السنة المالية: ${fiscalYear}

💰 *الملخص:*
• إجمالي المدين: ${formatCurrency(trialBalance.total_debit || 0)} ر.س
• إجمالي الدائن: ${formatCurrency(trialBalance.total_credit || 0)} ر.س
• عدد الحسابات: ${trialBalance.trial_balance?.length || 0}

🔗 للاطلاع على التفاصيل، يرجى الدخول إلى النظام المحاسبي`;

    shareViaWhatsApp(text);
  };

  // Generate WhatsApp share text for Account Statement
  const shareAccountStatement = () => {
    if (!accountStatement) {
      toast.error('يرجى إنشاء التقرير أولاً');
      return;
    }
    
    const account = accounts.find(a => a.account_code === selectedAccount);
    const transactions = accountStatement.transactions || [];
    const totalDebit = transactions.reduce((sum, t) => sum + (t.debit || 0), 0);
    const totalCredit = transactions.reduce((sum, t) => sum + (t.credit || 0), 0);
    
    const text = `📋 *كشف حساب*
📌 ${account?.account_name_ar || accountStatement.account?.account_name_ar || selectedAccount}
📅 السنة المالية: ${fiscalYear}

💰 *الملخص:*
• إجمالي المدين: ${formatCurrency(totalDebit)} ر.س
• إجمالي الدائن: ${formatCurrency(totalCredit)} ر.س
• الرصيد الختامي: ${formatCurrency(accountStatement.final_balance || 0)} ر.س
• عدد الحركات: ${transactions.length}

🔗 للاطلاع على التفاصيل، يرجى الدخول إلى النظام المحاسبي`;

    shareViaWhatsApp(text);
  };

  // Generate WhatsApp share text for General Ledger
  const shareGeneralLedger = () => {
    if (!generalLedger) {
      toast.error('يرجى إنشاء التقرير أولاً');
      return;
    }
    
    const ledger = generalLedger.ledger || [];
    const totalAccounts = ledger.length;
    
    const text = `📚 *دفتر الأستاذ العام*
📅 السنة المالية: ${fiscalYear}

💰 *الملخص:*
• عدد الحسابات: ${totalAccounts}

🔗 للاطلاع على التفاصيل، يرجى الدخول إلى النظام المحاسبي`;

    shareViaWhatsApp(text);
  };

  return (
    <div className="space-y-6" data-testid="reports-container">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t('reports')}</h1>
        <div className="flex items-center gap-2">
          <Label className="text-sm">السنة المالية:</Label>
          <Select value={fiscalYear} onValueChange={setFiscalYear}>
            <SelectTrigger className="w-28">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2025">2025</SelectItem>
              <SelectItem value="2026">2026</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="trial-balance" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="trial-balance" data-testid="trial-balance-tab">ميزان المراجعة</TabsTrigger>
          <TabsTrigger value="account-statement" data-testid="account-statement-tab">كشف حساب</TabsTrigger>
          <TabsTrigger value="general-ledger" data-testid="general-ledger-tab">دفتر الأستاذ</TabsTrigger>
        </TabsList>

        {/* Trial Balance */}
        <TabsContent value="trial-balance" className="space-y-4">
          <Card className="p-6 border border-border/60">
            <div className="flex flex-wrap gap-2 mb-4">
              <Button onClick={loadTrialBalance} className="bg-emerald hover:bg-emerald-hover" disabled={loading} data-testid="generate-trial-balance-button">
                {loading ? <RefreshCw className="h-4 w-4 me-2 animate-spin" /> : <FileText className="h-4 w-4 me-2" />}
                إنشاء التقرير
              </Button>
              {trialBalance && (
                <>
                  <Button variant="outline" onClick={printReport}>
                    <Printer className="h-4 w-4 me-2" />
                    طباعة
                  </Button>
                  <Button variant="outline" onClick={() => downloadReport('trial-balance', 'pdf')}>
                    <Download className="h-4 w-4 me-2" />
                    PDF
                  </Button>
                  <Button variant="outline" onClick={() => downloadReport('trial-balance', 'excel')}>
                    <Download className="h-4 w-4 me-2" />
                    Excel
                  </Button>
                  <Button variant="outline" onClick={shareTrialBalance} className="text-green-600 border-green-300 hover:bg-green-50" data-testid="share-trial-balance-whatsapp">
                    <Share2 className="h-4 w-4 me-2" />
                    WhatsApp
                  </Button>
                </>
              )}
            </div>

            {loading && <div className="text-center py-12">جاري التحميل...</div>}
            
            {trialBalance && !loading && (
              <div className="overflow-x-auto print:overflow-visible" id="trial-balance-print">
                {/* Report Header for Print */}
                <div className="hidden print:block text-center mb-6">
                  <h2 className="text-2xl font-bold">ميزان المراجعة</h2>
                  <p className="text-gray-600">للسنة المالية {fiscalYear}</p>
                </div>
                
                <table className="w-full border-collapse" data-testid="trial-balance-table">
                  <thead className="bg-emerald text-white print:bg-gray-800">
                    <tr>
                      <th className="px-3 py-3 text-start border">رمز الحساب</th>
                      <th className="px-3 py-3 text-start border">اسم الحساب</th>
                      <th className="px-3 py-3 text-center border" colSpan="2">الرصيد الافتتاحي</th>
                      <th className="px-3 py-3 text-center border" colSpan="2">الحركة خلال الفترة</th>
                      <th className="px-3 py-3 text-center border" colSpan="2">الرصيد النهائي</th>
                    </tr>
                    <tr className="bg-emerald/80 text-white print:bg-gray-700">
                      <th className="px-3 py-2 border"></th>
                      <th className="px-3 py-2 border"></th>
                      <th className="px-3 py-2 text-center border">مدين</th>
                      <th className="px-3 py-2 text-center border">دائن</th>
                      <th className="px-3 py-2 text-center border">مدين</th>
                      <th className="px-3 py-2 text-center border">دائن</th>
                      <th className="px-3 py-2 text-center border">مدين</th>
                      <th className="px-3 py-2 text-center border">دائن</th>
                    </tr>
                  </thead>
                  <tbody>
                    {trialBalance.trial_balance.map((item, idx) => {
                      // Calculate opening balance based on account type
                      const openingDebit = item.opening_debit || 0;
                      const openingCredit = item.opening_credit || 0;
                      
                      // Movement during period (from transactions)
                      const movementDebit = item.debit || 0;
                      const movementCredit = item.credit || 0;
                      
                      // Calculate ending balance
                      const endingDebit = openingDebit + movementDebit;
                      const endingCredit = openingCredit + movementCredit;
                      
                      // Net ending balance
                      const netBalance = endingDebit - endingCredit;
                      const finalDebit = netBalance > 0 ? netBalance : 0;
                      const finalCredit = netBalance < 0 ? Math.abs(netBalance) : 0;
                      
                      return (
                        <tr key={idx} className="border-b hover:bg-muted/30 print:hover:bg-transparent">
                          <td className="px-3 py-2 border font-mono">{item.account_code}</td>
                          <td className="px-3 py-2 border">{i18n.language === 'ar' ? item.account_name_ar : item.account_name_en}</td>
                          <td className="px-3 py-2 border text-end font-mono">{openingDebit > 0 ? formatCurrency(openingDebit) : '-'}</td>
                          <td className="px-3 py-2 border text-end font-mono">{openingCredit > 0 ? formatCurrency(openingCredit) : '-'}</td>
                          <td className="px-3 py-2 border text-end font-mono">{movementDebit > 0 ? formatCurrency(movementDebit) : '-'}</td>
                          <td className="px-3 py-2 border text-end font-mono">{movementCredit > 0 ? formatCurrency(movementCredit) : '-'}</td>
                          <td className="px-3 py-2 border text-end font-mono font-semibold">{finalDebit > 0 ? formatCurrency(finalDebit) : '-'}</td>
                          <td className="px-3 py-2 border text-end font-mono font-semibold">{finalCredit > 0 ? formatCurrency(finalCredit) : '-'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot className="bg-muted font-bold print:bg-gray-200">
                    <tr>
                      <td colSpan="2" className="px-3 py-3 border">الإجمالي</td>
                      <td className="px-3 py-3 border text-end font-mono">{formatCurrency(trialBalance.total_opening_debit || 0)}</td>
                      <td className="px-3 py-3 border text-end font-mono">{formatCurrency(trialBalance.total_opening_credit || 0)}</td>
                      <td className="px-3 py-3 border text-end font-mono">{formatCurrency(trialBalance.total_debit || 0)}</td>
                      <td className="px-3 py-3 border text-end font-mono">{formatCurrency(trialBalance.total_credit || 0)}</td>
                      <td className="px-3 py-3 border text-end font-mono text-emerald">{formatCurrency(trialBalance.total_ending_debit || trialBalance.total_debit || 0)}</td>
                      <td className="px-3 py-3 border text-end font-mono text-emerald">{formatCurrency(trialBalance.total_ending_credit || trialBalance.total_credit || 0)}</td>
                    </tr>
                  </tfoot>
                </table>
                
                {/* Balance Check */}
                <div className="mt-4 p-3 rounded-lg bg-muted">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">فحص التوازن:</span>
                    {Math.abs((trialBalance.total_debit || 0) - (trialBalance.total_credit || 0)) < 0.01 ? (
                      <span className="text-green-600 font-semibold">✓ الميزان متوازن</span>
                    ) : (
                      <span className="text-red-600 font-semibold">✗ الميزان غير متوازن - الفرق: {formatCurrency(Math.abs((trialBalance.total_debit || 0) - (trialBalance.total_credit || 0)))}</span>
                    )}
                  </div>
                </div>
              </div>
            )}

            {!trialBalance && !loading && (
              <div className="text-center py-12 text-muted-foreground">
                اضغط على "إنشاء التقرير" لعرض ميزان المراجعة
              </div>
            )}
          </Card>
        </TabsContent>

        {/* Account Statement */}
        <TabsContent value="account-statement" className="space-y-4">
          <Card className="p-6 border border-border/60">
            <div className="flex flex-wrap gap-4 mb-4 items-end">
              <div className="flex-1 min-w-[200px]">
                <Label>اختر الحساب</Label>
                <Select value={selectedAccount} onValueChange={setSelectedAccount}>
                  <SelectTrigger data-testid="account-statement-select">
                    <SelectValue placeholder="اختر حساب..." />
                  </SelectTrigger>
                  <SelectContent>
                    {accounts.map(acc => (
                      <SelectItem key={acc.account_code} value={acc.account_code}>
                        {acc.account_code} - {acc.account_name_ar}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={loadAccountStatement} className="bg-emerald hover:bg-emerald-hover" disabled={loading} data-testid="generate-account-statement-button">
                {loading ? <RefreshCw className="h-4 w-4 me-2 animate-spin" /> : <FileText className="h-4 w-4 me-2" />}
                إنشاء التقرير
              </Button>
            </div>

            {accountStatement && (
              <div className="flex flex-wrap gap-2 mb-4">
                <Button variant="outline" onClick={printReport}>
                  <Printer className="h-4 w-4 me-2" />
                  طباعة
                </Button>
                <Button variant="outline" onClick={() => downloadReport('account-statement', 'pdf', selectedAccount)}>
                  <Download className="h-4 w-4 me-2" />
                  PDF
                </Button>
                <Button variant="outline" onClick={() => downloadReport('account-statement', 'excel', selectedAccount)}>
                  <Download className="h-4 w-4 me-2" />
                  Excel
                </Button>
                <Button variant="outline" onClick={shareAccountStatement} className="text-green-600 border-green-300 hover:bg-green-50" data-testid="share-account-statement-whatsapp">
                  <Share2 className="h-4 w-4 me-2" />
                  WhatsApp
                </Button>
              </div>
            )}

            {loading && <div className="text-center py-12">جاري التحميل...</div>}
            
            {accountStatement && !loading && (
              <div className="overflow-x-auto">
                <div className="mb-4 p-4 bg-muted rounded-lg">
                  <h3 className="text-lg font-semibold">
                    {accountStatement.account.account_code} - {i18n.language === 'ar' ? accountStatement.account.account_name_ar : accountStatement.account.account_name_en}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    نوع الحساب: {accountStatement.account.account_type === 'asset' ? 'أصول' : 
                                 accountStatement.account.account_type === 'liability' ? 'خصوم' :
                                 accountStatement.account.account_type === 'equity' ? 'حقوق ملكية' :
                                 accountStatement.account.account_type === 'revenue' ? 'إيرادات' : 'مصروفات'}
                  </p>
                </div>
                
                <table className="w-full border-collapse" data-testid="account-statement-table">
                  <thead className="bg-emerald text-white">
                    <tr>
                      <th className="px-3 py-3 text-start border">التاريخ</th>
                      <th className="px-3 py-3 text-start border">البيان</th>
                      <th className="px-3 py-3 text-end border">مدين</th>
                      <th className="px-3 py-3 text-end border">دائن</th>
                      <th className="px-3 py-3 text-end border">الرصيد</th>
                    </tr>
                  </thead>
                  <tbody>
                    {accountStatement.transactions.map((txn, idx) => (
                      <tr key={idx} className="border-b hover:bg-muted/30">
                        <td className="px-3 py-2 border">{String(txn.date).substring(0, 10)}</td>
                        <td className="px-3 py-2 border">{txn.description}</td>
                        <td className="px-3 py-2 border text-end font-mono">{txn.debit > 0 ? formatCurrency(txn.debit) : '-'}</td>
                        <td className="px-3 py-2 border text-end font-mono">{txn.credit > 0 ? formatCurrency(txn.credit) : '-'}</td>
                        <td className="px-3 py-2 border text-end font-mono font-semibold">{formatCurrency(txn.balance)}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-muted font-bold">
                    <tr>
                      <td colSpan="4" className="px-3 py-3 border text-end">الرصيد النهائي:</td>
                      <td className="px-3 py-3 border text-end font-mono text-lg text-emerald">{formatCurrency(accountStatement.final_balance)}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}

            {!accountStatement && !loading && (
              <div className="text-center py-12 text-muted-foreground">
                اختر حساب ثم اضغط على "إنشاء التقرير"
              </div>
            )}
          </Card>
        </TabsContent>

        {/* General Ledger */}
        <TabsContent value="general-ledger" className="space-y-4">
          <Card className="p-6 border border-border/60">
            <div className="flex flex-wrap gap-2 mb-4">
              <Button onClick={loadGeneralLedger} className="bg-emerald hover:bg-emerald-hover" disabled={loading} data-testid="generate-general-ledger-button">
                {loading ? <RefreshCw className="h-4 w-4 me-2 animate-spin" /> : <FileText className="h-4 w-4 me-2" />}
                إنشاء التقرير
              </Button>
              {generalLedger && (
                <>
                  <Button variant="outline" onClick={printReport}>
                    <Printer className="h-4 w-4 me-2" />
                    طباعة
                  </Button>
                  <Button variant="outline" onClick={() => downloadReport('general-ledger', 'pdf')}>
                    <Download className="h-4 w-4 me-2" />
                    PDF
                  </Button>
                  <Button variant="outline" onClick={() => downloadReport('general-ledger', 'excel')}>
                    <Download className="h-4 w-4 me-2" />
                    Excel
                  </Button>
                  <Button variant="outline" onClick={shareGeneralLedger} className="text-green-600 border-green-300 hover:bg-green-50" data-testid="share-general-ledger-whatsapp">
                    <Share2 className="h-4 w-4 me-2" />
                    WhatsApp
                  </Button>
                </>
              )}
            </div>

            {loading && <div className="text-center py-12">جاري التحميل...</div>}
            
            {generalLedger && !loading && (
              <div className="space-y-6">
                {generalLedger.ledger.map((accountData, idx) => (
                  <div key={idx} className="border rounded-lg overflow-hidden">
                    <div className="bg-emerald/10 p-3 border-b">
                      <h3 className="font-semibold">
                        {accountData.account.account_code} - {i18n.language === 'ar' ? accountData.account.account_name_ar : accountData.account.account_name_en}
                      </h3>
                    </div>
                    {accountData.transactions.length > 0 ? (
                      <table className="w-full">
                        <thead className="bg-muted text-sm">
                          <tr>
                            <th className="px-3 py-2 text-start">التاريخ</th>
                            <th className="px-3 py-2 text-start">البيان</th>
                            <th className="px-3 py-2 text-end">مدين</th>
                            <th className="px-3 py-2 text-end">دائن</th>
                            <th className="px-3 py-2 text-end">الرصيد</th>
                          </tr>
                        </thead>
                        <tbody>
                          {accountData.transactions.map((txn, tIdx) => (
                            <tr key={tIdx} className="border-b text-sm">
                              <td className="px-3 py-2">{String(txn.date).substring(0, 10)}</td>
                              <td className="px-3 py-2">{txn.description}</td>
                              <td className="px-3 py-2 text-end font-mono">{txn.debit > 0 ? formatCurrency(txn.debit) : '-'}</td>
                              <td className="px-3 py-2 text-end font-mono">{txn.credit > 0 ? formatCurrency(txn.credit) : '-'}</td>
                              <td className="px-3 py-2 text-end font-mono font-semibold">{formatCurrency(txn.balance)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <div className="p-4 text-center text-muted-foreground text-sm">
                        لا توجد حركات
                      </div>
                    )}
                  </div>
                ))}
                <div className="text-center text-muted-foreground">
                  إجمالي الحسابات: {generalLedger.ledger.length}
                </div>
              </div>
            )}

            {!generalLedger && !loading && (
              <div className="text-center py-12 text-muted-foreground">
                اضغط على "إنشاء التقرير" لعرض دفتر الأستاذ العام
              </div>
            )}
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
