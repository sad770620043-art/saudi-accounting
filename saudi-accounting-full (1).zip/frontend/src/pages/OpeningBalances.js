import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../utils/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import { Plus, Trash2, Save, Search, AlertCircle, CheckCircle } from 'lucide-react';
import { formatCurrency } from '../utils/exportHelpers';
import { AccountCombobox } from '../components/AccountCombobox';

export default function OpeningBalances() {
  const { t, i18n } = useTranslation();
  const [accounts, setAccounts] = useState([]);
  const [balances, setBalances] = useState([]);
  const [fiscalYear, setFiscalYear] = useState('2025');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [newBalance, setNewBalance] = useState({
    account_code: '',
    debit: '',
    credit: ''
  });

  useEffect(() => {
    loadData();
  }, [fiscalYear]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [accountsRes, balancesRes] = await Promise.all([
        api.get('/accounts'),
        api.get(`/opening-balances?fiscal_year=${fiscalYear}`)
      ]);
      setAccounts(accountsRes.data);
      setBalances(balancesRes.data);
    } catch (error) {
      toast.error('حدث خطأ في تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  const handleAddBalance = async (e) => {
    e.preventDefault();
    
    if (!newBalance.account_code) {
      toast.error('يرجى اختيار حساب');
      return;
    }
    
    const debit = parseFloat(newBalance.debit) || 0;
    const credit = parseFloat(newBalance.credit) || 0;
    
    if (debit === 0 && credit === 0) {
      toast.error('يرجى إدخال مبلغ مدين أو دائن');
      return;
    }
    
    if (debit > 0 && credit > 0) {
      toast.error('لا يمكن إدخال مدين ودائن معاً - اختر واحد فقط');
      return;
    }
    
    setSaving(true);
    try {
      await api.post('/opening-balances', {
        account_code: newBalance.account_code,
        debit: debit,
        credit: credit,
        fiscal_year: fiscalYear
      });
      toast.success('تم إضافة الرصيد الافتتاحي بنجاح');
      loadData();
      setNewBalance({ account_code: '', debit: '', credit: '' });
    } catch (error) {
      toast.error(error.response?.data?.detail || 'حدث خطأ');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteBalance = async (accountCode) => {
    if (!window.confirm('هل أنت متأكد من حذف هذا الرصيد؟')) return;
    
    try {
      await api.delete(`/opening-balances/${accountCode}?fiscal_year=${fiscalYear}`);
      toast.success('تم حذف الرصيد بنجاح');
      loadData();
    } catch (error) {
      toast.error('حدث خطأ في الحذف');
    }
  };

  const getAccountName = (code) => {
    const acc = accounts.find(a => a.account_code === code);
    return acc ? (i18n.language === 'ar' ? acc.account_name_ar : acc.account_name_en) : code;
  };

  const getAccountType = (code) => {
    const acc = accounts.find(a => a.account_code === code);
    return acc?.account_type || '';
  };

  // Filter balances
  const filteredBalances = balances.filter(b => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    const name = getAccountName(b.account_code).toLowerCase();
    return b.account_code.toLowerCase().includes(term) || name.includes(term);
  });

  // Calculate totals
  const totalDebit = balances.reduce((sum, b) => sum + (b.debit || 0), 0);
  const totalCredit = balances.reduce((sum, b) => sum + (b.credit || 0), 0);
  const isBalanced = Math.abs(totalDebit - totalCredit) < 0.01;

  // Get accounts not yet in opening balances
  const availableAccounts = accounts.filter(acc => 
    !balances.some(b => b.account_code === acc.account_code)
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-xl text-muted-foreground">جاري التحميل...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="opening-balances-container">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">الأرصدة الافتتاحية</h1>
          <p className="text-sm text-muted-foreground">إدخال الأرصدة الافتتاحية لبداية السنة المالية</p>
        </div>
        <div className="flex items-center gap-3">
          <Label className="text-sm">السنة المالية:</Label>
          <Select value={fiscalYear} onValueChange={setFiscalYear}>
            <SelectTrigger className="w-28">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2025">2025</SelectItem>
              <SelectItem value="2026">2026</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Add Balance Form */}
      <Card className="p-6 border border-border/60">
        <h3 className="font-semibold mb-4">إضافة رصيد افتتاحي</h3>
        <form onSubmit={handleAddBalance} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
            <div className="md:col-span-2">
              <Label>الحساب</Label>
              <AccountCombobox
                accounts={availableAccounts}
                value={newBalance.account_code}
                onSelect={(code) => setNewBalance({...newBalance, account_code: code})}
                placeholder="اختر حساب..."
                language={i18n.language}
              />
            </div>
            <div>
              <Label>مدين (SAR)</Label>
              <Input
                type="number"
                step="0.01"
                value={newBalance.debit}
                onChange={(e) => setNewBalance({...newBalance, debit: e.target.value, credit: ''})}
                placeholder="0.00"
                className="text-end font-mono"
                data-testid="debit-input"
              />
            </div>
            <div>
              <Label>دائن (SAR)</Label>
              <Input
                type="number"
                step="0.01"
                value={newBalance.credit}
                onChange={(e) => setNewBalance({...newBalance, credit: e.target.value, debit: ''})}
                placeholder="0.00"
                className="text-end font-mono"
                data-testid="credit-input"
              />
            </div>
          </div>
          <div className="flex justify-end">
            <Button type="submit" className="bg-emerald hover:bg-emerald-hover" disabled={saving} data-testid="add-balance-button">
              <Plus className="h-4 w-4 me-2" />
              {saving ? 'جاري الحفظ...' : 'إضافة الرصيد'}
            </Button>
          </div>
        </form>
      </Card>

      {/* Balance Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4 border border-border/60">
          <p className="text-sm text-muted-foreground">إجمالي المدين</p>
          <p className="text-2xl font-bold text-blue-600 font-mono" dir="ltr">{formatCurrency(totalDebit)}</p>
        </Card>
        <Card className="p-4 border border-border/60">
          <p className="text-sm text-muted-foreground">إجمالي الدائن</p>
          <p className="text-2xl font-bold text-red-600 font-mono" dir="ltr">{formatCurrency(totalCredit)}</p>
        </Card>
        <Card className={`p-4 border-2 ${isBalanced ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'}`}>
          <p className="text-sm text-muted-foreground">حالة التوازن</p>
          <div className="flex items-center gap-2">
            {isBalanced ? (
              <>
                <CheckCircle className="h-6 w-6 text-green-600" />
                <span className="text-lg font-bold text-green-600">متوازن</span>
              </>
            ) : (
              <>
                <AlertCircle className="h-6 w-6 text-red-600" />
                <span className="text-lg font-bold text-red-600">
                  الفرق: {formatCurrency(Math.abs(totalDebit - totalCredit))}
                </span>
              </>
            )}
          </div>
        </Card>
      </div>

      {/* Search */}
      <Card className="p-4">
        <div className="relative">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="بحث بالرمز أو اسم الحساب..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="ps-9"
          />
        </div>
      </Card>

      {/* Balances Table */}
      <Card className="border border-border/60">
        <div className="overflow-x-auto">
          <table className="w-full" data-testid="balances-table">
            <thead className="bg-emerald text-white">
              <tr>
                <th className="px-4 py-3 text-start">رمز الحساب</th>
                <th className="px-4 py-3 text-start">اسم الحساب</th>
                <th className="px-4 py-3 text-start">النوع</th>
                <th className="px-4 py-3 text-end">مدين</th>
                <th className="px-4 py-3 text-end">دائن</th>
                <th className="px-4 py-3 text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filteredBalances.map((balance) => {
                const accountType = getAccountType(balance.account_code);
                return (
                  <tr key={balance.account_code} className="border-b border-border hover:bg-muted/30" data-testid={`balance-row-${balance.account_code}`}>
                    <td className="px-4 py-3 font-mono">{balance.account_code}</td>
                    <td className="px-4 py-3 font-medium">{getAccountName(balance.account_code)}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        accountType === 'asset' ? 'bg-blue-100 text-blue-700' :
                        accountType === 'liability' ? 'bg-red-100 text-red-700' :
                        accountType === 'equity' ? 'bg-purple-100 text-purple-700' :
                        accountType === 'revenue' ? 'bg-green-100 text-green-700' :
                        'bg-orange-100 text-orange-700'
                      }`}>
                        {accountType === 'asset' ? 'أصول' :
                         accountType === 'liability' ? 'خصوم' :
                         accountType === 'equity' ? 'حقوق ملكية' :
                         accountType === 'revenue' ? 'إيرادات' : 'مصروفات'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-end font-mono">
                      {balance.debit > 0 ? formatCurrency(balance.debit) : '-'}
                    </td>
                    <td className="px-4 py-3 text-end font-mono">
                      {balance.credit > 0 ? formatCurrency(balance.credit) : '-'}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        onClick={() => handleDeleteBalance(balance.account_code)}
                        data-testid={`delete-balance-${balance.account_code}`}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            {filteredBalances.length > 0 && (
              <tfoot className="bg-muted font-bold">
                <tr>
                  <td colSpan="3" className="px-4 py-3">الإجمالي</td>
                  <td className="px-4 py-3 text-end font-mono text-blue-600">{formatCurrency(totalDebit)}</td>
                  <td className="px-4 py-3 text-end font-mono text-red-600">{formatCurrency(totalCredit)}</td>
                  <td></td>
                </tr>
              </tfoot>
            )}
          </table>
          {filteredBalances.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              {searchTerm ? 'لا توجد نتائج للبحث' : 'لا توجد أرصدة افتتاحية - ابدأ بإضافة الأرصدة'}
            </div>
          )}
        </div>
      </Card>

      {/* Info Box */}
      <Card className="p-4 bg-blue-50 border-blue-200">
        <div className="flex gap-3">
          <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-blue-800">
            <p className="font-semibold mb-1">ملاحظات هامة:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>الأرصدة الافتتاحية هي أرصدة الحسابات في بداية السنة المالية</li>
              <li>يجب أن يكون إجمالي المدين مساوياً لإجمالي الدائن (الميزان متوازن)</li>
              <li>الأصول والمصروفات عادةً تكون مدينة، والخصوم وحقوق الملكية والإيرادات تكون دائنة</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
}
