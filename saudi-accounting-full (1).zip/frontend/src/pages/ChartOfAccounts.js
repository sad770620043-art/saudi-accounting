import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../utils/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card } from '../components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import { Plus, Edit, Trash2, Upload, Search, ChevronDown, ChevronRight, Folder, FileText, Filter, RefreshCcw, BarChart3 } from 'lucide-react';
import { cn } from '../lib/utils';

export default function ChartOfAccounts() {
  const { t, i18n } = useTranslation();
  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [expandedNodes, setExpandedNodes] = useState(new Set());
  const [accountStats, setAccountStats] = useState(null);
  const [resetConfirmOpen, setResetConfirmOpen] = useState(false);
  const [resetting, setResetting] = useState(false);
  const fileInputRef = useRef(null);
  
  const [currentAccount, setCurrentAccount] = useState({
    account_code: '',
    account_name_ar: '',
    account_name_en: '',
    account_type: 'asset',
    parent_code: '',
    level: 1,
    is_active: true
  });

  useEffect(() => {
    loadAccounts();
    loadStats();
  }, []);

  const loadAccounts = async () => {
    try {
      const response = await api.get('/accounts');
      setAccounts(response.data);
      const firstLevel = response.data.filter(a => a.level === 1).map(a => a.account_code);
      setExpandedNodes(new Set(firstLevel));
    } catch (error) {
      toast.error('حدث خطأ في تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  const loadStats = async () => {
    try {
      const response = await api.get('/accounts/stats');
      setAccountStats(response.data);
    } catch (error) {
      console.error('Failed to load stats');
    }
  };

  const handleResetToDefault = async () => {
    setResetting(true);
    try {
      const response = await api.post('/accounts/reset-to-default');
      toast.success(`${response.data.message} (${response.data.count} حساب)`);
      setResetConfirmOpen(false);
      loadAccounts();
      loadStats();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'حدث خطأ أثناء إعادة التعيين');
    } finally {
      setResetting(false);
    }
  };

  const buildTree = (accountsList) => {
    const map = {};
    const roots = [];
    
    accountsList.forEach(acc => {
      map[acc.account_code] = { ...acc, children: [] };
    });
    
    accountsList.forEach(acc => {
      if (acc.parent_code && map[acc.parent_code]) {
        map[acc.parent_code].children.push(map[acc.account_code]);
      } else if (!acc.parent_code || acc.level === 1) {
        roots.push(map[acc.account_code]);
      }
    });
    
    return roots;
  };

  const filteredAccounts = accounts.filter(account => {
    const matchesSearch = !searchTerm || 
      account.account_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      account.account_name_ar.toLowerCase().includes(searchTerm.toLowerCase()) ||
      account.account_name_en.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = filterType === 'all' || account.account_type === filterType;
    
    return matchesSearch && matchesType;
  });

  const accountTree = buildTree(filteredAccounts);

  const toggleNode = (code) => {
    setExpandedNodes(prev => {
      const newSet = new Set(prev);
      if (newSet.has(code)) {
        newSet.delete(code);
      } else {
        newSet.add(code);
      }
      return newSet;
    });
  };

  const expandAll = () => {
    setExpandedNodes(new Set(accounts.map(a => a.account_code)));
  };

  const collapseAll = () => {
    setExpandedNodes(new Set());
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editMode) {
        await api.put(`/accounts/${currentAccount.account_code}`, currentAccount);
      } else {
        await api.post('/accounts', currentAccount);
      }
      toast.success('تم الحفظ بنجاح');
      setDialogOpen(false);
      loadAccounts();
      resetForm();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'حدث خطأ');
    }
  };

  const handleDelete = async (code) => {
    if (window.confirm('هل أنت متأكد من حذف هذا الحساب؟')) {
      try {
        await api.delete(`/accounts/${code}`);
        toast.success('تم الحذف بنجاح');
        loadAccounts();
      } catch (error) {
        toast.error('حدث خطأ');
      }
    }
  };

  const resetForm = () => {
    setCurrentAccount({
      account_code: '',
      account_name_ar: '',
      account_name_en: '',
      account_type: 'asset',
      parent_code: '',
      level: 1,
      is_active: true
    });
    setEditMode(false);
  };

  const handleImportExcel = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await api.post('/accounts/import-excel', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      toast.success(`تم استيراد ${response.data.imported} حساب بنجاح!`);
      loadAccounts();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'فشل استيراد الملف');
    } finally {
      event.target.value = '';
    }
  };

  const openEditDialog = (account) => {
    setCurrentAccount(account);
    setEditMode(true);
    setDialogOpen(true);
  };

  const getTypeColor = (type) => {
    const colors = {
      asset: 'bg-blue-100 text-blue-700',
      liability: 'bg-red-100 text-red-700',
      equity: 'bg-purple-100 text-purple-700',
      revenue: 'bg-green-100 text-green-700',
      expense: 'bg-orange-100 text-orange-700'
    };
    return colors[type] || 'bg-gray-100 text-gray-700';
  };

  const getTypeLabel = (type) => {
    const labels = {
      asset: 'أصول',
      liability: 'خصوم',
      equity: 'حقوق ملكية',
      revenue: 'إيرادات',
      expense: 'مصروفات'
    };
    return labels[type] || type;
  };

  const renderTreeNode = (node, level) => {
    const hasChildren = node.children && node.children.length > 0;
    const isExpanded = expandedNodes.has(node.account_code);
    const paddingStart = level * 24 + 12;
    
    return (
      <div key={node.account_code}>
        <div 
          className="flex items-center gap-2 py-2 px-3 hover:bg-muted/50 rounded-lg cursor-pointer group border-b"
          style={{ paddingInlineStart: `${paddingStart}px` }}
        >
          <button
            onClick={() => toggleNode(node.account_code)}
            className={cn("p-0.5 rounded", hasChildren ? "hover:bg-muted" : "invisible")}
          >
            {hasChildren ? (
              isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />
            ) : <span className="w-4" />}
          </button>
          
          {hasChildren ? (
            <Folder className="h-4 w-4 text-amber-500" />
          ) : (
            <FileText className="h-4 w-4 text-muted-foreground" />
          )}
          
          <span className="font-mono text-sm text-muted-foreground w-20">{node.account_code}</span>
          <span className="flex-1 text-sm font-medium">
            {i18n.language === 'ar' ? node.account_name_ar : node.account_name_en}
          </span>
          
          <span className={cn("text-xs px-2 py-0.5 rounded-full", getTypeColor(node.account_type))}>
            {getTypeLabel(node.account_type)}
          </span>
          
          <div className="opacity-0 group-hover:opacity-100 flex gap-1">
            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={(e) => { e.stopPropagation(); openEditDialog(node); }}>
              <Edit className="h-3 w-3" />
            </Button>
            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={(e) => { e.stopPropagation(); handleDelete(node.account_code); }}>
              <Trash2 className="h-3 w-3 text-destructive" />
            </Button>
          </div>
        </div>
        
        {hasChildren && isExpanded && node.children.map(child => renderTreeNode(child, level + 1))}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-xl text-muted-foreground">جاري التحميل...</div>
      </div>
    );
  }

  return (
    <div className="space-y-4" data-testid="chart-of-accounts-container">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">دليل الحسابات</h1>
          <p className="text-sm text-muted-foreground">{accounts.length} حساب</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls"
            onChange={handleImportExcel}
            style={{ display: 'none' }}
          />
          
          {/* Reset to Default Button */}
          <Dialog open={resetConfirmOpen} onOpenChange={setResetConfirmOpen}>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                size="sm"
                className="text-orange-600 border-orange-300 hover:bg-orange-50"
                data-testid="reset-accounts-btn"
              >
                <RefreshCcw className="h-4 w-4 me-1" />
                إعادة تعيين ({accountStats?.default_available || 2145})
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle className="text-center text-lg">إعادة تعيين دليل الحسابات</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <p className="text-amber-800 text-sm font-medium mb-2">تحذير!</p>
                  <p className="text-amber-700 text-sm">
                    سيتم حذف جميع الحسابات الحالية ({accounts.length} حساب) واستبدالها بالدليل الافتراضي ({accountStats?.default_available || 2145} حساب).
                  </p>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-sm text-gray-600 mb-2">الدليل الجديد يتضمن:</p>
                  <ul className="text-sm text-gray-700 space-y-1">
                    <li>• {accountStats?.by_type?.asset || 560} حساب أصول</li>
                    <li>• {accountStats?.by_type?.liability || 528} حساب التزامات</li>
                    <li>• {accountStats?.by_type?.revenue || 177} حساب إيرادات</li>
                    <li>• {accountStats?.by_type?.expense || 880} حساب مصروفات</li>
                  </ul>
                </div>
                <div className="flex gap-2 justify-end pt-2">
                  <Button variant="outline" onClick={() => setResetConfirmOpen(false)}>
                    إلغاء
                  </Button>
                  <Button 
                    className="bg-orange-600 hover:bg-orange-700"
                    onClick={handleResetToDefault}
                    disabled={resetting}
                    data-testid="confirm-reset-btn"
                  >
                    {resetting ? 'جاري إعادة التعيين...' : 'تأكيد إعادة التعيين'}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Button 
            variant="outline" 
            size="sm"
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload className="h-4 w-4 me-1" />
            استيراد
          </Button>
          
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-emerald hover:bg-emerald-hover" size="sm" onClick={resetForm}>
                <Plus className="h-4 w-4 me-1" />
                إضافة حساب
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>{editMode ? 'تعديل الحساب' : 'إضافة حساب جديد'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>رمز الحساب</Label>
                    <Input
                      value={currentAccount.account_code}
                      onChange={(e) => setCurrentAccount({...currentAccount, account_code: e.target.value})}
                      required
                      disabled={editMode}
                      placeholder="مثال: 11000"
                      className="font-mono"
                    />
                  </div>
                  <div>
                    <Label>نوع الحساب</Label>
                    <Select
                      value={currentAccount.account_type}
                      onValueChange={(value) => setCurrentAccount({...currentAccount, account_type: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="asset">أصول</SelectItem>
                        <SelectItem value="liability">خصوم</SelectItem>
                        <SelectItem value="equity">حقوق ملكية</SelectItem>
                        <SelectItem value="revenue">إيرادات</SelectItem>
                        <SelectItem value="expense">مصروفات</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div>
                  <Label>اسم الحساب بالعربية</Label>
                  <Input
                    value={currentAccount.account_name_ar}
                    onChange={(e) => setCurrentAccount({...currentAccount, account_name_ar: e.target.value})}
                    required
                    placeholder="مثال: النقدية في الصندوق"
                  />
                </div>
                
                <div>
                  <Label>اسم الحساب بالإنجليزية</Label>
                  <Input
                    value={currentAccount.account_name_en}
                    onChange={(e) => setCurrentAccount({...currentAccount, account_name_en: e.target.value})}
                    required
                    placeholder="e.g. Cash in Hand"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>المستوى</Label>
                    <Select
                      value={String(currentAccount.level)}
                      onValueChange={(value) => setCurrentAccount({...currentAccount, level: parseInt(value)})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">المستوى 1 (رئيسي)</SelectItem>
                        <SelectItem value="2">المستوى 2 (فرعي)</SelectItem>
                        <SelectItem value="3">المستوى 3 (تفصيلي)</SelectItem>
                        <SelectItem value="4">المستوى 4</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>الحساب الرئيسي</Label>
                    <Select
                      value={currentAccount.parent_code || 'none'}
                      onValueChange={(value) => setCurrentAccount({...currentAccount, parent_code: value === 'none' ? '' : value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر الحساب الرئيسي" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">بدون (حساب رئيسي)</SelectItem>
                        {accounts.filter(a => a.level < currentAccount.level).map(acc => (
                          <SelectItem key={acc.account_code} value={acc.account_code}>
                            {acc.account_code} - {acc.account_name_ar}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="flex justify-end gap-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    إلغاء
                  </Button>
                  <Button type="submit" className="bg-emerald hover:bg-emerald-hover">
                    حفظ
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card className="p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="بحث بالرمز أو الاسم..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="ps-9"
            />
          </div>
          
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-40">
              <Filter className="h-4 w-4 me-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">الكل</SelectItem>
              <SelectItem value="asset">أصول</SelectItem>
              <SelectItem value="liability">خصوم</SelectItem>
              <SelectItem value="equity">حقوق ملكية</SelectItem>
              <SelectItem value="revenue">إيرادات</SelectItem>
              <SelectItem value="expense">مصروفات</SelectItem>
            </SelectContent>
          </Select>
          
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={expandAll}>توسيع الكل</Button>
            <Button variant="outline" size="sm" onClick={collapseAll}>طي الكل</Button>
          </div>
        </div>
      </Card>

      <Card className="p-2">
        {accountTree.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            {searchTerm ? 'لا توجد نتائج للبحث' : 'لا توجد حسابات'}
          </div>
        ) : (
          <div>
            {accountTree.map(node => renderTreeNode(node, 0))}
          </div>
        )}
      </Card>
    </div>
  );
}
