import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../utils/api';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import { Plus, Edit, Trash2, FolderKanban, Search, Calendar, DollarSign } from 'lucide-react';
import { formatDate } from '../utils/exportHelpers';

export default function Projects() {
  const { t, i18n } = useTranslation();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  
  const [currentProject, setCurrentProject] = useState({
    project_code: '',
    project_name_ar: '',
    project_name_en: '',
    client_name: '',
    start_date: '',
    end_date: '',
    budget: 0,
    status: 'active',
    description: '',
    is_active: true
  });

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    try {
      const response = await api.get('/projects');
      setProjects(response.data);
    } catch (error) {
      toast.error('حدث خطأ في تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editMode) {
        await api.put(`/projects/${currentProject.project_code}`, currentProject);
        toast.success('تم تحديث المشروع بنجاح');
      } else {
        await api.post('/projects', currentProject);
        toast.success('تم إنشاء المشروع بنجاح');
      }
      setDialogOpen(false);
      loadProjects();
      resetForm();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'حدث خطأ');
    }
  };

  const handleEdit = (project) => {
    setCurrentProject({
      ...project,
      start_date: project.start_date || '',
      end_date: project.end_date || ''
    });
    setEditMode(true);
    setDialogOpen(true);
  };

  const handleDelete = async (projectCode) => {
    if (!confirm('هل أنت متأكد من حذف المشروع؟')) return;
    try {
      await api.delete(`/projects/${projectCode}`);
      toast.success('تم حذف المشروع بنجاح');
      loadProjects();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'حدث خطأ');
    }
  };

  const resetForm = () => {
    setCurrentProject({
      project_code: '',
      project_name_ar: '',
      project_name_en: '',
      client_name: '',
      start_date: '',
      end_date: '',
      budget: 0,
      status: 'active',
      description: '',
      is_active: true
    });
    setEditMode(false);
  };

  const getStatusBadge = (status) => {
    const styles = {
      active: 'bg-green-100 text-green-700',
      completed: 'bg-blue-100 text-blue-700',
      on_hold: 'bg-yellow-100 text-yellow-700',
      cancelled: 'bg-red-100 text-red-700'
    };
    const labels = {
      active: 'نشط',
      completed: 'مكتمل',
      on_hold: 'معلق',
      cancelled: 'ملغي'
    };
    return (
      <span className={`px-2 py-1 rounded-full text-xs ${styles[status] || styles.active}`}>
        {labels[status] || status}
      </span>
    );
  };

  const filteredProjects = projects.filter(project => {
    if (filterStatus !== 'all' && project.status !== filterStatus) return false;
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      project.project_code.toLowerCase().includes(term) ||
      project.project_name_ar.toLowerCase().includes(term) ||
      (project.project_name_en || '').toLowerCase().includes(term) ||
      (project.client_name || '').toLowerCase().includes(term)
    );
  });

  // Calculate stats
  const stats = {
    total: projects.length,
    active: projects.filter(p => p.status === 'active').length,
    completed: projects.filter(p => p.status === 'completed').length,
    totalBudget: projects.reduce((sum, p) => sum + (p.budget || 0), 0)
  };

  if (loading) {
    return <div className="text-center py-12">جاري التحميل...</div>;
  }

  return (
    <div className="space-y-6" data-testid="projects-container">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <FolderKanban className="h-8 w-8 text-emerald" />
          <div>
            <h1 className="text-2xl font-bold">المشاريع</h1>
            <p className="text-sm text-muted-foreground">{projects.length} مشروع</p>
          </div>
        </div>
        
        <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) resetForm(); }}>
          <DialogTrigger asChild>
            <Button className="bg-emerald hover:bg-emerald-hover" data-testid="add-project-btn">
              <Plus className="h-4 w-4 me-2" />
              إضافة مشروع
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{editMode ? 'تعديل المشروع' : 'إضافة مشروع جديد'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>رمز المشروع *</Label>
                  <Input
                    value={currentProject.project_code}
                    onChange={(e) => setCurrentProject({...currentProject, project_code: e.target.value})}
                    required
                    disabled={editMode}
                    placeholder="PRJ001"
                    data-testid="project-code-input"
                  />
                </div>
                <div>
                  <Label>حالة المشروع</Label>
                  <Select 
                    value={currentProject.status} 
                    onValueChange={(val) => setCurrentProject({...currentProject, status: val})}
                  >
                    <SelectTrigger data-testid="project-status-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">نشط</SelectItem>
                      <SelectItem value="completed">مكتمل</SelectItem>
                      <SelectItem value="on_hold">معلق</SelectItem>
                      <SelectItem value="cancelled">ملغي</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label>اسم المشروع بالعربي *</Label>
                <Input
                  value={currentProject.project_name_ar}
                  onChange={(e) => setCurrentProject({...currentProject, project_name_ar: e.target.value})}
                  required
                  placeholder="مشروع تطوير النظام"
                  data-testid="project-name-ar-input"
                />
              </div>
              
              <div>
                <Label>اسم المشروع بالإنجليزي</Label>
                <Input
                  value={currentProject.project_name_en}
                  onChange={(e) => setCurrentProject({...currentProject, project_name_en: e.target.value})}
                  placeholder="System Development Project"
                />
              </div>
              
              <div>
                <Label>اسم العميل</Label>
                <Input
                  value={currentProject.client_name}
                  onChange={(e) => setCurrentProject({...currentProject, client_name: e.target.value})}
                  placeholder="شركة العميل"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>تاريخ البداية</Label>
                  <Input
                    type="date"
                    value={currentProject.start_date}
                    onChange={(e) => setCurrentProject({...currentProject, start_date: e.target.value})}
                  />
                </div>
                <div>
                  <Label>تاريخ النهاية</Label>
                  <Input
                    type="date"
                    value={currentProject.end_date}
                    onChange={(e) => setCurrentProject({...currentProject, end_date: e.target.value})}
                  />
                </div>
              </div>
              
              <div>
                <Label>الميزانية (ريال)</Label>
                <Input
                  type="number"
                  value={currentProject.budget}
                  onChange={(e) => setCurrentProject({...currentProject, budget: parseFloat(e.target.value) || 0})}
                  placeholder="0.00"
                  data-testid="project-budget-input"
                />
              </div>
              
              <div>
                <Label>الوصف</Label>
                <Input
                  value={currentProject.description}
                  onChange={(e) => setCurrentProject({...currentProject, description: e.target.value})}
                  placeholder="وصف المشروع"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  إلغاء
                </Button>
                <Button type="submit" className="bg-emerald hover:bg-emerald-hover" data-testid="save-project-btn">
                  {editMode ? 'تحديث' : 'حفظ'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <FolderKanban className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">إجمالي المشاريع</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </div>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-100 rounded-lg">
              <FolderKanban className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">مشاريع نشطة</p>
              <p className="text-2xl font-bold">{stats.active}</p>
            </div>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <FolderKanban className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">مشاريع مكتملة</p>
              <p className="text-2xl font-bold">{stats.completed}</p>
            </div>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-100 rounded-lg">
              <DollarSign className="h-5 w-5 text-emerald" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">إجمالي الميزانيات</p>
              <p className="text-xl font-bold">{stats.totalBudget.toLocaleString()} ر.س</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Search and Filter */}
      <Card className="p-4">
        <div className="flex gap-4 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute start-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="بحث بالرمز أو الاسم أو العميل..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="ps-10"
              data-testid="search-projects-input"
            />
          </div>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="الحالة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الحالات</SelectItem>
              <SelectItem value="active">نشط</SelectItem>
              <SelectItem value="completed">مكتمل</SelectItem>
              <SelectItem value="on_hold">معلق</SelectItem>
              <SelectItem value="cancelled">ملغي</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Table */}
      <Card className="border border-border/60">
        <div className="overflow-x-auto">
          <table className="w-full" data-testid="projects-table">
            <thead className="bg-muted">
              <tr>
                <th className="px-4 py-3 text-start">الرمز</th>
                <th className="px-4 py-3 text-start">اسم المشروع</th>
                <th className="px-4 py-3 text-start">العميل</th>
                <th className="px-4 py-3 text-start">الميزانية</th>
                <th className="px-4 py-3 text-start">الفترة</th>
                <th className="px-4 py-3 text-start">الحالة</th>
                <th className="px-4 py-3 text-start">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filteredProjects.map((project) => (
                <tr key={project.project_code} className="border-b border-border hover:bg-muted/30" data-testid={`project-row-${project.project_code}`}>
                  <td className="px-4 py-3 font-medium">{project.project_code}</td>
                  <td className="px-4 py-3">
                    <div>
                      <div>{project.project_name_ar}</div>
                      {project.project_name_en && (
                        <div className="text-xs text-muted-foreground">{project.project_name_en}</div>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">{project.client_name || '-'}</td>
                  <td className="px-4 py-3">{(project.budget || 0).toLocaleString()} ر.س</td>
                  <td className="px-4 py-3 text-sm">
                    {project.start_date && (
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {project.start_date}
                        {project.end_date && ` - ${project.end_date}`}
                      </div>
                    )}
                    {!project.start_date && '-'}
                  </td>
                  <td className="px-4 py-3">{getStatusBadge(project.status)}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <Button size="icon" variant="ghost" onClick={() => handleEdit(project)} data-testid={`edit-project-${project.project_code}`}>
                        <Edit className="h-4 w-4 text-blue-500" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => handleDelete(project.project_code)} data-testid={`delete-project-${project.project_code}`}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredProjects.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              {searchTerm || filterStatus !== 'all' ? 'لا توجد نتائج للبحث' : 'لا توجد مشاريع. ابدأ بإضافة مشروع جديد.'}
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
