import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../contexts/AuthContext';
import api from '../utils/api';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { toast } from 'sonner';
import { Lock, User } from 'lucide-react';

export default function Login() {
  const { t, i18n } = useTranslation();
  const { login } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const isRTL = i18n.language === 'ar';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await api.post('/auth/login', { username, password });
      login(response.data.token, { username: response.data.username, full_name: response.data.full_name });
      toast.success(t('success'));
      navigate('/dashboard');
    } catch (error) {
      toast.error(error.response?.data?.detail || t('error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left side - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md space-y-8">
          {/* Logo/Title */}
          <div className={`space-y-2 ${isRTL ? 'text-right' : 'text-left'}`}>
            <h1 className="text-4xl font-bold text-emerald" data-testid="login-title">
              {t('welcomeBack')}
            </h1>
            <p className="text-muted-foreground">{t('enterCredentials')}</p>
          </div>

          {/* Default Credentials Notice */}
          <div className="p-4 bg-emerald/10 border border-emerald/30 rounded-md space-y-2">
            <h3 className="font-semibold text-emerald">{isRTL ? 'بيانات الدخول الافتراضية' : 'Default Login Credentials'}</h3>
            <div className="space-y-1 text-sm">
              <p><strong>{isRTL ? 'اسم المستخدم:' : 'Username:'}</strong> <code className="px-2 py-1 bg-white rounded">admin</code></p>
              <p><strong>{isRTL ? 'كلمة المرور:' : 'Password:'}</strong> <code className="px-2 py-1 bg-white rounded">admin123</code></p>
            </div>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-6" data-testid="login-form">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-start block">
                {t('username')}
              </Label>
              <div className="relative">
                <User className={`absolute top-3 ${isRTL ? 'right-3' : 'left-3'} h-5 w-5 text-muted-foreground`} />
                <Input
                  id="username"
                  data-testid="username-input"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className={`${isRTL ? 'pr-10' : 'pl-10'}`}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-start block">
                {t('password')}
              </Label>
              <div className="relative">
                <Lock className={`absolute top-3 ${isRTL ? 'right-3' : 'left-3'} h-5 w-5 text-muted-foreground`} />
                <Input
                  id="password"
                  data-testid="password-input"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`${isRTL ? 'pr-10' : 'pl-10'}`}
                  required
                />
              </div>
            </div>

            <Button
              type="submit"
              data-testid="login-submit-button"
              className="w-full bg-emerald hover:bg-emerald-hover transition-colors duration-200"
              disabled={loading}
            >
              {loading ? t('loading') : t('login')}
            </Button>
          </form>

          {/* Language Toggle */}
          <div className="flex justify-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => i18n.changeLanguage('ar')}
              className={i18n.language === 'ar' ? 'bg-emerald/10' : ''}
              data-testid="language-ar-button"
            >
              العربية
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => i18n.changeLanguage('en')}
              className={i18n.language === 'en' ? 'bg-emerald/10' : ''}
              data-testid="language-en-button"
            >
              English
            </Button>
          </div>
        </div>
      </div>

      {/* Right side - Image/Branding */}
      <div 
        className="hidden lg:block lg:w-1/2 bg-cover bg-center relative"
        style={{
          backgroundImage: 'url(https://images.unsplash.com/photo-1770836560507-ba33be89e547?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1ODF8MHwxfHNlYXJjaHwzfHxyaXlhZGglMjBtb2Rlcm4lMjBhcmNoaXRlY3R1cmUlMjBhYnN0cmFjdHxlbnwwfHx8fDE3NzQ0NTY4NTV8MA&ixlib=rb-4.1.0&q=85)'
        }}
      >
        <div className="absolute inset-0 bg-emerald/70 backdrop-blur-sm flex items-center justify-center">
          <div className="text-center text-white p-8">
            <h2 className="text-5xl font-bold mb-4">SUAS</h2>
            <p className="text-2xl">Saudi Unified Accounting System</p>
            <p className="text-xl mt-2">النظام المحاسبي السعودي الموحد</p>
          </div>
        </div>
      </div>
    </div>
  );
}