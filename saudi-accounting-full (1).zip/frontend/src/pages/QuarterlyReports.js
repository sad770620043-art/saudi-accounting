import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import api, { getTenantId } from '../utils/api';
import { saveAs } from 'file-saver';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { toast } from 'sonner';
import { 
  CalendarRange, 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  ArrowRightLeft,
  Sparkles,
  RefreshCw,
  Download,
  Share2,
  Printer,
  ChevronDown,
  ChevronUp,
  Building2,
  History,
  Plus,
  GitCompare,
  Trash2
} from 'lucide-react';
import { formatCurrency } from '../utils/exportHelpers';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  ComposedChart,
  Area
} from 'recharts';

const COLORS = ['#10b981', '#ef4444', '#f59e0b', '#3b82f6', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];

export default function QuarterlyReports() {
  const { t, i18n } = useTranslation();
  const currentYear = new Date().getFullYear();
  const currentQuarter = Math.ceil((new Date().getMonth() + 1) / 3);
  
  const [year, setYear] = useState(currentYear);
  const [quarter, setQuarter] = useState(currentQuarter);
  const [reportData, setReportData] = useState(null);
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loadingAi, setLoadingAi] = useState(false);
  const [showAiSection, setShowAiSection] = useState(false);
  const [exportingPdf, setExportingPdf] = useState(false);
  const [exportingPptx, setExportingPptx] = useState(false);
  
  // New states for comparison and historical data
  const [comparisonData, setComparisonData] = useState(null);
  const [historicalDialogOpen, setHistoricalDialogOpen] = useState(false);
  const [historicalData, setHistoricalData] = useState([]);
  const [savingHistorical, setSavingHistorical] = useState(false);
  const [newHistoricalData, setNewHistoricalData] = useState({
    year: currentYear - 1,
    total_revenue: 0,
    total_expense: 0,
    net_profit: 0,
    closing_cash_balance: 0,
    closing_bank_balance: 0,
    notes: '',
    q1_revenue: 0, q1_expense: 0,
    q2_revenue: 0, q2_expense: 0,
    q3_revenue: 0, q3_expense: 0,
    q4_revenue: 0, q4_expense: 0
  });

  useEffect(() => {
    loadReport();
    loadComparison();
  }, [year, quarter]);

  useEffect(() => {
    loadHistoricalData();
  }, []);

  const loadReport = async () => {
    setLoading(true);
    setAiAnalysis(null);
    try {
      const response = await api.get(`/reports/quarterly?year=${year}&quarter=${quarter}`);
      setReportData(response.data);
    } catch (error) {
      toast.error('حدث خطأ في تحميل التقرير');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const loadComparison = async () => {
    try {
      const response = await api.get(`/reports/quarterly/comparison?year=${year}&quarter=${quarter}`);
      setComparisonData(response.data);
    } catch (error) {
      console.error('Error loading comparison:', error);
    }
  };

  const loadHistoricalData = async () => {
    try {
      const response = await api.get('/historical-data');
      setHistoricalData(response.data);
    } catch (error) {
      console.error('Error loading historical data:', error);
    }
  };

  const saveHistoricalData = async () => {
    setSavingHistorical(true);
    try {
      // Calculate net profit if not set
      const dataToSave = {
        ...newHistoricalData,
        net_profit: newHistoricalData.total_revenue - newHistoricalData.total_expense
      };
      await api.post('/historical-data', dataToSave);
      toast.success(`تم حفظ بيانات سنة ${newHistoricalData.year} بنجاح`);
      setHistoricalDialogOpen(false);
      loadHistoricalData();
      loadComparison();
      // Reset form
      setNewHistoricalData({
        year: currentYear - 1,
        total_revenue: 0,
        total_expense: 0,
        net_profit: 0,
        closing_cash_balance: 0,
        closing_bank_balance: 0,
        notes: '',
        q1_revenue: 0, q1_expense: 0,
        q2_revenue: 0, q2_expense: 0,
        q3_revenue: 0, q3_expense: 0,
        q4_revenue: 0, q4_expense: 0
      });
    } catch (error) {
      toast.error('حدث خطأ في حفظ البيانات');
      console.error(error);
    } finally {
      setSavingHistorical(false);
    }
  };

  const deleteHistoricalData = async (yearToDelete) => {
    if (!confirm(`هل أنت متأكد من حذف بيانات سنة ${yearToDelete}؟`)) return;
    try {
      await api.delete(`/historical-data/${yearToDelete}`);
      toast.success('تم حذف البيانات بنجاح');
      loadHistoricalData();
      loadComparison();
    } catch (error) {
      toast.error('حدث خطأ في حذف البيانات');
    }
  };

  const loadAiAnalysis = async () => {
    if (!reportData) return;
    
    setLoadingAi(true);
    setShowAiSection(true);
    try {
      const response = await api.post('/reports/quarterly/ai-analysis', {
        report_data: reportData
      });
      setAiAnalysis(response.data);
    } catch (error) {
      toast.error('حدث خطأ في تحليل الذكاء الاصطناعي');
      console.error(error);
    } finally {
      setLoadingAi(false);
    }
  };

  const shareViaWhatsApp = () => {
    if (!reportData) {
      toast.error('يرجى تحميل التقرير أولاً');
      return;
    }
    const { summary, totals, period } = reportData;
    
    const text = `📊 *التقرير الربعي - Q${period.quarter} ${period.year}*

💰 *ملخص الأداء المالي:*
• إجمالي الإيرادات: ${formatCurrency(totals.total_revenue)} ر.س
• إجمالي المصروفات: ${formatCurrency(totals.total_expense)} ر.س
• صافي الربح: ${formatCurrency(totals.net_profit)} ر.س
• هامش الربح: ${totals.profit_margin}%

🏦 الرصيد المتاح في البنك: ${formatCurrency(summary.bank_balance)} ر.س

📈 الرصيد المرحل من الفترة السابقة:
• إيرادات: ${formatCurrency(summary.carried_forward.revenue)} ر.س
• مصروفات: ${formatCurrency(summary.carried_forward.expense)} ر.س`;

    // Use location.href instead of window.open to avoid popup blockers
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(text)}`;
    const newWindow = window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    if (!newWindow || newWindow.closed || typeof newWindow.closed === 'undefined') {
      // Popup was blocked, use direct navigation
      window.location.href = whatsappUrl;
    }
    toast.success('جاري فتح WhatsApp...');
  };

  const exportPdf = async () => {
    if (!reportData) {
      toast.error('يرجى تحميل التقرير أولاً');
      return;
    }
    setExportingPdf(true);
    try {
      const response = await api.get(`/reports/quarterly/export/pdf?year=${year}&quarter=${quarter}`, {
        responseType: 'blob'
      });
      const blob = new Blob([response.data], { type: 'application/pdf' });
      saveAs(blob, `quarterly_report_Q${quarter}_${year}.pdf`);
      toast.success('تم تحميل ملف PDF بنجاح');
    } catch (error) {
      console.error('PDF export error:', error);
      toast.error('حدث خطأ في تصدير PDF');
    } finally {
      setExportingPdf(false);
    }
  };

  const exportPptx = async () => {
    if (!reportData) {
      toast.error('يرجى تحميل التقرير أولاً');
      return;
    }
    setExportingPptx(true);
    try {
      const response = await api.get(`/reports/quarterly/export/pptx?year=${year}&quarter=${quarter}`, {
        responseType: 'blob'
      });
      const blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation' });
      saveAs(blob, `quarterly_report_Q${quarter}_${year}.pptx`);
      toast.success('تم تحميل ملف PowerPoint بنجاح');
    } catch (error) {
      console.error('PPTX export error:', error);
      toast.error('حدث خطأ في تصدير PowerPoint');
    } finally {
      setExportingPptx(false);
    }
  };

  const printReport = () => {
    window.print();
  };

  const years = Array.from({ length: 5 }, (_, i) => currentYear - 2 + i);
  const quarters = [
    { value: 1, label: 'Q1 (يناير - مارس)' },
    { value: 2, label: 'Q2 (أبريل - يونيو)' },
    { value: 3, label: 'Q3 (يوليو - سبتمبر)' },
    { value: 4, label: 'Q4 (أكتوبر - ديسمبر)' }
  ];

  const summary = reportData?.summary || {};
  const totals = reportData?.totals || {};
  const chartData = reportData?.chart_data || [];

  // Prepare pie chart data
  const pieData = reportData?.top_expense_accounts?.slice(0, 5).map((acc, idx) => ({
    name: acc.account_name,
    value: acc.amount,
    color: COLORS[idx % COLORS.length]
  })) || [];

  return (
    <div className="space-y-6 print:space-y-4" data-testid="quarterly-reports-container">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-gradient-to-br from-emerald to-teal-500 rounded-xl shadow-lg">
            <CalendarRange className="h-7 w-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">التقارير الربعية</h1>
            <p className="text-sm text-muted-foreground">تحليل الإيرادات والمصروفات</p>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2 print:hidden">
          <Select value={String(year)} onValueChange={(v) => setYear(parseInt(v))}>
            <SelectTrigger className="w-[120px]" data-testid="year-select">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {years.map(y => (
                <SelectItem key={y} value={String(y)}>{y}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={String(quarter)} onValueChange={(v) => setQuarter(parseInt(v))}>
            <SelectTrigger className="w-[180px]" data-testid="quarter-select">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {quarters.map(q => (
                <SelectItem key={q.value} value={String(q.value)}>{q.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Button variant="outline" onClick={loadReport} disabled={loading}>
            <RefreshCw className={`h-4 w-4 me-1 ${loading ? 'animate-spin' : ''}`} />
            تحديث
          </Button>
          
          {/* Historical Data Dialog */}
          <Dialog open={historicalDialogOpen} onOpenChange={setHistoricalDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="text-purple-600 border-purple-300 hover:bg-purple-50">
                <History className="h-4 w-4 me-1" />
                بيانات سابقة
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <History className="h-5 w-5 text-purple-500" />
                  إدخال بيانات السنوات السابقة
                </DialogTitle>
              </DialogHeader>
              
              <Tabs defaultValue="add" className="mt-4">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="add">إضافة بيانات جديدة</TabsTrigger>
                  <TabsTrigger value="view">عرض البيانات المحفوظة</TabsTrigger>
                </TabsList>
                
                <TabsContent value="add" className="space-y-4 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>السنة *</Label>
                      <Select 
                        value={String(newHistoricalData.year)} 
                        onValueChange={(v) => setNewHistoricalData({...newHistoricalData, year: parseInt(v)})}
                      >
                        <SelectTrigger data-testid="historical-year-select">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Array.from({ length: 10 }, (_, i) => currentYear - 1 - i).map(y => (
                            <SelectItem key={y} value={String(y)}>{y}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>ملاحظات</Label>
                      <Input
                        value={newHistoricalData.notes}
                        onChange={(e) => setNewHistoricalData({...newHistoricalData, notes: e.target.value})}
                        placeholder="ملاحظات اختيارية"
                      />
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="font-medium mb-3">الملخص السنوي</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>إجمالي الإيرادات السنوية</Label>
                        <Input
                          type="number"
                          value={newHistoricalData.total_revenue}
                          onChange={(e) => setNewHistoricalData({...newHistoricalData, total_revenue: parseFloat(e.target.value) || 0})}
                          data-testid="historical-total-revenue"
                        />
                      </div>
                      <div>
                        <Label>إجمالي المصروفات السنوية</Label>
                        <Input
                          type="number"
                          value={newHistoricalData.total_expense}
                          onChange={(e) => setNewHistoricalData({...newHistoricalData, total_expense: parseFloat(e.target.value) || 0})}
                          data-testid="historical-total-expense"
                        />
                      </div>
                      <div>
                        <Label>رصيد الصندوق الختامي</Label>
                        <Input
                          type="number"
                          value={newHistoricalData.closing_cash_balance}
                          onChange={(e) => setNewHistoricalData({...newHistoricalData, closing_cash_balance: parseFloat(e.target.value) || 0})}
                        />
                      </div>
                      <div>
                        <Label>رصيد البنك الختامي</Label>
                        <Input
                          type="number"
                          value={newHistoricalData.closing_bank_balance}
                          onChange={(e) => setNewHistoricalData({...newHistoricalData, closing_bank_balance: parseFloat(e.target.value) || 0})}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-blue-50 rounded-lg p-4">
                    <h4 className="font-medium mb-3">البيانات الربعية (اختياري)</h4>
                    <div className="grid grid-cols-4 gap-3 text-sm">
                      {[1, 2, 3, 4].map(q => (
                        <div key={q} className="space-y-2">
                          <p className="font-medium text-center text-blue-700">Q{q}</p>
                          <Input
                            type="number"
                            placeholder="إيرادات"
                            value={newHistoricalData[`q${q}_revenue`]}
                            onChange={(e) => setNewHistoricalData({...newHistoricalData, [`q${q}_revenue`]: parseFloat(e.target.value) || 0})}
                            className="text-xs"
                          />
                          <Input
                            type="number"
                            placeholder="مصروفات"
                            value={newHistoricalData[`q${q}_expense`]}
                            onChange={(e) => setNewHistoricalData({...newHistoricalData, [`q${q}_expense`]: parseFloat(e.target.value) || 0})}
                            className="text-xs"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="bg-emerald-50 rounded-lg p-4">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">صافي الربح المتوقع:</span>
                      <span className={`text-xl font-bold ${(newHistoricalData.total_revenue - newHistoricalData.total_expense) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(newHistoricalData.total_revenue - newHistoricalData.total_expense)} ر.س
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setHistoricalDialogOpen(false)}>
                      إلغاء
                    </Button>
                    <Button 
                      onClick={saveHistoricalData}
                      disabled={savingHistorical}
                      className="bg-purple-600 hover:bg-purple-700"
                      data-testid="save-historical-btn"
                    >
                      {savingHistorical ? 'جاري الحفظ...' : 'حفظ البيانات'}
                    </Button>
                  </div>
                </TabsContent>
                
                <TabsContent value="view" className="pt-4">
                  {historicalData.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <History className="h-12 w-12 mx-auto mb-3 opacity-50" />
                      <p>لا توجد بيانات سابقة محفوظة</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {historicalData.map((data) => (
                        <div key={data.year} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div>
                            <p className="font-bold text-lg">{data.year}</p>
                            <div className="text-sm text-muted-foreground mt-1">
                              <span className="text-green-600">إيرادات: {formatCurrency(data.total_revenue)}</span>
                              <span className="mx-2">|</span>
                              <span className="text-red-600">مصروفات: {formatCurrency(data.total_expense)}</span>
                              <span className="mx-2">|</span>
                              <span className={data.net_profit >= 0 ? 'text-green-700' : 'text-red-700'}>
                                صافي: {formatCurrency(data.net_profit)}
                              </span>
                            </div>
                            {data.notes && <p className="text-xs text-muted-foreground mt-1">{data.notes}</p>}
                          </div>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => deleteHistoricalData(data.year)}
                            className="text-red-500 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-20">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4 text-emerald" />
          <p className="text-muted-foreground">جاري تحميل التقرير...</p>
        </div>
      ) : reportData ? (
        <>
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Carried Forward */}
            <Card className="border-s-4 border-s-blue-500">
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">الرصيد المرحل</p>
                    <p className="text-2xl font-bold mt-1">{formatCurrency(summary.carried_forward?.net || 0)}</p>
                    <p className="text-xs text-muted-foreground mt-1">من الفترة السابقة</p>
                  </div>
                  <div className="p-3 bg-blue-100 rounded-full">
                    <ArrowRightLeft className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Current Period Revenue */}
            <Card className="border-s-4 border-s-green-500">
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">إيرادات الربع</p>
                    <p className="text-2xl font-bold mt-1 text-green-600">{formatCurrency(totals.total_revenue || 0)}</p>
                    <p className="text-xs text-muted-foreground mt-1">إجمالي الإيرادات</p>
                  </div>
                  <div className="p-3 bg-green-100 rounded-full">
                    <TrendingUp className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Current Period Expenses */}
            <Card className="border-s-4 border-s-red-500">
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">مصروفات الربع</p>
                    <p className="text-2xl font-bold mt-1 text-red-600">{formatCurrency(totals.total_expense || 0)}</p>
                    <p className="text-xs text-muted-foreground mt-1">إجمالي المصروفات</p>
                  </div>
                  <div className="p-3 bg-red-100 rounded-full">
                    <TrendingDown className="h-6 w-6 text-red-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Bank Balance */}
            <Card className="border-s-4 border-s-emerald">
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">الرصيد البنكي المتاح</p>
                    <p className="text-2xl font-bold mt-1 text-emerald">{formatCurrency(summary.bank_balance || 0)}</p>
                    <p className="text-xs text-muted-foreground mt-1">حتى تاريخ اليوم</p>
                  </div>
                  <div className="p-3 bg-emerald-100 rounded-full">
                    <Wallet className="h-6 w-6 text-emerald" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Net Profit Summary */}
          <Card className={`${totals.net_profit >= 0 ? 'bg-gradient-to-r from-green-50 to-emerald-50 border-green-200' : 'bg-gradient-to-r from-red-50 to-orange-50 border-red-200'}`}>
            <CardContent className="py-6">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="text-center md:text-start">
                  <p className="text-lg font-medium">صافي الربح للربع {quarter} - {year}</p>
                  <p className={`text-4xl font-bold mt-2 ${totals.net_profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {formatCurrency(totals.net_profit || 0)} ر.س
                  </p>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">هامش الربح</p>
                    <p className={`text-2xl font-bold ${totals.profit_margin >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {totals.profit_margin || 0}%
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">الرصيد الختامي</p>
                    <p className="text-2xl font-bold text-blue-600">
                      {formatCurrency(summary.closing_balance?.net || 0)}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Bar Chart - Monthly Comparison */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-emerald" />
                  مقارنة الإيرادات والمصروفات الشهرية
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis dataKey="month" tick={{ fill: '#6b7280' }} />
                      <YAxis tick={{ fill: '#6b7280' }} />
                      <Tooltip 
                        formatter={(value) => `${formatCurrency(value)} ر.س`}
                        contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e5e7eb' }}
                      />
                      <Legend />
                      <Bar dataKey="revenue" name="الإيرادات" fill="#10b981" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="expense" name="المصروفات" fill="#ef4444" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Line Chart - Net Profit Trend */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-blue-500" />
                  صافي الربح الشهري
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis dataKey="month" tick={{ fill: '#6b7280' }} />
                      <YAxis tick={{ fill: '#6b7280' }} />
                      <Tooltip 
                        formatter={(value) => `${formatCurrency(value)} ر.س`}
                        contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e5e7eb' }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="net" 
                        name="صافي الربح" 
                        stroke="#3b82f6" 
                        strokeWidth={3}
                        dot={{ fill: '#3b82f6', strokeWidth: 2, r: 6 }}
                        activeDot={{ r: 8, fill: '#2563eb' }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quarters Comparison Section */}
          {comparisonData && comparisonData.comparison && comparisonData.comparison.length > 0 && (
            <Card className="border-2 border-indigo-200">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <GitCompare className="h-5 w-5 text-indigo-500" />
                  مقارنة الأرباع
                  {comparisonData.comparison.some(c => !c.has_data && !c.is_current) && (
                    <span className="text-xs bg-orange-100 text-orange-600 px-2 py-1 rounded-full ms-2">
                      بعض الأرباع بدون بيانات - يمكنك إضافتها من "بيانات سابقة"
                    </span>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={comparisonData.comparison} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis dataKey="label" tick={{ fill: '#6b7280' }} />
                      <YAxis tick={{ fill: '#6b7280' }} />
                      <Tooltip 
                        formatter={(value, name) => {
                          const labels = { revenue: 'الإيرادات', expense: 'المصروفات', net_profit: 'صافي الربح' };
                          return [`${formatCurrency(value)} ر.س`, labels[name] || name];
                        }}
                        contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e5e7eb' }}
                      />
                      <Legend 
                        formatter={(value) => {
                          const labels = { revenue: 'الإيرادات', expense: 'المصروفات', net_profit: 'صافي الربح' };
                          return labels[value] || value;
                        }}
                      />
                      <Bar dataKey="revenue" name="revenue" fill="#10b981" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="expense" name="expense" fill="#ef4444" radius={[4, 4, 0, 0]} />
                      <Line 
                        type="monotone" 
                        dataKey="net_profit" 
                        name="net_profit"
                        stroke="#6366f1" 
                        strokeWidth={3}
                        dot={{ fill: '#6366f1', strokeWidth: 2, r: 6 }}
                      />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
                
                {/* Growth indicators */}
                {comparisonData.comparison.length >= 2 && comparisonData.comparison[comparisonData.comparison.length - 1].revenue_growth !== undefined && (
                  <div className="mt-4 flex flex-wrap gap-4 justify-center">
                    <div className={`px-4 py-2 rounded-lg flex items-center gap-2 ${
                      comparisonData.comparison[comparisonData.comparison.length - 1].revenue_growth >= 0 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-red-100 text-red-700'
                    }`}>
                      {comparisonData.comparison[comparisonData.comparison.length - 1].revenue_growth >= 0 
                        ? <TrendingUp className="h-4 w-4" /> 
                        : <TrendingDown className="h-4 w-4" />}
                      <span>نمو الإيرادات: {comparisonData.comparison[comparisonData.comparison.length - 1].revenue_growth}%</span>
                    </div>
                    <div className={`px-4 py-2 rounded-lg flex items-center gap-2 ${
                      comparisonData.comparison[comparisonData.comparison.length - 1].expense_growth <= 0 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-orange-100 text-orange-700'
                    }`}>
                      {comparisonData.comparison[comparisonData.comparison.length - 1].expense_growth <= 0 
                        ? <TrendingDown className="h-4 w-4" /> 
                        : <TrendingUp className="h-4 w-4" />}
                      <span>تغير المصروفات: {comparisonData.comparison[comparisonData.comparison.length - 1].expense_growth}%</span>
                    </div>
                  </div>
                )}
                
                {/* Comparison Table */}
                <div className="mt-6 overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-indigo-50">
                      <tr>
                        <th className="px-4 py-2 text-start">الربع</th>
                        <th className="px-4 py-2 text-start">الإيرادات</th>
                        <th className="px-4 py-2 text-start">المصروفات</th>
                        <th className="px-4 py-2 text-start">صافي الربح</th>
                        <th className="px-4 py-2 text-start">الحالة</th>
                      </tr>
                    </thead>
                    <tbody>
                      {comparisonData.comparison.map((q, idx) => (
                        <tr key={idx} className={`border-b ${q.is_current ? 'bg-indigo-100 font-medium' : ''}`}>
                          <td className="px-4 py-2">
                            {q.label}
                            {q.is_current && <span className="ms-2 text-xs bg-indigo-500 text-white px-2 py-0.5 rounded">الحالي</span>}
                          </td>
                          <td className="px-4 py-2 text-green-600">{formatCurrency(q.revenue)} ر.س</td>
                          <td className="px-4 py-2 text-red-600">{formatCurrency(q.expense)} ر.س</td>
                          <td className={`px-4 py-2 font-medium ${q.net_profit >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                            {formatCurrency(q.net_profit)} ر.س
                          </td>
                          <td className="px-4 py-2">
                            {q.has_data ? (
                              <span className="text-green-600 text-xs">بيانات متوفرة</span>
                            ) : (
                              <span className="text-orange-500 text-xs">بدون بيانات</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Top Accounts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Top Revenue Accounts */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                  أعلى مصادر الإيرادات
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {reportData.top_revenue_accounts?.slice(0, 5).map((acc, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-xs font-bold">
                          {idx + 1}
                        </span>
                        <span className="font-medium">{acc.account_name}</span>
                      </div>
                      <span className="font-bold text-green-600">{formatCurrency(acc.amount)} ر.س</span>
                    </div>
                  ))}
                  {(!reportData.top_revenue_accounts || reportData.top_revenue_accounts.length === 0) && (
                    <p className="text-center text-muted-foreground py-4">لا توجد إيرادات في هذا الربع</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Top Expense Accounts */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingDown className="h-5 w-5 text-red-500" />
                  أعلى بنود المصروفات
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {reportData.top_expense_accounts?.slice(0, 5).map((acc, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center text-xs font-bold">
                          {idx + 1}
                        </span>
                        <span className="font-medium">{acc.account_name}</span>
                      </div>
                      <span className="font-bold text-red-600">{formatCurrency(acc.amount)} ر.س</span>
                    </div>
                  ))}
                  {(!reportData.top_expense_accounts || reportData.top_expense_accounts.length === 0) && (
                    <p className="text-center text-muted-foreground py-4">لا توجد مصروفات في هذا الربع</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Expense Distribution Pie Chart */}
          {pieData.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-purple-500" />
                  توزيع المصروفات
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `${formatCurrency(value)} ر.س`} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}

          {/* AI Analysis Section */}
          <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-indigo-50">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-purple-500" />
                  تحليل الذكاء الاصطناعي
                </CardTitle>
                <Button 
                  onClick={loadAiAnalysis} 
                  disabled={loadingAi}
                  className="bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600"
                  data-testid="ai-analysis-btn"
                >
                  {loadingAi ? (
                    <>
                      <RefreshCw className="h-4 w-4 me-2 animate-spin" />
                      جاري التحليل...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 me-2" />
                      تحليل بالذكاء الاصطناعي
                    </>
                  )}
                </Button>
              </div>
            </CardHeader>
            {showAiSection && (
              <CardContent>
                {loadingAi ? (
                  <div className="text-center py-12">
                    <div className="relative">
                      <Sparkles className="h-12 w-12 mx-auto text-purple-500 animate-pulse" />
                      <div className="absolute inset-0 animate-ping">
                        <Sparkles className="h-12 w-12 mx-auto text-purple-300 opacity-50" />
                      </div>
                    </div>
                    <p className="mt-4 text-purple-600 font-medium">الذكاء الاصطناعي يحلل بياناتك المالية...</p>
                    <p className="text-sm text-muted-foreground mt-1">يتم إعداد توصيات مخصصة لوضعك المالي</p>
                  </div>
                ) : aiAnalysis ? (
                  <div className="prose prose-sm max-w-none">
                    <div className="bg-white rounded-lg p-6 shadow-sm border border-purple-100">
                      <div 
                        className="whitespace-pre-wrap text-gray-700 leading-relaxed"
                        dangerouslySetInnerHTML={{ 
                          __html: aiAnalysis.analysis
                            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                            .replace(/##\s?(.*?)$/gm, '<h3 class="text-lg font-bold mt-4 mb-2 text-purple-700">$1</h3>')
                            .replace(/\n/g, '<br/>')
                        }}
                      />
                      <div className="mt-4 pt-4 border-t border-purple-100 text-xs text-muted-foreground">
                        تم إنشاء التحليل في: {new Date(aiAnalysis.generated_at).toLocaleString('ar-SA')}
                        {aiAnalysis.is_fallback && <span className="ms-2 text-orange-500">(تحليل أساسي)</span>}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Sparkles className="h-8 w-8 mx-auto mb-3 opacity-50" />
                    <p>اضغط على "تحليل بالذكاء الاصطناعي" للحصول على رؤى وتوصيات مخصصة</p>
                  </div>
                )}
              </CardContent>
            )}
          </Card>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-2 justify-center print:hidden">
            <Button variant="outline" onClick={printReport}>
              <Printer className="h-4 w-4 me-2" />
              طباعة التقرير
            </Button>
            <Button 
              variant="outline" 
              onClick={shareViaWhatsApp}
              className="text-green-600 border-green-300 hover:bg-green-50"
              data-testid="share-whatsapp-btn"
            >
              <Share2 className="h-4 w-4 me-2" />
              مشاركة عبر WhatsApp
            </Button>
            <Button 
              variant="outline"
              onClick={exportPdf}
              disabled={exportingPdf}
              className="text-red-600 border-red-300 hover:bg-red-50"
              data-testid="export-pdf-btn"
            >
              {exportingPdf ? (
                <RefreshCw className="h-4 w-4 me-2 animate-spin" />
              ) : (
                <Download className="h-4 w-4 me-2" />
              )}
              {exportingPdf ? 'جاري التصدير...' : 'تصدير PDF'}
            </Button>
            <Button 
              variant="outline"
              onClick={exportPptx}
              disabled={exportingPptx}
              className="text-orange-600 border-orange-300 hover:bg-orange-50"
              data-testid="export-pptx-btn"
            >
              {exportingPptx ? (
                <RefreshCw className="h-4 w-4 me-2 animate-spin" />
              ) : (
                <Download className="h-4 w-4 me-2" />
              )}
              {exportingPptx ? 'جاري التصدير...' : 'تصدير PowerPoint'}
            </Button>
          </div>
        </>
      ) : (
        <div className="text-center py-20 text-muted-foreground">
          <CalendarRange className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p>اختر السنة والربع لعرض التقرير</p>
        </div>
      )}
    </div>
  );
}
