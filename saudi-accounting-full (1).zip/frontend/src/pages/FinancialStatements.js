import React, { useState, useEffect, useCallback } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import api from '../utils/api';

// Format currency
const formatCurrency = (amount) => {
  return new Intl.NumberFormat('ar-SA', {
    style: 'currency',
    currency: 'SAR',
    minimumFractionDigits: 2
  }).format(amount || 0);
};

// Income Statement Component
const IncomeStatement = ({ data, loading }) => {
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="print-container bg-white" id="income-statement">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-emerald-700">قائمة الدخل</h2>
        <h3 className="text-lg text-gray-600">Income Statement</h3>
        <p className="text-sm text-gray-500">للسنة المالية {data.fiscal_year}</p>
      </div>

      {/* Revenue Section */}
      <div className="mb-6">
        <h3 className="text-lg font-bold bg-emerald-100 p-2 rounded">الإيرادات - Revenue</h3>
        <table className="w-full mt-2">
          <tbody>
            {data.revenue?.items?.map((item, idx) => (
              <tr key={idx} className="border-b">
                <td className="py-2 pr-4">{item.account_name_ar}</td>
                <td className="py-2 text-left w-32">{formatCurrency(item.amount)}</td>
              </tr>
            ))}
            <tr className="font-bold bg-emerald-50">
              <td className="py-2 pr-4">إجمالي الإيرادات</td>
              <td className="py-2 text-left">{formatCurrency(data.revenue?.total)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Cost of Sales */}
      {data.cost_of_sales?.items?.length > 0 && (
        <div className="mb-6">
          <h3 className="text-lg font-bold bg-red-100 p-2 rounded">تكلفة المبيعات - Cost of Sales</h3>
          <table className="w-full mt-2">
            <tbody>
              {data.cost_of_sales.items.map((item, idx) => (
                <tr key={idx} className="border-b">
                  <td className="py-2 pr-4">{item.account_name_ar}</td>
                  <td className="py-2 text-left w-32">({formatCurrency(item.amount)})</td>
                </tr>
              ))}
              <tr className="font-bold bg-red-50">
                <td className="py-2 pr-4">إجمالي تكلفة المبيعات</td>
                <td className="py-2 text-left">({formatCurrency(data.cost_of_sales.total)})</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}

      {/* Gross Profit */}
      <div className="mb-6 p-3 bg-blue-100 rounded-lg">
        <div className="flex justify-between items-center font-bold text-lg">
          <span>مجمل الربح - Gross Profit</span>
          <span className={data.gross_profit >= 0 ? 'text-emerald-700' : 'text-red-600'}>
            {formatCurrency(data.gross_profit)}
          </span>
        </div>
      </div>

      {/* Operating Expenses */}
      {data.operating_expenses?.items?.length > 0 && (
        <div className="mb-6">
          <h3 className="text-lg font-bold bg-orange-100 p-2 rounded">المصروفات التشغيلية - Operating Expenses</h3>
          <table className="w-full mt-2">
            <tbody>
              {data.operating_expenses.items.map((item, idx) => (
                <tr key={idx} className="border-b">
                  <td className="py-2 pr-4">{item.account_name_ar}</td>
                  <td className="py-2 text-left w-32">({formatCurrency(item.amount)})</td>
                </tr>
              ))}
              <tr className="font-bold bg-orange-50">
                <td className="py-2 pr-4">إجمالي المصروفات التشغيلية</td>
                <td className="py-2 text-left">({formatCurrency(data.operating_expenses.total)})</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}

      {/* Admin Expenses */}
      {data.admin_expenses?.items?.length > 0 && (
        <div className="mb-6">
          <h3 className="text-lg font-bold bg-purple-100 p-2 rounded">المصروفات الإدارية - Admin Expenses</h3>
          <table className="w-full mt-2">
            <tbody>
              {data.admin_expenses.items.map((item, idx) => (
                <tr key={idx} className="border-b">
                  <td className="py-2 pr-4">{item.account_name_ar}</td>
                  <td className="py-2 text-left w-32">({formatCurrency(item.amount)})</td>
                </tr>
              ))}
              <tr className="font-bold bg-purple-50">
                <td className="py-2 pr-4">إجمالي المصروفات الإدارية</td>
                <td className="py-2 text-left">({formatCurrency(data.admin_expenses.total)})</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}

      {/* Net Income */}
      <div className="p-4 bg-gradient-to-r from-emerald-600 to-emerald-700 rounded-lg text-white">
        <div className="flex justify-between items-center font-bold text-xl">
          <span>صافي الدخل - Net Income</span>
          <span className={data.net_income >= 0 ? '' : 'text-red-200'}>
            {formatCurrency(data.net_income)}
          </span>
        </div>
      </div>
    </div>
  );
};

// Balance Sheet Component
const BalanceSheet = ({ data, loading }) => {
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="print-container bg-white" id="balance-sheet">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-emerald-700">قائمة المركز المالي</h2>
        <h3 className="text-lg text-gray-600">Statement of Financial Position</h3>
        <p className="text-sm text-gray-500">كما في {data.report_date?.split('T')[0]}</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Assets Side */}
        <div>
          <h3 className="text-xl font-bold text-center bg-blue-600 text-white p-2 rounded-t">الأصول - Assets</h3>
          
          {/* Current Assets */}
          <div className="border border-blue-200 p-3">
            <h4 className="font-bold text-blue-700 mb-2">الأصول المتداولة - Current Assets</h4>
            <table className="w-full text-sm">
              <tbody>
                {data.assets?.current_assets?.items?.map((item, idx) => (
                  <tr key={idx} className="border-b border-gray-100">
                    <td className="py-1">{item.account_name_ar}</td>
                    <td className="py-1 text-left">{formatCurrency(item.amount)}</td>
                  </tr>
                ))}
                <tr className="font-bold bg-blue-50">
                  <td className="py-2">إجمالي الأصول المتداولة</td>
                  <td className="py-2 text-left">{formatCurrency(data.assets?.current_assets?.total)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Non-Current Assets */}
          <div className="border border-blue-200 border-t-0 p-3">
            <h4 className="font-bold text-blue-700 mb-2">الأصول غير المتداولة - Non-Current Assets</h4>
            <table className="w-full text-sm">
              <tbody>
                {data.assets?.non_current_assets?.items?.map((item, idx) => (
                  <tr key={idx} className="border-b border-gray-100">
                    <td className="py-1">{item.account_name_ar}</td>
                    <td className="py-1 text-left">{formatCurrency(item.amount)}</td>
                  </tr>
                ))}
                {data.assets?.non_current_assets?.items?.length === 0 && (
                  <tr><td className="py-1 text-gray-400" colSpan={2}>لا يوجد</td></tr>
                )}
                <tr className="font-bold bg-blue-50">
                  <td className="py-2">إجمالي الأصول غير المتداولة</td>
                  <td className="py-2 text-left">{formatCurrency(data.assets?.non_current_assets?.total)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Total Assets */}
          <div className="bg-blue-600 text-white p-3 rounded-b font-bold flex justify-between">
            <span>إجمالي الأصول</span>
            <span>{formatCurrency(data.assets?.total)}</span>
          </div>
        </div>

        {/* Liabilities & Equity Side */}
        <div>
          <h3 className="text-xl font-bold text-center bg-emerald-600 text-white p-2 rounded-t">الخصوم وحقوق الملكية</h3>
          
          {/* Current Liabilities */}
          <div className="border border-emerald-200 p-3">
            <h4 className="font-bold text-red-700 mb-2">الخصوم المتداولة - Current Liabilities</h4>
            <table className="w-full text-sm">
              <tbody>
                {data.liabilities?.current_liabilities?.items?.map((item, idx) => (
                  <tr key={idx} className="border-b border-gray-100">
                    <td className="py-1">{item.account_name_ar}</td>
                    <td className="py-1 text-left">{formatCurrency(item.amount)}</td>
                  </tr>
                ))}
                {data.liabilities?.current_liabilities?.items?.length === 0 && (
                  <tr><td className="py-1 text-gray-400" colSpan={2}>لا يوجد</td></tr>
                )}
                <tr className="font-bold bg-red-50">
                  <td className="py-2">إجمالي الخصوم المتداولة</td>
                  <td className="py-2 text-left">{formatCurrency(data.liabilities?.current_liabilities?.total)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Non-Current Liabilities */}
          <div className="border border-emerald-200 border-t-0 p-3">
            <h4 className="font-bold text-red-700 mb-2">الخصوم غير المتداولة - Non-Current Liabilities</h4>
            <table className="w-full text-sm">
              <tbody>
                {data.liabilities?.non_current_liabilities?.items?.map((item, idx) => (
                  <tr key={idx} className="border-b border-gray-100">
                    <td className="py-1">{item.account_name_ar}</td>
                    <td className="py-1 text-left">{formatCurrency(item.amount)}</td>
                  </tr>
                ))}
                {data.liabilities?.non_current_liabilities?.items?.length === 0 && (
                  <tr><td className="py-1 text-gray-400" colSpan={2}>لا يوجد</td></tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Equity */}
          <div className="border border-emerald-200 border-t-0 p-3">
            <h4 className="font-bold text-emerald-700 mb-2">حقوق الملكية - Equity</h4>
            <table className="w-full text-sm">
              <tbody>
                {data.equity?.items?.map((item, idx) => (
                  <tr key={idx} className="border-b border-gray-100">
                    <td className="py-1">{item.account_name_ar}</td>
                    <td className="py-1 text-left">{formatCurrency(item.amount)}</td>
                  </tr>
                ))}
                <tr className="font-bold bg-emerald-50">
                  <td className="py-2">إجمالي حقوق الملكية</td>
                  <td className="py-2 text-left">{formatCurrency(data.equity?.total)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Total Liabilities & Equity */}
          <div className="bg-emerald-600 text-white p-3 rounded-b font-bold flex justify-between">
            <span>إجمالي الخصوم وحقوق الملكية</span>
            <span>{formatCurrency(data.total_liabilities_equity)}</span>
          </div>
        </div>
      </div>

      {/* Balance Check */}
      <div className={`mt-4 p-3 rounded-lg text-center font-bold ${data.is_balanced ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
        {data.is_balanced ? (
          <span>✓ القائمة متوازنة - الأصول = الخصوم + حقوق الملكية</span>
        ) : (
          <span>⚠ يوجد فرق: {formatCurrency(Math.abs((data.assets?.total || 0) - (data.total_liabilities_equity || 0)))}</span>
        )}
      </div>
    </div>
  );
};

// Cash Flow Statement Component
const CashFlowStatement = ({ data, loading }) => {
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  if (!data) return null;

  const ActivitySection = ({ title, titleEn, activity, color }) => (
    <div className="mb-6">
      <h3 className={`text-lg font-bold ${color} p-2 rounded`}>{title} - {titleEn}</h3>
      <table className="w-full mt-2 text-sm">
        <tbody>
          {/* Receipts */}
          {activity.receipts?.length > 0 && (
            <>
              <tr className="bg-gray-50">
                <td className="py-2 pr-4 font-semibold" colSpan={2}>التحصيلات:</td>
              </tr>
              {activity.receipts.map((item, idx) => (
                <tr key={idx} className="border-b">
                  <td className="py-1 pr-6">{item.description}</td>
                  <td className="py-1 text-left text-green-600">{formatCurrency(item.amount)}</td>
                </tr>
              ))}
            </>
          )}
          
          {/* Payments */}
          {activity.payments?.length > 0 && (
            <>
              <tr className="bg-gray-50">
                <td className="py-2 pr-4 font-semibold" colSpan={2}>المدفوعات:</td>
              </tr>
              {activity.payments.map((item, idx) => (
                <tr key={idx} className="border-b">
                  <td className="py-1 pr-6">{item.description}</td>
                  <td className="py-1 text-left text-red-600">({formatCurrency(item.amount)})</td>
                </tr>
              ))}
            </>
          )}
          
          <tr className="font-bold bg-gray-100">
            <td className="py-2 pr-4">صافي التدفق النقدي</td>
            <td className={`py-2 text-left ${activity.net >= 0 ? 'text-green-700' : 'text-red-700'}`}>
              {formatCurrency(activity.net)}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="print-container bg-white" id="cash-flow">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-emerald-700">قائمة التدفقات النقدية</h2>
        <h3 className="text-lg text-gray-600">Cash Flow Statement</h3>
        <p className="text-sm text-gray-500">للسنة المالية {data.fiscal_year}</p>
      </div>

      {/* Opening Cash */}
      <div className="mb-4 p-3 bg-gray-100 rounded-lg flex justify-between items-center">
        <span className="font-bold">النقدية في بداية الفترة</span>
        <span className="font-bold text-lg">{formatCurrency(data.opening_cash)}</span>
      </div>

      {/* Operating Activities */}
      <ActivitySection 
        title="الأنشطة التشغيلية" 
        titleEn="Operating Activities"
        activity={data.operating_activities}
        color="bg-blue-100"
      />

      {/* Investing Activities */}
      <ActivitySection 
        title="الأنشطة الاستثمارية" 
        titleEn="Investing Activities"
        activity={data.investing_activities}
        color="bg-purple-100"
      />

      {/* Financing Activities */}
      <ActivitySection 
        title="الأنشطة التمويلية" 
        titleEn="Financing Activities"
        activity={data.financing_activities}
        color="bg-orange-100"
      />

      {/* Net Change */}
      <div className="mb-4 p-3 bg-yellow-100 rounded-lg flex justify-between items-center">
        <span className="font-bold">صافي التغير في النقدية</span>
        <span className={`font-bold text-lg ${data.net_change >= 0 ? 'text-green-700' : 'text-red-700'}`}>
          {formatCurrency(data.net_change)}
        </span>
      </div>

      {/* Ending Cash */}
      <div className="p-4 bg-gradient-to-r from-emerald-600 to-emerald-700 rounded-lg text-white">
        <div className="flex justify-between items-center font-bold text-xl">
          <span>النقدية في نهاية الفترة</span>
          <span>{formatCurrency(data.ending_cash)}</span>
        </div>
      </div>
    </div>
  );
};

// Main Component
export default function FinancialStatements() {
  const [activeTab, setActiveTab] = useState('income');
  const [fiscalYear, setFiscalYear] = useState('2025');
  const [loading, setLoading] = useState(false);
  const [incomeData, setIncomeData] = useState(null);
  const [balanceData, setBalanceData] = useState(null);
  const [cashFlowData, setCashFlowData] = useState(null);

  const loadIncomeStatement = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get(`/reports/income-statement?fiscal_year=${fiscalYear}`);
      setIncomeData(res.data);
    } catch (err) {
      console.error('Error loading income statement:', err);
    }
    setLoading(false);
  }, [fiscalYear]);

  const loadBalanceSheet = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get(`/reports/balance-sheet?fiscal_year=${fiscalYear}`);
      setBalanceData(res.data);
    } catch (err) {
      console.error('Error loading balance sheet:', err);
    }
    setLoading(false);
  }, [fiscalYear]);

  const loadCashFlow = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get(`/reports/cash-flow?fiscal_year=${fiscalYear}`);
      setCashFlowData(res.data);
    } catch (err) {
      console.error('Error loading cash flow:', err);
    }
    setLoading(false);
  }, [fiscalYear]);

  useEffect(() => {
    if (activeTab === 'income') {
      loadIncomeStatement();
    } else if (activeTab === 'balance') {
      loadBalanceSheet();
    } else if (activeTab === 'cashflow') {
      loadCashFlow();
    }
  }, [activeTab, fiscalYear, loadIncomeStatement, loadBalanceSheet, loadCashFlow]);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-6" dir="rtl">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">القوائم المالية</h1>
        <div className="flex gap-3">
          <Select value={fiscalYear} onValueChange={setFiscalYear}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2025">2025</SelectItem>
              <SelectItem value="2026">2026</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={handlePrint} variant="outline" className="no-print">
            <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
            </svg>
            طباعة
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6 no-print">
          <TabsTrigger value="income" data-testid="income-tab">
            قائمة الدخل
          </TabsTrigger>
          <TabsTrigger value="balance" data-testid="balance-tab">
            المركز المالي
          </TabsTrigger>
          <TabsTrigger value="cashflow" data-testid="cashflow-tab">
            التدفقات النقدية
          </TabsTrigger>
        </TabsList>

        <Card>
          <CardContent className="p-6">
            <TabsContent value="income" className="mt-0">
              <IncomeStatement data={incomeData} loading={loading} />
            </TabsContent>

            <TabsContent value="balance" className="mt-0">
              <BalanceSheet data={balanceData} loading={loading} />
            </TabsContent>

            <TabsContent value="cashflow" className="mt-0">
              <CashFlowStatement data={cashFlowData} loading={loading} />
            </TabsContent>
          </CardContent>
        </Card>
      </Tabs>
    </div>
  );
}
