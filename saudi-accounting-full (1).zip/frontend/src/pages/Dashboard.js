import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../utils/api';
import { Card } from '../components/ui/card';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  FileText, 
  Users, 
  BookOpen,
  ArrowUpRight,
  ArrowDownRight,
  Receipt,
  CreditCard,
  BookMarked,
  PieChart
} from 'lucide-react';
import { formatCurrency } from '../utils/exportHelpers';

export default function Dashboard() {
  const { t } = useTranslation();
  const [stats, setStats] = useState({
    accounts: 0,
    customers: 0,
    invoices: 0,
    journalEntries: 0,
    receiptVouchers: 0,
    paymentVouchers: 0,
    totalRevenue: 0,
    totalExpenses: 0,
    totalReceivables: 0,
    totalPayables: 0
  });
  const [recentActivities, setRecentActivities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [
        accountsRes, 
        customersRes, 
        invoicesRes, 
        entriesRes,
        receiptRes,
        paymentRes
      ] = await Promise.all([
        api.get('/accounts'),
        api.get('/customers'),
        api.get('/invoices'),
        api.get('/journal-entries'),
        api.get('/receipt-vouchers'),
        api.get('/payment-vouchers')
      ]);

      // Calculate totals
      const totalInvoices = invoicesRes.data.reduce((sum, inv) => sum + (inv.total_amount || 0), 0);
      const totalReceipts = receiptRes.data.reduce((sum, v) => sum + (v.amount || 0), 0);
      const totalPayments = paymentRes.data.reduce((sum, v) => sum + (v.amount || 0), 0);

      setStats({
        accounts: accountsRes.data.length,
        customers: customersRes.data.length,
        invoices: invoicesRes.data.length,
        journalEntries: entriesRes.data.length,
        receiptVouchers: receiptRes.data.length,
        paymentVouchers: paymentRes.data.length,
        totalRevenue: totalInvoices,
        totalExpenses: totalPayments,
        totalReceivables: totalInvoices - totalReceipts,
        totalPayables: 0
      });

      // Recent activities
      const activities = [
        ...invoicesRes.data.slice(-3).map(i => ({ type: 'invoice', data: i, date: i.invoice_date })),
        ...entriesRes.data.slice(-3).map(e => ({ type: 'journal', data: e, date: e.entry_date })),
        ...receiptRes.data.slice(-2).map(v => ({ type: 'receipt', data: v, date: v.voucher_date })),
        ...paymentRes.data.slice(-2).map(v => ({ type: 'payment', data: v, date: v.voucher_date }))
      ].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 8);
      
      setRecentActivities(activities);
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const StatCard = ({ title, value, icon: Icon, trend, trendValue, color = "emerald", subtitle }) => (
    <Card className="p-5 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-muted-foreground mb-1">{title}</p>
          <p className="text-2xl font-bold">{value}</p>
          {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
        </div>
        <div className={`p-3 rounded-lg bg-${color}/10`}>
          <Icon className={`h-6 w-6 text-${color}`} />
        </div>
      </div>
      {trend && (
        <div className="flex items-center mt-3 pt-3 border-t">
          {trend === 'up' ? (
            <ArrowUpRight className="h-4 w-4 text-green-500 me-1" />
          ) : (
            <ArrowDownRight className="h-4 w-4 text-red-500 me-1" />
          )}
          <span className={`text-sm ${trend === 'up' ? 'text-green-500' : 'text-red-500'}`}>
            {trendValue}
          </span>
        </div>
      )}
    </Card>
  );

  const getActivityIcon = (type) => {
    switch (type) {
      case 'invoice': return FileText;
      case 'journal': return BookMarked;
      case 'receipt': return Receipt;
      case 'payment': return CreditCard;
      default: return FileText;
    }
  };

  const getActivityColor = (type) => {
    switch (type) {
      case 'invoice': return 'text-blue-500 bg-blue-100';
      case 'journal': return 'text-purple-500 bg-purple-100';
      case 'receipt': return 'text-green-500 bg-green-100';
      case 'payment': return 'text-red-500 bg-red-100';
      default: return 'text-gray-500 bg-gray-100';
    }
  };

  const getActivityLabel = (activity) => {
    switch (activity.type) {
      case 'invoice': return `فاتورة #${activity.data.invoice_number}`;
      case 'journal': return `قيد #${activity.data.entry_number}`;
      case 'receipt': return `سند قبض #${activity.data.voucher_number}`;
      case 'payment': return `سند صرف #${activity.data.voucher_number}`;
      default: return '';
    }
  };

  const getActivityAmount = (activity) => {
    switch (activity.type) {
      case 'invoice': return activity.data.total_amount;
      case 'journal': return activity.data.total_debit;
      case 'receipt': 
      case 'payment': return activity.data.amount;
      default: return 0;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-xl text-muted-foreground">جاري التحميل...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="dashboard">
      {/* Welcome Section */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold">مرحباً بك في النظام المحاسبي</h1>
        <p className="text-muted-foreground">نظرة عامة على الأداء المالي</p>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-5 bg-gradient-to-br from-emerald to-emerald-hover text-white">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm opacity-80 mb-1">إجمالي الإيرادات</p>
              <p className="text-2xl font-bold" dir="ltr">{formatCurrency(stats.totalRevenue)}</p>
            </div>
            <TrendingUp className="h-8 w-8 opacity-80" />
          </div>
        </Card>
        
        <Card className="p-5 bg-gradient-to-br from-red-500 to-red-600 text-white">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm opacity-80 mb-1">إجمالي المصروفات</p>
              <p className="text-2xl font-bold" dir="ltr">{formatCurrency(stats.totalExpenses)}</p>
            </div>
            <TrendingDown className="h-8 w-8 opacity-80" />
          </div>
        </Card>
        
        <Card className="p-5 bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm opacity-80 mb-1">المدينون (ذمم مدينة)</p>
              <p className="text-2xl font-bold" dir="ltr">{formatCurrency(stats.totalReceivables)}</p>
            </div>
            <DollarSign className="h-8 w-8 opacity-80" />
          </div>
        </Card>

        <Card className="p-5 bg-gradient-to-br from-orange-500 to-orange-600 text-white">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm opacity-80 mb-1">صافي الربح</p>
              <p className="text-2xl font-bold" dir="ltr">{formatCurrency(stats.totalRevenue - stats.totalExpenses)}</p>
            </div>
            <PieChart className="h-8 w-8 opacity-80" />
          </div>
        </Card>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatCard 
          title="الحسابات" 
          value={stats.accounts} 
          icon={BookOpen}
          subtitle="دليل الحسابات"
        />
        <StatCard 
          title="العملاء" 
          value={stats.customers} 
          icon={Users}
        />
        <StatCard 
          title="الفواتير" 
          value={stats.invoices} 
          icon={FileText}
        />
        <StatCard 
          title="القيود" 
          value={stats.journalEntries} 
          icon={BookMarked}
        />
        <StatCard 
          title="سندات القبض" 
          value={stats.receiptVouchers} 
          icon={Receipt}
        />
        <StatCard 
          title="سندات الصرف" 
          value={stats.paymentVouchers} 
          icon={CreditCard}
        />
      </div>

      {/* Recent Activities & Quick Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activities */}
        <Card className="p-5">
          <h3 className="font-semibold mb-4">آخر النشاطات</h3>
          <div className="space-y-3">
            {recentActivities.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">لا توجد نشاطات حتى الآن</p>
            ) : (
              recentActivities.map((activity, index) => {
                const Icon = getActivityIcon(activity.type);
                const colorClass = getActivityColor(activity.type);
                return (
                  <div key={index} className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                    <div className={`p-2 rounded-lg ${colorClass}`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{getActivityLabel(activity)}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(activity.date).toLocaleDateString('ar-SA')}
                      </p>
                    </div>
                    <span className="font-mono font-medium" dir="ltr">
                      {formatCurrency(getActivityAmount(activity))}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        </Card>

        {/* Quick Access */}
        <Card className="p-5">
          <h3 className="font-semibold mb-4">الوصول السريع</h3>
          <div className="grid grid-cols-2 gap-3">
            <a href="/easy-entries" className="flex items-center gap-3 p-4 rounded-lg border hover:border-emerald hover:bg-emerald/5 transition-colors">
              <BookMarked className="h-6 w-6 text-emerald" />
              <div>
                <p className="font-medium">قيد سريع</p>
                <p className="text-xs text-muted-foreground">إضافة قيد جديد</p>
              </div>
            </a>
            <a href="/invoices" className="flex items-center gap-3 p-4 rounded-lg border hover:border-blue-500 hover:bg-blue-50 transition-colors">
              <FileText className="h-6 w-6 text-blue-500" />
              <div>
                <p className="font-medium">فاتورة جديدة</p>
                <p className="text-xs text-muted-foreground">إنشاء فاتورة</p>
              </div>
            </a>
            <a href="/receipt-vouchers" className="flex items-center gap-3 p-4 rounded-lg border hover:border-green-500 hover:bg-green-50 transition-colors">
              <Receipt className="h-6 w-6 text-green-500" />
              <div>
                <p className="font-medium">سند قبض</p>
                <p className="text-xs text-muted-foreground">تسجيل قبض</p>
              </div>
            </a>
            <a href="/payment-vouchers" className="flex items-center gap-3 p-4 rounded-lg border hover:border-red-500 hover:bg-red-50 transition-colors">
              <CreditCard className="h-6 w-6 text-red-500" />
              <div>
                <p className="font-medium">سند صرف</p>
                <p className="text-xs text-muted-foreground">تسجيل صرف</p>
              </div>
            </a>
          </div>
        </Card>
      </div>
    </div>
  );
}
