import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../utils/api';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { toast } from 'sonner';
import { Plus, Eye, Printer, Search } from 'lucide-react';
import { formatDate, formatCurrency } from '../utils/exportHelpers';
import { PrintPaymentVoucher } from '../components/PrintTemplates';
import { AccountCombobox } from '../components/AccountCombobox';

export default function PaymentVouchers() {
  const { t, i18n } = useTranslation();
  const [vouchers, setVouchers] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [selectedVoucher, setSelectedVoucher] = useState(null);
  const [printVoucher, setPrintVoucher] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [newVoucher, setNewVoucher] = useState({
    voucher_number: '',
    voucher_date: formatDate(new Date()),
    paid_to: '',
    amount: 0,
    payment_method: 'cash',
    account_code: '',
    description: ''
  });

  useEffect(() => {
    loadVouchers();
    loadAccounts();
  }, []);

  const loadVouchers = async () => {
    try {
      const response = await api.get('/payment-vouchers');
      setVouchers(response.data);
    } catch (error) {
      toast.error(t('error'));
    } finally {
      setLoading(false);
    }
  };

  const loadAccounts = async () => {
    try {
      const response = await api.get('/accounts');
      setAccounts(response.data);
    } catch (error) {
      console.error('Error loading accounts');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!newVoucher.account_code) {
      toast.error('يجب اختيار الحساب');
      return;
    }
    
    try {
      await api.post('/payment-vouchers', {
        ...newVoucher,
        voucher_date: new Date(newVoucher.voucher_date).toISOString()
      });
      toast.success(t('successfullySaved'));
      setDialogOpen(false);
      loadVouchers();
      resetForm();
    } catch (error) {
      toast.error(error.response?.data?.detail || t('error'));
    }
  };

  const resetForm = () => {
    setNewVoucher({
      voucher_number: '',
      voucher_date: formatDate(new Date()),
      paid_to: '',
      amount: 0,
      payment_method: 'cash',
      account_code: '',
      description: ''
    });
  };

  const viewVoucher = (voucher) => {
    setSelectedVoucher(voucher);
    setViewDialogOpen(true);
  };

  const getAccountName = (accountCode) => {
    const account = accounts.find(a => a.account_code === accountCode);
    if (!account) return accountCode;
    return i18n.language === 'ar' ? account.account_name_ar : account.account_name_en;
  };

  // Filter vouchers based on search term
  const filteredVouchers = vouchers.filter(voucher => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      voucher.voucher_number?.toLowerCase().includes(term) ||
      voucher.paid_to?.toLowerCase().includes(term) ||
      voucher.description?.toLowerCase().includes(term) ||
      formatDate(voucher.voucher_date).includes(term)
    );
  });

  if (printVoucher) {
    return <PrintPaymentVoucher voucher={printVoucher} onClose={() => setPrintVoucher(null)} />;
  }
  if (loading) {
    return <div className="text-center py-12">{t('loading')}</div>;
  }

  return (
    <div className="space-y-6" data-testid="payment-vouchers-container">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">{t('paymentVouchers')}</h1>
        
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald hover:bg-emerald-hover" onClick={resetForm} data-testid="add-payment-voucher-button">
              <Plus className="h-4 w-4 me-2" />
              {t('addPaymentVoucher')}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{t('addPaymentVoucher')}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>{t('voucherNumber')}</Label>
                  <Input
                    value={newVoucher.voucher_number}
                    onChange={(e) => setNewVoucher({...newVoucher, voucher_number: e.target.value})}
                    required
                    data-testid="voucher-number-input"
                  />
                </div>
                <div>
                  <Label>{t('voucherDate')}</Label>
                  <Input
                    type="date"
                    value={newVoucher.voucher_date}
                    onChange={(e) => setNewVoucher({...newVoucher, voucher_date: e.target.value})}
                    required
                    data-testid="voucher-date-input"
                  />
                </div>
              </div>
              
              <div>
                <Label>{t('paidTo')}</Label>
                <Input
                  value={newVoucher.paid_to}
                  onChange={(e) => setNewVoucher({...newVoucher, paid_to: e.target.value})}
                  required
                  data-testid="paid-to-input"
                />
              </div>

              <div>
                <Label>{t('amount')} (SAR)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={newVoucher.amount || ''}
                  onChange={(e) => setNewVoucher({...newVoucher, amount: parseFloat(e.target.value) || 0})}
                  required
                  className="text-end"
                  data-testid="amount-input"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>{t('paymentMethod')}</Label>
                  <Select
                    value={newVoucher.payment_method}
                    onValueChange={(value) => setNewVoucher({...newVoucher, payment_method: value})}
                  >
                    <SelectTrigger data-testid="payment-method-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash">{t('cash')}</SelectItem>
                      <SelectItem value="check">{t('check')}</SelectItem>
                      <SelectItem value="bank_transfer">{t('bankTransfer')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>{t('accountCode')}</Label>
                  <AccountCombobox
                    accounts={accounts.filter(a => a.account_type === 'asset')}
                    value={newVoucher.account_code}
                    onSelect={(value) => setNewVoucher({...newVoucher, account_code: value})}
                    placeholder="اختر حساب الخزينة/البنك"
                    language={i18n.language}
                  />
                </div>
              </div>

              <div>
                <Label>{t('description')}</Label>
                <Input
                  value={newVoucher.description}
                  onChange={(e) => setNewVoucher({...newVoucher, description: e.target.value})}
                  required
                  data-testid="description-input"
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  {t('cancel')}
                </Button>
                <Button type="submit" className="bg-emerald hover:bg-emerald-hover" data-testid="save-voucher-button">
                  {t('save')}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search Bar */}
      <Card className="p-4">
        <div className="relative">
          <Search className="absolute start-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="بحث بالرقم أو المدفوع إليه أو الوصف..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="ps-10"
            data-testid="search-vouchers-input"
          />
        </div>
      </Card>

      <Card className="border border-border/60">
        <div className="overflow-x-auto">
          <table className="w-full" data-testid="vouchers-table">
            <thead className="bg-muted">
              <tr>
                <th className="px-4 py-3 text-start">{t('voucherNumber')}</th>
                <th className="px-4 py-3 text-start">{t('voucherDate')}</th>
                <th className="px-4 py-3 text-start">{t('paidTo')}</th>
                <th className="px-4 py-3 text-end">{t('amount')}</th>
                <th className="px-4 py-3 text-start">{t('paymentMethod')}</th>
                <th className="px-4 py-3 text-start">{t('actions')}</th>
              </tr>
            </thead>
            <tbody>
              {filteredVouchers.map((voucher) => (
                <tr key={voucher.voucher_number} className="border-b border-border hover:bg-muted/30" data-testid={`voucher-row-${voucher.voucher_number}`}>
                  <td className="px-4 py-3">{voucher.voucher_number}</td>
                  <td className="px-4 py-3">{formatDate(voucher.voucher_date)}</td>
                  <td className="px-4 py-3">{voucher.paid_to}</td>
                  <td className="px-4 py-3 text-end">{formatCurrency(voucher.amount)}</td>
                  <td className="px-4 py-3">{t(voucher.payment_method)}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <Button size="icon" variant="ghost" onClick={() => viewVoucher(voucher)} data-testid={`view-voucher-${voucher.voucher_number}`}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => setPrintVoucher(voucher)} data-testid={`print-voucher-${voucher.voucher_number}`}>
                        <Printer className="h-4 w-4 text-emerald" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredVouchers.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              {searchTerm ? 'لا توجد نتائج للبحث' : t('noData')}
            </div>
          )}
        </div>
      </Card>

      {/* View Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>سند صرف - {selectedVoucher?.voucher_number}</DialogTitle>
          </DialogHeader>
          {selectedVoucher && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><span className="font-semibold">رقم السند:</span> {selectedVoucher.voucher_number}</div>
                <div><span className="font-semibold">التاريخ:</span> {formatDate(selectedVoucher.voucher_date)}</div>
                <div><span className="font-semibold">مدفوع إلى:</span> {selectedVoucher.paid_to}</div>
                <div><span className="font-semibold">المبلغ:</span> {formatCurrency(selectedVoucher.amount)}</div>
                <div><span className="font-semibold">طريقة الدفع:</span> {t(selectedVoucher.payment_method)}</div>
                <div><span className="font-semibold">الحساب:</span> {getAccountName(selectedVoucher.account_code)}</div>
              </div>
              <div className="pt-2 border-t">
                <span className="font-semibold">الوصف:</span>
                <p className="mt-1">{selectedVoucher.description}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
