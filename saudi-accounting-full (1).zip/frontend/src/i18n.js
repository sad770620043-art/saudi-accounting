import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const resources = {
  en: {
    translation: {
      // Auth
      "login": "Login",
      "username": "Username",
      "password": "Password",
      "welcomeBack": "Welcome Back",
      "enterCredentials": "Enter your credentials to access your account",
      
      // Navigation
      "dashboard": "Dashboard",
      "chartOfAccounts": "Chart of Accounts",
      "openingBalances": "Opening Balances",
      "customers": "Customers",
      "invoices": "Invoices",
      "journalEntries": "Journal Entries",
      "receiptVouchers": "Receipt Vouchers",
      "paymentVouchers": "Payment Vouchers",
      "reports": "Reports",
      "settings": "Settings",
      "logout": "Logout",
      
      // Dashboard
      "totalAccounts": "Total Accounts",
      "totalCustomers": "Total Customers",
      "totalInvoices": "Total Invoices",
      "totalRevenue": "Total Revenue",
      "recentTransactions": "Recent Transactions",
      
      // Chart of Accounts
      "accountCode": "Account Code",
      "accountNameAr": "Account Name (Arabic)",
      "accountNameEn": "Account Name (English)",
      "accountType": "Account Type",
      "parentCode": "Parent Code",
      "level": "Level",
      "status": "Status",
      "active": "Active",
      "inactive": "Inactive",
      "addAccount": "Add Account",
      "editAccount": "Edit Account",
      "deleteAccount": "Delete Account",
      
      // Account Types
      "asset": "Asset",
      "liability": "Liability",
      "equity": "Equity",
      "revenue": "Revenue",
      "expense": "Expense",
      
      // Opening Balances
      "fiscalYear": "Fiscal Year",
      "debit": "Debit",
      "credit": "Credit",
      "balance": "Balance",
      "addOpeningBalance": "Add Opening Balance",
      
      // Customers
      "customerCode": "Customer Code",
      "customerName": "Customer Name",
      "phone": "Phone",
      "email": "Email",
      "address": "Address",
      "addCustomer": "Add Customer",
      "editCustomer": "Edit Customer",
      
      // Invoices
      "invoiceNumber": "Invoice Number",
      "invoiceDate": "Invoice Date",
      "customer": "Customer",
      "items": "Items",
      "description": "Description",
      "quantity": "Quantity",
      "unitPrice": "Unit Price",
      "total": "Total",
      "subtotal": "Subtotal",
      "vat": "VAT",
      "totalAmount": "Total Amount",
      "notes": "Notes",
      "addInvoice": "Add Invoice",
      "addItem": "Add Item",
      
      // Journal Entries
      "entryNumber": "Entry Number",
      "entryDate": "Entry Date",
      "addJournalEntry": "Add Journal Entry",
      "addLine": "Add Line",
      "totalDebit": "Total Debit",
      "totalCredit": "Total Credit",
      
      // Vouchers
      "voucherNumber": "Voucher Number",
      "voucherDate": "Voucher Date",
      "receivedFrom": "Received From",
      "paidTo": "Paid To",
      "amount": "Amount",
      "paymentMethod": "Payment Method",
      "cash": "Cash",
      "check": "Check",
      "bankTransfer": "Bank Transfer",
      "addReceiptVoucher": "Add Receipt Voucher",
      "addPaymentVoucher": "Add Payment Voucher",
      
      // Reports
      "trialBalance": "Trial Balance",
      "accountStatement": "Account Statement",
      "generalLedger": "General Ledger",
      "generateReport": "Generate Report",
      "exportPDF": "Export PDF",
      "exportExcel": "Export Excel",
      "exportWord": "Export Word",
      "print": "Print",
      
      // Common
      "save": "Save",
      "cancel": "Cancel",
      "edit": "Edit",
      "delete": "Delete",
      "view": "View",
      "search": "Search",
      "actions": "Actions",
      "loading": "Loading...",
      "noData": "No data available",
      "confirm": "Confirm",
      "areYouSure": "Are you sure?",
      "successfullySaved": "Successfully saved",
      "successfullyDeleted": "Successfully deleted",
      "error": "Error",
      "success": "Success",
    }
  },
  ar: {
    translation: {
      // Auth
      "login": "تسجيل الدخول",
      "username": "اسم المستخدم",
      "password": "كلمة المرور",
      "welcomeBack": "مرحباً بعودتك",
      "enterCredentials": "أدخل بيانات الدخول للوصول إلى حسابك",
      
      // Navigation
      "dashboard": "لوحة التحكم",
      "chartOfAccounts": "دليل الحسابات",
      "openingBalances": "الأرصدة الافتتاحية",
      "customers": "العملاء",
      "invoices": "الفواتير",
      "journalEntries": "القيود اليومية",
      "receiptVouchers": "سندات القبض",
      "paymentVouchers": "سندات الصرف",
      "reports": "التقارير",
      "settings": "الإعدادات",
      "logout": "تسجيل الخروج",
      
      // Dashboard
      "totalAccounts": "إجمالي الحسابات",
      "totalCustomers": "إجمالي العملاء",
      "totalInvoices": "إجمالي الفواتير",
      "totalRevenue": "إجمالي الإيرادات",
      "recentTransactions": "المعاملات الأخيرة",
      
      // Chart of Accounts
      "accountCode": "رمز الحساب",
      "accountNameAr": "اسم الحساب (عربي)",
      "accountNameEn": "اسم الحساب (إنجليزي)",
      "accountType": "نوع الحساب",
      "parentCode": "الحساب الأب",
      "level": "المستوى",
      "status": "الحالة",
      "active": "نشط",
      "inactive": "غير نشط",
      "addAccount": "إضافة حساب",
      "editAccount": "تعديل حساب",
      "deleteAccount": "حذف حساب",
      
      // Account Types
      "asset": "أصل",
      "liability": "خصم",
      "equity": "حقوق ملكية",
      "revenue": "إيراد",
      "expense": "مصروف",
      
      // Opening Balances
      "fiscalYear": "السنة المالية",
      "debit": "مدين",
      "credit": "دائن",
      "balance": "الرصيد",
      "addOpeningBalance": "إضافة رصيد افتتاحي",
      
      // Customers
      "customerCode": "رمز العميل",
      "customerName": "اسم العميل",
      "phone": "الهاتف",
      "email": "البريد الإلكتروني",
      "address": "العنوان",
      "addCustomer": "إضافة عميل",
      "editCustomer": "تعديل عميل",
      
      // Invoices
      "invoiceNumber": "رقم الفاتورة",
      "invoiceDate": "تاريخ الفاتورة",
      "customer": "العميل",
      "items": "البنود",
      "description": "الوصف",
      "quantity": "الكمية",
      "unitPrice": "سعر الوحدة",
      "total": "الإجمالي",
      "subtotal": "المجموع الفرعي",
      "vat": "ضريبة القيمة المضافة",
      "totalAmount": "المبلغ الإجمالي",
      "notes": "ملاحظات",
      "addInvoice": "إضافة فاتورة",
      "addItem": "إضافة بند",
      
      // Journal Entries
      "entryNumber": "رقم القيد",
      "entryDate": "تاريخ القيد",
      "addJournalEntry": "إضافة قيد يومي",
      "addLine": "إضافة سطر",
      "totalDebit": "إجمالي المدين",
      "totalCredit": "إجمالي الدائن",
      
      // Vouchers
      "voucherNumber": "رقم السند",
      "voucherDate": "تاريخ السند",
      "receivedFrom": "مستلم من",
      "paidTo": "مدفوع إلى",
      "amount": "المبلغ",
      "paymentMethod": "طريقة الدفع",
      "cash": "نقدي",
      "check": "شيك",
      "bankTransfer": "تحويل بنكي",
      "addReceiptVoucher": "إضافة سند قبض",
      "addPaymentVoucher": "إضافة سند صرف",
      
      // Reports
      "trialBalance": "ميزان المراجعة",
      "accountStatement": "كشف الحساب",
      "generalLedger": "دفتر الأستاذ",
      "generateReport": "إنشاء تقرير",
      "exportPDF": "تصدير PDF",
      "exportExcel": "تصدير Excel",
      "exportWord": "تصدير Word",
      "print": "طباعة",
      
      // Common
      "save": "حفظ",
      "cancel": "إلغاء",
      "edit": "تعديل",
      "delete": "حذف",
      "view": "عرض",
      "search": "بحث",
      "actions": "الإجراءات",
      "loading": "جاري التحميل...",
      "noData": "لا توجد بيانات",
      "confirm": "تأكيد",
      "areYouSure": "هل أنت متأكد؟",
      "successfullySaved": "تم الحفظ بنجاح",
      "successfullyDeleted": "تم الحذف بنجاح",
      "error": "خطأ",
      "success": "نجاح",
    }
  }
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'ar',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;