import React, { createContext, useState, useContext, useEffect } from 'react';
import { setTenantContext, clearTenantContext, getTenantId } from '../utils/api';

const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [tenantId, setTenantIdState] = useState(localStorage.getItem('tenant_id'));
  const [tenantInfo, setTenantInfo] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    const storedUser = localStorage.getItem('user');
    const storedTenantId = localStorage.getItem('tenant_id');
    const storedTenantInfo = localStorage.getItem('tenant_info');
    
    if (storedToken && storedUser) {
      setToken(storedToken);
      setUser(JSON.parse(storedUser));
    }
    if (storedTenantId) {
      setTenantIdState(storedTenantId);
    }
    if (storedTenantInfo) {
      try {
        setTenantInfo(JSON.parse(storedTenantInfo));
      } catch (e) {
        // Ignore parse errors
      }
    }
    setLoading(false);
  }, []);

  const login = (tokenData, userData, tenantData = null) => {
    localStorage.setItem('token', tokenData);
    localStorage.setItem('user', JSON.stringify(userData));
    setToken(tokenData);
    setUser(userData);
    
    if (tenantData) {
      localStorage.setItem('tenant_id', tenantData.tenant_id);
      localStorage.setItem('tenant_info', JSON.stringify(tenantData));
      setTenantIdState(tenantData.tenant_id);
      setTenantInfo(tenantData);
      setTenantContext(tenantData.tenant_id);
    }
  };

  const setTenant = (tenantData) => {
    if (tenantData) {
      localStorage.setItem('tenant_id', tenantData.tenant_id);
      localStorage.setItem('tenant_info', JSON.stringify(tenantData));
      setTenantIdState(tenantData.tenant_id);
      setTenantInfo(tenantData);
      setTenantContext(tenantData.tenant_id);
    } else {
      localStorage.removeItem('tenant_id');
      localStorage.removeItem('tenant_info');
      setTenantIdState(null);
      setTenantInfo(null);
      clearTenantContext();
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('tenant_id');
    localStorage.removeItem('tenant_info');
    setToken(null);
    setUser(null);
    setTenantIdState(null);
    setTenantInfo(null);
    clearTenantContext();
  };

  // Check if user is in tenant context
  const isTenantMode = !!tenantId;
  
  // Get current tenant ID
  const currentTenantId = tenantId || getTenantId();

  return (
    <AuthContext.Provider value={{ 
      user, 
      token, 
      tenantId: currentTenantId,
      tenantInfo,
      login, 
      logout, 
      setTenant,
      loading, 
      isAuthenticated: !!token,
      isTenantMode 
    }}>
      {children}
    </AuthContext.Provider>
  );
};