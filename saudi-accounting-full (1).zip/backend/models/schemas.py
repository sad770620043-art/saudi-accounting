"""
Pydantic Models for the Saudi Accounting System
"""
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional
from datetime import datetime, timezone


# ==================== Tenant Models ====================

class Tenant(BaseModel):
    model_config = ConfigDict(extra="ignore")
    tenant_id: str
    company_name_ar: str
    company_name_en: str
    contact_person: str
    phone: str
    email: str
    license_type: str = "standard"
    license_expiry: str
    max_users: int = 5
    is_active: bool = True
    features: List[str] = []
    notes: str = ""
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class TenantCreate(BaseModel):
    company_name_ar: str
    company_name_en: str
    contact_person: str
    phone: str
    email: str
    license_type: str = "standard"
    license_expiry: str
    max_users: int = 5
    features: List[str] = []
    notes: str = ""


# ==================== Auth Models ====================

class SuperAdminLogin(BaseModel):
    username: str
    password: str


class UserLogin(BaseModel):
    username: str
    password: str


class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    username: str
    password_hash: str
    full_name: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class LoginRequest(BaseModel):
    username: str
    password: str


class LoginResponse(BaseModel):
    token: str
    username: str
    full_name: str


# ==================== Chart of Accounts Models ====================

class ChartOfAccount(BaseModel):
    model_config = ConfigDict(extra="ignore")
    account_code: str
    account_name_ar: str
    account_name_en: str
    account_type: str  # asset, liability, equity, revenue, expense
    parent_code: Optional[str] = None
    level: int
    is_active: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class OpeningBalance(BaseModel):
    model_config = ConfigDict(extra="ignore")
    account_code: str
    debit: float = 0.0
    credit: float = 0.0
    fiscal_year: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Customer Model ====================

class Customer(BaseModel):
    model_config = ConfigDict(extra="ignore")
    customer_code: str
    customer_name: str
    tax_number: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None
    is_active: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Invoice Models ====================

class InvoiceItem(BaseModel):
    description: str
    quantity: float
    unit_price: float
    total: float


class Invoice(BaseModel):
    model_config = ConfigDict(extra="ignore")
    invoice_number: str
    invoice_date: datetime
    customer_code: str
    items: List[InvoiceItem]
    subtotal: float
    vat_rate: float = 15.0
    vat_amount: float
    total_amount: float
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Journal Entry Models ====================

class JournalEntryLine(BaseModel):
    account_code: str
    description: str
    debit: float = 0.0
    credit: float = 0.0
    cost_center_code: Optional[str] = None
    project_code: Optional[str] = None


class JournalEntry(BaseModel):
    model_config = ConfigDict(extra="ignore")
    entry_number: str
    entry_date: datetime
    description: str
    lines: List[JournalEntryLine]
    total_debit: float
    total_credit: float
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Voucher Models ====================

class ReceiptVoucher(BaseModel):
    model_config = ConfigDict(extra="ignore")
    voucher_number: str
    voucher_date: datetime
    customer_code: Optional[str] = None
    received_from: str
    amount: float
    payment_method: str
    account_code: str
    description: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class PaymentVoucher(BaseModel):
    model_config = ConfigDict(extra="ignore")
    voucher_number: str
    voucher_date: datetime
    paid_to: str
    amount: float
    payment_method: str
    account_code: str
    description: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Cost Centers & Projects Models ====================

class CostCenter(BaseModel):
    model_config = ConfigDict(extra="ignore")
    center_code: str
    center_name_ar: str
    center_name_en: str = ""
    parent_code: Optional[str] = None
    is_active: bool = True
    description: str = ""
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Project(BaseModel):
    model_config = ConfigDict(extra="ignore")
    project_code: str
    project_name_ar: str
    project_name_en: str = ""
    client_name: str = ""
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    budget: float = 0.0
    status: str = "active"
    is_active: bool = True
    description: str = ""
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== Settings Models ====================

class CompanySettings(BaseModel):
    model_config = ConfigDict(extra="ignore")
    company_name_ar: str = ""
    company_name_en: str = ""
    commercial_registration: str = ""
    tax_number: str = ""
    address_ar: str = ""
    address_en: str = ""
    phone: str = ""
    email: str = ""
    logo_url: str = ""
    logo_base64: str = ""
    primary_color: str = "#006d5b"
    invoice_color: str = "#006d5b"
    voucher_color: str = "#006d5b"
    invoice_template: str = "classic"
    voucher_template: str = "classic"


# ==================== Historical Data Models ====================

class HistoricalYearData(BaseModel):
    model_config = ConfigDict(extra="ignore")
    year: int
    total_revenue: float = 0
    total_expense: float = 0
    q1_revenue: float = 0
    q1_expense: float = 0
    q2_revenue: float = 0
    q2_expense: float = 0
    q3_revenue: float = 0
    q3_expense: float = 0
    q4_revenue: float = 0
    q4_expense: float = 0
    notes: str = ""
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
