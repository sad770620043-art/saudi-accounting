"""
Database Configuration and Connection
"""
from motor.motor_asyncio import AsyncIOMotorClient
import os
from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent.parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

def get_tenant_db(tenant_id: str = None):
    """Get database for a specific tenant or default database"""
    if tenant_id:
        return client[f"{os.environ['DB_NAME']}_{tenant_id}"]
    return db

async def close_db_connection():
    """Close database connection"""
    client.close()
