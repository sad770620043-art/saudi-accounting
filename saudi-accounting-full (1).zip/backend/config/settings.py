"""
Application Settings and Configuration
"""
import os
from pathlib import Path
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).parent.parent
load_dotenv(ROOT_DIR / '.env')

# JWT Configuration
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key-change-in-production')
JWT_ALGORITHM = "HS256"

# Super Admin Credentials
SUPER_ADMIN_USERNAME = os.environ.get('SUPER_ADMIN_USERNAME', 'owner')
SUPER_ADMIN_PASSWORD = os.environ.get('SUPER_ADMIN_PASSWORD', 'owner@2024')

# CORS Settings
CORS_ORIGINS = os.environ.get('CORS_ORIGINS', '*').split(',')
