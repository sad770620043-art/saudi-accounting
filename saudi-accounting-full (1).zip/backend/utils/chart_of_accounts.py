"""
Default Chart of Accounts Loader
"""
import json
from pathlib import Path

ROOT_DIR = Path(__file__).parent.parent


def load_default_chart_of_accounts():
    """Load the default chart of accounts from JSON file"""
    json_path = ROOT_DIR / 'data' / 'default_chart_of_accounts.json'
    if json_path.exists():
        with open(json_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []


DEFAULT_CHART_OF_ACCOUNTS = load_default_chart_of_accounts()
