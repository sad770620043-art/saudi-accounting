"""
Authentication utilities
"""
from passlib.context import CryptContext
import jwt
from fastapi import HTTPException, Header
from datetime import datetime, timezone
from config.database import db, get_tenant_db
from config.settings import JWT_SECRET, JWT_ALGORITHM

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    """Hash a password"""
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against a hash"""
    return pwd_context.verify(plain_password, hashed_password)


def create_token(data: dict) -> str:
    """Create a JWT token"""
    return jwt.encode(data, JWT_SECRET, algorithm=JWT_ALGORITHM)


def verify_token(token: str) -> dict:
    """Verify and decode a JWT token"""
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except:
        raise HTTPException(status_code=401, detail="Invalid token")


async def get_current_tenant_db(x_tenant_id: str = Header(None)):
    """Get the database for the current tenant from header"""
    if x_tenant_id:
        # Verify tenant exists and is active
        tenant = await db.tenants.find_one({"tenant_id": x_tenant_id})
        if not tenant:
            raise HTTPException(status_code=404, detail="Tenant not found")
        if not tenant.get('is_active', True):
            raise HTTPException(status_code=403, detail="Tenant is deactivated")
        # Check license expiry
        if tenant.get('license_expiry'):
            expiry = datetime.strptime(tenant['license_expiry'], '%Y-%m-%d')
            if expiry < datetime.now():
                raise HTTPException(status_code=403, detail="License expired")
        return get_tenant_db(x_tenant_id)
    return db
