"""
Super Admin (Owner) API Routes
"""
from fastapi import APIRouter, HTTPException
from datetime import datetime, timezone, timedelta
import uuid

from config.database import db, get_tenant_db
from config.settings import SUPER_ADMIN_USERNAME, SUPER_ADMIN_PASSWORD, JWT_SECRET, JWT_ALGORITHM
from models import TenantCreate, SuperAdminLogin
from utils.auth import pwd_context, create_token
from utils.chart_of_accounts import DEFAULT_CHART_OF_ACCOUNTS

router = APIRouter(prefix="/super-admin", tags=["Super Admin"])


@router.post("/login")
async def super_admin_login(credentials: SuperAdminLogin):
    """Login for system owner/developer"""
    if credentials.username == SUPER_ADMIN_USERNAME and credentials.password == SUPER_ADMIN_PASSWORD:
        token = create_token({
            "username": credentials.username,
            "role": "super_admin",
            "exp": datetime.now(timezone.utc).timestamp() + 86400 * 7
        })
        return {
            "token": token,
            "username": credentials.username,
            "role": "super_admin"
        }
    raise HTTPException(status_code=401, detail="Invalid credentials")


@router.get("/tenants")
async def get_all_tenants():
    """Get all tenants/copies of the software"""
    tenants = await db.tenants.find({}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    for tenant in tenants:
        if tenant.get('license_expiry'):
            expiry_date = datetime.strptime(tenant['license_expiry'], '%Y-%m-%d')
            tenant['is_expired'] = expiry_date < datetime.now()
            tenant['days_remaining'] = (expiry_date - datetime.now()).days
        else:
            tenant['is_expired'] = True
            tenant['days_remaining'] = 0
    return tenants


@router.post("/tenants")
async def create_tenant(tenant: TenantCreate):
    """Create a new tenant/copy with its own database"""
    tenant_id = str(uuid.uuid4())[:8].upper()
    
    existing = await db.tenants.find_one({"email": tenant.email})
    if existing:
        raise HTTPException(status_code=400, detail="Tenant with this email already exists")
    
    doc = tenant.model_dump()
    doc['tenant_id'] = tenant_id
    doc['is_active'] = True
    doc['created_at'] = datetime.now(timezone.utc).isoformat()
    doc['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    await db.tenants.insert_one(doc)
    
    # Create tenant's own database with initial data
    tenant_db = get_tenant_db(tenant_id)
    
    # Create admin user for this tenant
    hashed_password = pwd_context.hash("admin123")
    await tenant_db.users.insert_one({
        "username": "admin",
        "full_name": "مدير النظام",
        "password_hash": hashed_password,
        "role": "admin",
        "created_at": datetime.now(timezone.utc)
    })
    
    # Create company settings
    await tenant_db.company_settings.insert_one({
        "company_name_ar": tenant.company_name_ar,
        "company_name_en": tenant.company_name_en,
        "commercial_registration": "",
        "tax_number": "",
        "address_ar": "",
        "address_en": "",
        "phone": tenant.phone,
        "email": tenant.email,
        "logo_url": "",
        "logo_base64": "",
        "primary_color": "#006d5b",
        "invoice_color": "#006d5b",
        "voucher_color": "#006d5b",
        "invoice_template": "classic",
        "voucher_template": "classic",
        "license_expiry": tenant.license_expiry,
        "app_version": "1.0.0",
        "created_at": datetime.now(timezone.utc).isoformat()
    })
    
    # Create default chart of accounts from JSON file (2145 accounts)
    if DEFAULT_CHART_OF_ACCOUNTS:
        accounts_to_insert = []
        for acc in DEFAULT_CHART_OF_ACCOUNTS:
            accounts_to_insert.append({
                "account_code": acc["account_code"],
                "account_name_ar": acc["account_name_ar"],
                "account_name_en": acc.get("account_name_en", ""),
                "account_type": acc["account_type"],
                "parent_code": acc["parent_code"],
                "level": acc["level"],
                "is_active": acc["is_active"],
                "nature": acc.get("nature", "debit"),
                "closing_type": acc.get("closing_type", "balance_sheet"),
                "created_at": datetime.now(timezone.utc).isoformat()
            })
        await tenant_db.chart_of_accounts.insert_many(accounts_to_insert)
    
    return {
        "message": "Tenant created successfully",
        "tenant_id": tenant_id,
        "login_url": f"/tenant/{tenant_id}",
        "admin_username": "admin",
        "admin_password": "admin123"
    }


@router.get("/tenants/{tenant_id}")
async def get_tenant(tenant_id: str):
    """Get tenant details"""
    tenant = await db.tenants.find_one({"tenant_id": tenant_id}, {"_id": 0})
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    return tenant


@router.put("/tenants/{tenant_id}")
async def update_tenant(tenant_id: str, tenant: TenantCreate):
    """Update tenant information"""
    doc = tenant.model_dump()
    doc['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    result = await db.tenants.update_one(
        {"tenant_id": tenant_id},
        {"$set": doc}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    return {"message": "Tenant updated successfully"}


@router.put("/tenants/{tenant_id}/toggle-status")
async def toggle_tenant_status(tenant_id: str):
    """Activate or deactivate a tenant"""
    tenant = await db.tenants.find_one({"tenant_id": tenant_id})
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    new_status = not tenant.get('is_active', True)
    await db.tenants.update_one(
        {"tenant_id": tenant_id},
        {"$set": {"is_active": new_status, "updated_at": datetime.now(timezone.utc).isoformat()}}
    )
    
    return {"message": f"Tenant {'activated' if new_status else 'deactivated'}", "is_active": new_status}


@router.put("/tenants/{tenant_id}/extend-license")
async def extend_tenant_license(tenant_id: str, days: int = 30):
    """Extend tenant license by specified days"""
    tenant = await db.tenants.find_one({"tenant_id": tenant_id})
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    current_expiry = datetime.strptime(tenant['license_expiry'], '%Y-%m-%d')
    if current_expiry < datetime.now():
        current_expiry = datetime.now()
    
    new_expiry = current_expiry + timedelta(days=days)
    
    await db.tenants.update_one(
        {"tenant_id": tenant_id},
        {"$set": {
            "license_expiry": new_expiry.strftime('%Y-%m-%d'),
            "updated_at": datetime.now(timezone.utc).isoformat()
        }}
    )
    
    return {
        "message": f"License extended by {days} days",
        "new_expiry": new_expiry.strftime('%Y-%m-%d')
    }


@router.delete("/tenants/{tenant_id}")
async def delete_tenant(tenant_id: str):
    """Delete a tenant permanently"""
    result = await db.tenants.delete_one({"tenant_id": tenant_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Tenant not found")
    return {"message": "Tenant deleted successfully"}


@router.get("/statistics")
async def get_super_admin_statistics():
    """Get overall statistics for all tenants"""
    total_tenants = await db.tenants.count_documents({})
    active_tenants = await db.tenants.count_documents({"is_active": True})
    
    today = datetime.now().strftime('%Y-%m-%d')
    expired_tenants = await db.tenants.count_documents({"license_expiry": {"$lt": today}})
    
    expiring_soon_date = (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%d')
    expiring_soon = await db.tenants.count_documents({
        "license_expiry": {"$gte": today, "$lte": expiring_soon_date}
    })
    
    standard = await db.tenants.count_documents({"license_type": "standard"})
    premium = await db.tenants.count_documents({"license_type": "premium"})
    enterprise = await db.tenants.count_documents({"license_type": "enterprise"})
    
    return {
        "total_tenants": total_tenants,
        "active_tenants": active_tenants,
        "inactive_tenants": total_tenants - active_tenants,
        "expired_tenants": expired_tenants,
        "expiring_soon": expiring_soon,
        "license_distribution": {
            "standard": standard,
            "premium": premium,
            "enterprise": enterprise
        }
    }


@router.get("/license-alerts")
async def get_license_alerts():
    """Get license expiry alerts"""
    today = datetime.now()
    today_str = today.strftime('%Y-%m-%d')
    
    # Get all tenants
    tenants = await db.tenants.find({"is_active": True}, {"_id": 0}).to_list(1000)
    
    alerts = []
    critical_count = 0
    high_count = 0
    medium_count = 0
    
    for tenant in tenants:
        if not tenant.get('license_expiry'):
            continue
            
        expiry = datetime.strptime(tenant['license_expiry'], '%Y-%m-%d')
        days_remaining = (expiry - today).days
        
        if days_remaining < 0:
            # Expired
            alerts.append({
                "tenant_id": tenant['tenant_id'],
                "company_name_ar": tenant['company_name_ar'],
                "license_expiry": tenant['license_expiry'],
                "days_remaining": days_remaining,
                "severity": "critical",
                "message_ar": f"منتهي منذ {abs(days_remaining)} يوم",
                "message_en": f"Expired {abs(days_remaining)} days ago"
            })
            critical_count += 1
        elif days_remaining <= 7:
            # Expires within 7 days
            alerts.append({
                "tenant_id": tenant['tenant_id'],
                "company_name_ar": tenant['company_name_ar'],
                "license_expiry": tenant['license_expiry'],
                "days_remaining": days_remaining,
                "severity": "high",
                "message_ar": f"ينتهي خلال {days_remaining} يوم",
                "message_en": f"Expires in {days_remaining} days"
            })
            high_count += 1
        elif days_remaining <= 30:
            # Expires within 30 days
            alerts.append({
                "tenant_id": tenant['tenant_id'],
                "company_name_ar": tenant['company_name_ar'],
                "license_expiry": tenant['license_expiry'],
                "days_remaining": days_remaining,
                "severity": "medium",
                "message_ar": f"ينتهي خلال {days_remaining} يوم",
                "message_en": f"Expires in {days_remaining} days"
            })
            medium_count += 1
    
    # Sort by severity and days remaining
    severity_order = {"critical": 0, "high": 1, "medium": 2}
    alerts.sort(key=lambda x: (severity_order[x['severity']], x['days_remaining']))
    
    return {
        "total_alerts": len(alerts),
        "critical": critical_count,
        "high": high_count,
        "medium": medium_count,
        "alerts": alerts
    }
