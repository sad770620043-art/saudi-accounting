"""
Authentication Routes
"""
from fastapi import APIRouter, HTTPException, Header
from datetime import datetime, timezone

from config.database import db
from models import LoginRequest, LoginResponse, User, UserLogin
from utils.auth import pwd_context, create_token, get_current_tenant_db

router = APIRouter(tags=["Authentication"])


@router.post("/auth/login", response_model=LoginResponse)
async def login(request: LoginRequest):
    """Standard user login"""
    user = await db.users.find_one({"username": request.username}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    if not pwd_context.verify(request.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    token = create_token({"username": user["username"]})
    
    return LoginResponse(
        token=token,
        username=user["username"],
        full_name=user["full_name"]
    )


@router.post("/auth/init")
async def init_user():
    """Initialize default admin user"""
    existing = await db.users.find_one({"username": "admin"})
    if existing:
        return {"message": "User already exists"}
    
    user = User(
        username="admin",
        password_hash=pwd_context.hash("admin123"),
        full_name="Administrator"
    )
    
    doc = user.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    await db.users.insert_one(doc)
    
    return {"message": "Admin user created", "username": "admin", "password": "admin123"}


@router.post("/tenant/login")
async def tenant_login(user: UserLogin, x_tenant_id: str = Header(None)):
    """Login for a specific tenant"""
    tenant_db = await get_current_tenant_db(x_tenant_id)
    
    db_user = await tenant_db.users.find_one({"username": user.username})
    if not db_user or not pwd_context.verify(user.password, db_user['password_hash']):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    token = create_token({
        "username": user.username,
        "tenant_id": x_tenant_id,
        "exp": datetime.now(timezone.utc).timestamp() + 86400
    })
    
    return {
        "token": token,
        "username": user.username,
        "full_name": db_user.get('full_name', user.username),
        "tenant_id": x_tenant_id
    }


@router.get("/tenant/info")
async def get_tenant_info(x_tenant_id: str = Header(None)):
    """Get current tenant information"""
    if not x_tenant_id:
        raise HTTPException(status_code=400, detail="Tenant ID required")
    
    tenant = await db.tenants.find_one({"tenant_id": x_tenant_id}, {"_id": 0})
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    return tenant
