"""
Test cases for new Journal Entry features:
1. Auto-generated entry number (JE-YYYY-XXXXX format)
2. Add new account from within journal entry form
"""
import pytest
import requests
import os
from datetime import datetime

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

class TestJournalEntryNextNumber:
    """Test auto-generated journal entry number endpoint"""
    
    def test_next_number_endpoint_returns_200(self):
        """Test that /api/journal-entries/next-number returns 200"""
        response = requests.get(f"{BASE_URL}/api/journal-entries/next-number")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        print(f"✓ GET /api/journal-entries/next-number returned 200")
    
    def test_next_number_format(self):
        """Test that next number follows JE-YYYY-XXXXX format"""
        response = requests.get(f"{BASE_URL}/api/journal-entries/next-number")
        assert response.status_code == 200
        
        data = response.json()
        assert "next_number" in data, "Response should contain 'next_number' field"
        
        next_number = data["next_number"]
        current_year = datetime.now().year
        
        # Verify format: JE-YYYY-XXXXX
        assert next_number.startswith(f"JE-{current_year}-"), f"Expected format JE-{current_year}-XXXXX, got {next_number}"
        
        # Verify the number part is 5 digits
        parts = next_number.split("-")
        assert len(parts) == 3, f"Expected 3 parts separated by '-', got {len(parts)}"
        assert len(parts[2]) == 5, f"Expected 5-digit number, got {parts[2]}"
        assert parts[2].isdigit(), f"Last part should be numeric, got {parts[2]}"
        
        print(f"✓ Next number format is correct: {next_number}")
    
    def test_next_number_increments_after_entry_creation(self):
        """Test that next number increments after creating a journal entry"""
        # Get initial next number
        response1 = requests.get(f"{BASE_URL}/api/journal-entries/next-number")
        assert response1.status_code == 200
        initial_number = response1.json()["next_number"]
        
        # Create a journal entry with this number
        entry_data = {
            "entry_number": initial_number,
            "entry_date": datetime.now().isoformat(),
            "description": "TEST_Auto-generated entry number test",
            "lines": [
                {"account_code": "11110", "description": "Test debit", "debit": 100, "credit": 0},
                {"account_code": "21110", "description": "Test credit", "debit": 0, "credit": 100}
            ],
            "total_debit": 100,
            "total_credit": 100
        }
        
        create_response = requests.post(f"{BASE_URL}/api/journal-entries", json=entry_data)
        assert create_response.status_code == 200, f"Failed to create entry: {create_response.text}"
        
        # Get next number again
        response2 = requests.get(f"{BASE_URL}/api/journal-entries/next-number")
        assert response2.status_code == 200
        new_number = response2.json()["next_number"]
        
        # Verify it incremented
        initial_seq = int(initial_number.split("-")[-1])
        new_seq = int(new_number.split("-")[-1])
        assert new_seq == initial_seq + 1, f"Expected {initial_seq + 1}, got {new_seq}"
        
        print(f"✓ Next number incremented from {initial_number} to {new_number}")


class TestAccountCreation:
    """Test account creation endpoint (used by add account dialog)"""
    
    def test_create_account_success(self):
        """Test creating a new account"""
        import uuid
        unique_code = f"TEST{uuid.uuid4().hex[:6].upper()}"
        
        account_data = {
            "account_code": unique_code,
            "account_name_ar": "حساب اختبار",
            "account_name_en": "Test Account",
            "account_type": "expense",
            "parent_code": "52000",
            "level": 4,
            "is_active": True
        }
        
        response = requests.post(f"{BASE_URL}/api/accounts", json=account_data)
        assert response.status_code == 200, f"Failed to create account: {response.text}"
        
        data = response.json()
        assert data["account_code"] == unique_code
        assert data["account_name_ar"] == "حساب اختبار"
        
        print(f"✓ Created account {unique_code} successfully")
        
        # Verify account appears in accounts list
        list_response = requests.get(f"{BASE_URL}/api/accounts")
        assert list_response.status_code == 200
        accounts = list_response.json()
        account_codes = [a["account_code"] for a in accounts]
        assert unique_code in account_codes, f"Created account {unique_code} not found in accounts list"
        
        print(f"✓ Account {unique_code} appears in accounts list")
    
    def test_create_account_duplicate_code_fails(self):
        """Test that creating account with duplicate code fails"""
        # First, get an existing account code
        response = requests.get(f"{BASE_URL}/api/accounts")
        assert response.status_code == 200
        accounts = response.json()
        assert len(accounts) > 0, "No accounts found"
        
        existing_code = accounts[0]["account_code"]
        
        # Try to create account with same code
        account_data = {
            "account_code": existing_code,
            "account_name_ar": "حساب مكرر",
            "account_name_en": "Duplicate Account",
            "account_type": "expense",
            "level": 4,
            "is_active": True
        }
        
        response = requests.post(f"{BASE_URL}/api/accounts", json=account_data)
        assert response.status_code == 400, f"Expected 400 for duplicate code, got {response.status_code}"
        
        print(f"✓ Duplicate account code {existing_code} correctly rejected")
    
    def test_get_accounts_returns_list(self):
        """Test that accounts endpoint returns a list"""
        response = requests.get(f"{BASE_URL}/api/accounts")
        assert response.status_code == 200
        
        accounts = response.json()
        assert isinstance(accounts, list), "Expected list of accounts"
        assert len(accounts) > 0, "Expected at least one account"
        
        # Verify account structure
        first_account = accounts[0]
        required_fields = ["account_code", "account_name_ar", "account_type", "level", "is_active"]
        for field in required_fields:
            assert field in first_account, f"Missing field: {field}"
        
        print(f"✓ Accounts endpoint returns {len(accounts)} accounts with correct structure")


class TestJournalEntryCreation:
    """Test journal entry creation with accounts"""
    
    def test_create_journal_entry_with_valid_accounts(self):
        """Test creating a journal entry with valid account codes"""
        # Get next entry number
        next_response = requests.get(f"{BASE_URL}/api/journal-entries/next-number")
        assert next_response.status_code == 200
        entry_number = next_response.json()["next_number"]
        
        entry_data = {
            "entry_number": entry_number,
            "entry_date": datetime.now().isoformat(),
            "description": "TEST_Journal entry with valid accounts",
            "lines": [
                {"account_code": "11110", "description": "Cash debit", "debit": 500, "credit": 0},
                {"account_code": "41100", "description": "Sales credit", "debit": 0, "credit": 500}
            ],
            "total_debit": 500,
            "total_credit": 500
        }
        
        response = requests.post(f"{BASE_URL}/api/journal-entries", json=entry_data)
        assert response.status_code == 200, f"Failed to create entry: {response.text}"
        
        data = response.json()
        assert data["entry_number"] == entry_number
        assert data["total_debit"] == 500
        assert data["total_credit"] == 500
        
        print(f"✓ Created journal entry {entry_number} successfully")
    
    def test_create_journal_entry_unbalanced_fails(self):
        """Test that unbalanced journal entry fails"""
        entry_data = {
            "entry_number": "TEST-UNBALANCED-001",
            "entry_date": datetime.now().isoformat(),
            "description": "TEST_Unbalanced entry",
            "lines": [
                {"account_code": "11110", "description": "Cash debit", "debit": 500, "credit": 0},
                {"account_code": "41100", "description": "Sales credit", "debit": 0, "credit": 400}
            ],
            "total_debit": 500,
            "total_credit": 400
        }
        
        response = requests.post(f"{BASE_URL}/api/journal-entries", json=entry_data)
        assert response.status_code == 400, f"Expected 400 for unbalanced entry, got {response.status_code}"
        
        print("✓ Unbalanced journal entry correctly rejected")


class TestTenantSpecificFeatures:
    """Test features work with tenant-specific database"""
    
    def test_next_number_with_tenant_header(self):
        """Test next number endpoint with X-Tenant-ID header"""
        headers = {"X-Tenant-ID": "C447CEF2"}
        
        response = requests.get(f"{BASE_URL}/api/journal-entries/next-number", headers=headers)
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert "next_number" in data
        
        print(f"✓ Tenant-specific next number: {data['next_number']}")
    
    def test_create_account_with_tenant_header(self):
        """Test account creation with X-Tenant-ID header"""
        import uuid
        unique_code = f"TENANT{uuid.uuid4().hex[:4].upper()}"
        headers = {"X-Tenant-ID": "C447CEF2"}
        
        account_data = {
            "account_code": unique_code,
            "account_name_ar": "حساب اختبار للمستأجر",
            "account_name_en": "Tenant Test Account",
            "account_type": "expense",
            "level": 4,
            "is_active": True
        }
        
        response = requests.post(f"{BASE_URL}/api/accounts", json=account_data, headers=headers)
        assert response.status_code == 200, f"Failed to create tenant account: {response.text}"
        
        print(f"✓ Created tenant-specific account {unique_code}")


@pytest.fixture(scope="session", autouse=True)
def cleanup_test_data():
    """Cleanup test data after all tests"""
    yield
    # Note: In production, you'd want to clean up TEST_ prefixed entries
    print("\n✓ Test session completed")
