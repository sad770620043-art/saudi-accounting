"""
Test suite for Quarterly Reports feature
Tests:
- GET /api/reports/quarterly - Quarterly financial report endpoint
- POST /api/reports/quarterly/ai-analysis - AI analysis endpoint
"""

import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

class TestQuarterlyReportEndpoint:
    """Tests for GET /api/reports/quarterly endpoint"""
    
    def test_quarterly_report_returns_200(self):
        """Test that quarterly report endpoint returns 200 status"""
        response = requests.get(f"{BASE_URL}/api/reports/quarterly?year=2025&quarter=1")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        print("✓ Quarterly report endpoint returns 200")
    
    def test_quarterly_report_response_structure(self):
        """Test that response has correct structure with all required fields"""
        response = requests.get(f"{BASE_URL}/api/reports/quarterly?year=2025&quarter=1")
        data = response.json()
        
        # Check period structure
        assert "period" in data, "Missing 'period' in response"
        period = data["period"]
        assert "year" in period, "Missing 'year' in period"
        assert "quarter" in period, "Missing 'quarter' in period"
        assert "quarter_name" in period, "Missing 'quarter_name' in period"
        assert "start_date" in period, "Missing 'start_date' in period"
        assert "end_date" in period, "Missing 'end_date' in period"
        print("✓ Period structure is correct")
        
        # Check summary structure
        assert "summary" in data, "Missing 'summary' in response"
        summary = data["summary"]
        assert "carried_forward" in summary, "Missing 'carried_forward' in summary"
        assert "current_period" in summary, "Missing 'current_period' in summary"
        assert "closing_balance" in summary, "Missing 'closing_balance' in summary"
        assert "bank_balance" in summary, "Missing 'bank_balance' in summary"
        print("✓ Summary structure is correct")
        
        # Check carried_forward structure
        cf = summary["carried_forward"]
        assert "revenue" in cf, "Missing 'revenue' in carried_forward"
        assert "expense" in cf, "Missing 'expense' in carried_forward"
        assert "net" in cf, "Missing 'net' in carried_forward"
        print("✓ Carried forward structure is correct")
        
        # Check chart_data
        assert "chart_data" in data, "Missing 'chart_data' in response"
        assert isinstance(data["chart_data"], list), "chart_data should be a list"
        print("✓ Chart data is present and is a list")
        
        # Check top accounts
        assert "top_revenue_accounts" in data, "Missing 'top_revenue_accounts' in response"
        assert "top_expense_accounts" in data, "Missing 'top_expense_accounts' in response"
        print("✓ Top accounts fields are present")
        
        # Check totals
        assert "totals" in data, "Missing 'totals' in response"
        totals = data["totals"]
        assert "total_revenue" in totals, "Missing 'total_revenue' in totals"
        assert "total_expense" in totals, "Missing 'total_expense' in totals"
        assert "net_profit" in totals, "Missing 'net_profit' in totals"
        assert "profit_margin" in totals, "Missing 'profit_margin' in totals"
        print("✓ Totals structure is correct")
    
    def test_quarterly_report_all_quarters(self):
        """Test that all 4 quarters return valid data"""
        for quarter in [1, 2, 3, 4]:
            response = requests.get(f"{BASE_URL}/api/reports/quarterly?year=2025&quarter={quarter}")
            assert response.status_code == 200, f"Quarter {quarter} failed with status {response.status_code}"
            data = response.json()
            assert data["period"]["quarter"] == quarter, f"Quarter mismatch for Q{quarter}"
        print("✓ All 4 quarters return valid data")
    
    def test_quarterly_report_invalid_quarter(self):
        """Test that invalid quarter returns 400 error"""
        response = requests.get(f"{BASE_URL}/api/reports/quarterly?year=2025&quarter=5")
        assert response.status_code == 400, f"Expected 400 for invalid quarter, got {response.status_code}"
        print("✓ Invalid quarter returns 400 error")
    
    def test_quarterly_report_chart_data_structure(self):
        """Test that chart_data has correct monthly structure"""
        response = requests.get(f"{BASE_URL}/api/reports/quarterly?year=2025&quarter=1")
        data = response.json()
        chart_data = data["chart_data"]
        
        # Q1 should have 3 months
        assert len(chart_data) == 3, f"Expected 3 months in Q1, got {len(chart_data)}"
        
        for month_data in chart_data:
            assert "month" in month_data, "Missing 'month' in chart_data item"
            assert "revenue" in month_data, "Missing 'revenue' in chart_data item"
            assert "expense" in month_data, "Missing 'expense' in chart_data item"
            assert "net" in month_data, "Missing 'net' in chart_data item"
        print("✓ Chart data has correct monthly structure")
    
    def test_quarterly_report_different_years(self):
        """Test quarterly report for different years"""
        for year in [2024, 2025, 2026]:
            response = requests.get(f"{BASE_URL}/api/reports/quarterly?year={year}&quarter=1")
            assert response.status_code == 200, f"Year {year} failed with status {response.status_code}"
            data = response.json()
            assert data["period"]["year"] == year, f"Year mismatch for {year}"
        print("✓ Different years return valid data")


class TestQuarterlyAIAnalysisEndpoint:
    """Tests for POST /api/reports/quarterly/ai-analysis endpoint"""
    
    def test_ai_analysis_returns_200(self):
        """Test that AI analysis endpoint returns 200 status"""
        payload = {
            "report_data": {
                "period": {"year": 2025, "quarter": 1},
                "summary": {
                    "carried_forward": {"revenue": 0, "expense": 0, "net": 0},
                    "bank_balance": 0
                },
                "totals": {
                    "total_revenue": 0,
                    "total_expense": 0,
                    "net_profit": 0,
                    "profit_margin": 0
                },
                "top_expense_accounts": [],
                "top_revenue_accounts": []
            }
        }
        response = requests.post(
            f"{BASE_URL}/api/reports/quarterly/ai-analysis",
            json=payload
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        print("✓ AI analysis endpoint returns 200")
    
    def test_ai_analysis_response_structure(self):
        """Test that AI analysis response has correct structure"""
        payload = {
            "report_data": {
                "period": {"year": 2025, "quarter": 1},
                "summary": {
                    "carried_forward": {"revenue": 1000, "expense": 500, "net": 500},
                    "bank_balance": 5000
                },
                "totals": {
                    "total_revenue": 10000,
                    "total_expense": 7000,
                    "net_profit": 3000,
                    "profit_margin": 30
                },
                "top_expense_accounts": [
                    {"account_name": "رواتب", "amount": 3000},
                    {"account_name": "إيجار", "amount": 2000}
                ],
                "top_revenue_accounts": [
                    {"account_name": "مبيعات", "amount": 8000},
                    {"account_name": "خدمات", "amount": 2000}
                ]
            }
        }
        response = requests.post(
            f"{BASE_URL}/api/reports/quarterly/ai-analysis",
            json=payload
        )
        data = response.json()
        
        assert "analysis" in data, "Missing 'analysis' in response"
        assert "generated_at" in data, "Missing 'generated_at' in response"
        assert isinstance(data["analysis"], str), "Analysis should be a string"
        assert len(data["analysis"]) > 50, "Analysis should have meaningful content"
        print("✓ AI analysis response structure is correct")
    
    def test_ai_analysis_with_financial_data(self):
        """Test AI analysis with actual financial data"""
        payload = {
            "report_data": {
                "period": {"year": 2025, "quarter": 1},
                "summary": {
                    "carried_forward": {"revenue": 50000, "expense": 30000, "net": 20000},
                    "bank_balance": 100000
                },
                "totals": {
                    "total_revenue": 150000,
                    "total_expense": 100000,
                    "net_profit": 50000,
                    "profit_margin": 33.33
                },
                "top_expense_accounts": [
                    {"account_name": "الرواتب والأجور", "amount": 40000},
                    {"account_name": "إيجار المكتب", "amount": 20000},
                    {"account_name": "الكهرباء والماء", "amount": 5000}
                ],
                "top_revenue_accounts": [
                    {"account_name": "مبيعات البضائع", "amount": 100000},
                    {"account_name": "مبيعات الخدمات", "amount": 50000}
                ]
            }
        }
        response = requests.post(
            f"{BASE_URL}/api/reports/quarterly/ai-analysis",
            json=payload,
            timeout=60  # AI analysis may take time
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        assert len(data["analysis"]) > 100, "AI analysis should provide detailed content"
        print("✓ AI analysis with financial data works correctly")


class TestQuarterlyReportIntegration:
    """Integration tests for quarterly reports flow"""
    
    def test_full_quarterly_report_flow(self):
        """Test getting quarterly report and then AI analysis"""
        # Step 1: Get quarterly report
        report_response = requests.get(f"{BASE_URL}/api/reports/quarterly?year=2025&quarter=1")
        assert report_response.status_code == 200, "Failed to get quarterly report"
        report_data = report_response.json()
        
        # Step 2: Send report data to AI analysis
        ai_response = requests.post(
            f"{BASE_URL}/api/reports/quarterly/ai-analysis",
            json={"report_data": report_data},
            timeout=60
        )
        assert ai_response.status_code == 200, "Failed to get AI analysis"
        ai_data = ai_response.json()
        
        assert "analysis" in ai_data, "AI response missing analysis"
        print("✓ Full quarterly report flow works correctly")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
