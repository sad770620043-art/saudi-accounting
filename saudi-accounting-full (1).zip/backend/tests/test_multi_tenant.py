"""
Multi-Tenant API Tests for Saudi Accounting System
Tests Owner Panel login, tenant management, and tenant-specific data isolation
"""
import pytest
import requests
import os
import uuid

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'https://saudi-ledger.preview.emergentagent.com').rstrip('/')

# Test credentials
OWNER_USERNAME = "owner"
OWNER_PASSWORD = "owner@2024"
TENANT_USERNAME = "admin"
TENANT_PASSWORD = "admin123"
EXISTING_TENANT_ID = "C447CEF2"


class TestOwnerPanelLogin:
    """Test Owner/Super Admin login functionality"""
    
    def test_owner_login_success(self):
        """Test successful owner login with correct credentials"""
        response = requests.post(f"{BASE_URL}/api/super-admin/login", json={
            "username": OWNER_USERNAME,
            "password": OWNER_PASSWORD
        })
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        
        data = response.json()
        assert "token" in data, "Response should contain token"
        assert data["username"] == OWNER_USERNAME
        assert data["role"] == "super_admin"
        print(f"✓ Owner login successful: {data['username']} with role {data['role']}")
    
    def test_owner_login_invalid_credentials(self):
        """Test owner login with invalid credentials"""
        response = requests.post(f"{BASE_URL}/api/super-admin/login", json={
            "username": "wrong_user",
            "password": "wrong_pass"
        })
        assert response.status_code == 401, f"Expected 401, got {response.status_code}"
        print("✓ Invalid owner credentials correctly rejected")


class TestTenantManagement:
    """Test tenant CRUD operations from Owner Panel"""
    
    @pytest.fixture
    def owner_token(self):
        """Get owner authentication token"""
        response = requests.post(f"{BASE_URL}/api/super-admin/login", json={
            "username": OWNER_USERNAME,
            "password": OWNER_PASSWORD
        })
        if response.status_code == 200:
            return response.json().get("token")
        pytest.skip("Owner authentication failed")
    
    def test_get_all_tenants(self, owner_token):
        """Test retrieving all tenants"""
        response = requests.get(f"{BASE_URL}/api/super-admin/tenants")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        tenants = response.json()
        assert isinstance(tenants, list), "Response should be a list"
        print(f"✓ Retrieved {len(tenants)} tenants")
        
        # Verify tenant structure
        if len(tenants) > 0:
            tenant = tenants[0]
            assert "tenant_id" in tenant
            assert "company_name_ar" in tenant
            assert "is_active" in tenant
            assert "license_expiry" in tenant
            print(f"✓ Tenant structure verified: {tenant['tenant_id']} - {tenant['company_name_ar']}")
    
    def test_get_statistics(self, owner_token):
        """Test retrieving owner statistics"""
        response = requests.get(f"{BASE_URL}/api/super-admin/statistics")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        stats = response.json()
        assert "total_tenants" in stats
        assert "active_tenants" in stats
        assert "expired_tenants" in stats
        assert "license_distribution" in stats
        print(f"✓ Statistics: {stats['total_tenants']} total, {stats['active_tenants']} active")
    
    def test_create_tenant(self, owner_token):
        """Test creating a new tenant"""
        unique_email = f"test_{uuid.uuid4().hex[:8]}@test.com"
        tenant_data = {
            "company_name_ar": "شركة اختبار جديدة",
            "company_name_en": "New Test Company",
            "contact_person": "Test Person",
            "phone": "0501234567",
            "email": unique_email,
            "license_type": "standard",
            "license_expiry": "2027-12-31",
            "max_users": 5,
            "features": ["invoices", "vouchers"],
            "notes": "Test tenant"
        }
        
        response = requests.post(f"{BASE_URL}/api/super-admin/tenants", json=tenant_data)
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        
        data = response.json()
        assert "tenant_id" in data, "Response should contain tenant_id"
        assert "admin_username" in data
        assert "admin_password" in data
        print(f"✓ Created tenant: {data['tenant_id']} with admin credentials")
        
        # Store for cleanup
        return data["tenant_id"]
    
    def test_get_specific_tenant(self, owner_token):
        """Test retrieving a specific tenant"""
        response = requests.get(f"{BASE_URL}/api/super-admin/tenants/{EXISTING_TENANT_ID}")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        tenant = response.json()
        assert tenant["tenant_id"] == EXISTING_TENANT_ID
        print(f"✓ Retrieved tenant: {tenant['company_name_ar']}")
    
    def test_toggle_tenant_status(self, owner_token):
        """Test toggling tenant active status"""
        # First get current status
        response = requests.get(f"{BASE_URL}/api/super-admin/tenants/{EXISTING_TENANT_ID}")
        original_status = response.json().get("is_active", True)
        
        # Toggle status
        response = requests.put(f"{BASE_URL}/api/super-admin/tenants/{EXISTING_TENANT_ID}/toggle-status")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert data["is_active"] != original_status
        print(f"✓ Toggled tenant status from {original_status} to {data['is_active']}")
        
        # Toggle back to original
        requests.put(f"{BASE_URL}/api/super-admin/tenants/{EXISTING_TENANT_ID}/toggle-status")
        print("✓ Restored original status")


class TestTenantLogin:
    """Test tenant-specific login functionality"""
    
    def test_tenant_info_retrieval(self):
        """Test retrieving tenant info with X-Tenant-ID header"""
        response = requests.get(
            f"{BASE_URL}/api/tenant/info",
            headers={"X-Tenant-ID": EXISTING_TENANT_ID}
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        tenant = response.json()
        assert tenant["tenant_id"] == EXISTING_TENANT_ID
        assert "company_name_ar" in tenant
        assert "license_expiry" in tenant
        print(f"✓ Tenant info: {tenant['company_name_ar']} ({tenant['tenant_id']})")
    
    def test_tenant_login_success(self):
        """Test successful tenant login with admin credentials"""
        response = requests.post(
            f"{BASE_URL}/api/tenant/login",
            json={"username": TENANT_USERNAME, "password": TENANT_PASSWORD},
            headers={"X-Tenant-ID": EXISTING_TENANT_ID}
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        
        data = response.json()
        assert "token" in data
        assert data["username"] == TENANT_USERNAME
        assert data["tenant_id"] == EXISTING_TENANT_ID
        print(f"✓ Tenant login successful: {data['full_name']} for tenant {data['tenant_id']}")
    
    def test_tenant_login_invalid_credentials(self):
        """Test tenant login with invalid credentials"""
        response = requests.post(
            f"{BASE_URL}/api/tenant/login",
            json={"username": "wrong", "password": "wrong"},
            headers={"X-Tenant-ID": EXISTING_TENANT_ID}
        )
        assert response.status_code == 401, f"Expected 401, got {response.status_code}"
        print("✓ Invalid tenant credentials correctly rejected")
    
    def test_tenant_login_invalid_tenant(self):
        """Test tenant login with non-existent tenant ID"""
        response = requests.post(
            f"{BASE_URL}/api/tenant/login",
            json={"username": TENANT_USERNAME, "password": TENANT_PASSWORD},
            headers={"X-Tenant-ID": "INVALID123"}
        )
        assert response.status_code == 404, f"Expected 404, got {response.status_code}"
        print("✓ Invalid tenant ID correctly rejected")


class TestTenantDataIsolation:
    """Test that tenant data is properly isolated"""
    
    @pytest.fixture
    def tenant_token(self):
        """Get tenant authentication token"""
        response = requests.post(
            f"{BASE_URL}/api/tenant/login",
            json={"username": TENANT_USERNAME, "password": TENANT_PASSWORD},
            headers={"X-Tenant-ID": EXISTING_TENANT_ID}
        )
        if response.status_code == 200:
            return response.json().get("token")
        pytest.skip("Tenant authentication failed")
    
    def test_accounts_with_tenant_header(self, tenant_token):
        """Test retrieving accounts with X-Tenant-ID header"""
        response = requests.get(
            f"{BASE_URL}/api/accounts",
            headers={
                "X-Tenant-ID": EXISTING_TENANT_ID,
                "Authorization": f"Bearer {tenant_token}"
            }
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        accounts = response.json()
        assert isinstance(accounts, list)
        assert len(accounts) > 0, "Tenant should have default chart of accounts"
        print(f"✓ Retrieved {len(accounts)} accounts for tenant {EXISTING_TENANT_ID}")
    
    def test_customers_with_tenant_header(self, tenant_token):
        """Test retrieving customers with X-Tenant-ID header"""
        response = requests.get(
            f"{BASE_URL}/api/customers",
            headers={
                "X-Tenant-ID": EXISTING_TENANT_ID,
                "Authorization": f"Bearer {tenant_token}"
            }
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        customers = response.json()
        assert isinstance(customers, list)
        print(f"✓ Retrieved {len(customers)} customers for tenant {EXISTING_TENANT_ID}")
    
    def test_journal_entries_with_tenant_header(self, tenant_token):
        """Test retrieving journal entries with X-Tenant-ID header"""
        response = requests.get(
            f"{BASE_URL}/api/journal-entries",
            headers={
                "X-Tenant-ID": EXISTING_TENANT_ID,
                "Authorization": f"Bearer {tenant_token}"
            }
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        entries = response.json()
        assert isinstance(entries, list)
        print(f"✓ Retrieved {len(entries)} journal entries for tenant {EXISTING_TENANT_ID}")
    
    def test_invoices_with_tenant_header(self, tenant_token):
        """Test retrieving invoices with X-Tenant-ID header"""
        response = requests.get(
            f"{BASE_URL}/api/invoices",
            headers={
                "X-Tenant-ID": EXISTING_TENANT_ID,
                "Authorization": f"Bearer {tenant_token}"
            }
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        invoices = response.json()
        assert isinstance(invoices, list)
        print(f"✓ Retrieved {len(invoices)} invoices for tenant {EXISTING_TENANT_ID}")
    
    def test_receipt_vouchers_with_tenant_header(self, tenant_token):
        """Test retrieving receipt vouchers with X-Tenant-ID header"""
        response = requests.get(
            f"{BASE_URL}/api/receipt-vouchers",
            headers={
                "X-Tenant-ID": EXISTING_TENANT_ID,
                "Authorization": f"Bearer {tenant_token}"
            }
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        vouchers = response.json()
        assert isinstance(vouchers, list)
        print(f"✓ Retrieved {len(vouchers)} receipt vouchers for tenant {EXISTING_TENANT_ID}")
    
    def test_payment_vouchers_with_tenant_header(self, tenant_token):
        """Test retrieving payment vouchers with X-Tenant-ID header"""
        response = requests.get(
            f"{BASE_URL}/api/payment-vouchers",
            headers={
                "X-Tenant-ID": EXISTING_TENANT_ID,
                "Authorization": f"Bearer {tenant_token}"
            }
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        vouchers = response.json()
        assert isinstance(vouchers, list)
        print(f"✓ Retrieved {len(vouchers)} payment vouchers for tenant {EXISTING_TENANT_ID}")
    
    def test_trial_balance_with_tenant_header(self, tenant_token):
        """Test retrieving trial balance with X-Tenant-ID header"""
        response = requests.get(
            f"{BASE_URL}/api/reports/trial-balance",
            headers={
                "X-Tenant-ID": EXISTING_TENANT_ID,
                "Authorization": f"Bearer {tenant_token}"
            }
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        report = response.json()
        assert "trial_balance" in report
        assert "fiscal_year" in report
        print(f"✓ Retrieved trial balance for tenant {EXISTING_TENANT_ID}")


class TestDataIsolationBetweenTenants:
    """Test that data is properly isolated between different tenants"""
    
    def test_different_tenants_have_different_data(self):
        """Verify that different tenants have isolated databases"""
        # Get accounts for existing tenant (C447CEF2 - created with multi-tenant feature)
        response1 = requests.get(
            f"{BASE_URL}/api/accounts",
            headers={"X-Tenant-ID": EXISTING_TENANT_ID}
        )
        assert response1.status_code == 200
        accounts1 = response1.json()
        
        # Get accounts without tenant header (main database)
        response2 = requests.get(f"{BASE_URL}/api/accounts")
        assert response2.status_code == 200
        accounts2 = response2.json()
        
        # Both should have accounts
        assert len(accounts1) > 0, "Tenant should have accounts"
        assert len(accounts2) > 0, "Main database should have accounts"
        print(f"✓ Tenant {EXISTING_TENANT_ID} has {len(accounts1)} accounts")
        print(f"✓ Main database has {len(accounts2)} accounts")
        print("✓ Data isolation verified - tenant and main DB are separate")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
