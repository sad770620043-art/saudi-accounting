# Saudi Accounting System Backend Tests
# Tests for: Authentication, Chart of Accounts, Journal Entries, Receipt/Payment Vouchers, Invoices

import pytest
import requests
import os
import random
import string

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'https://saudi-ledger.preview.emergentagent.com')

def generate_unique_id():
    """Generate unique ID for test data"""
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

class TestAuthentication:
    """Authentication endpoint tests"""
    
    def test_login_success(self):
        """Test login with valid credentials admin/admin123"""
        response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        assert response.status_code == 200, f"Login failed: {response.text}"
        data = response.json()
        assert "token" in data, "Token not in response"
        assert data["username"] == "admin"
        assert "full_name" in data
        print(f"✓ Login successful - username: {data['username']}")
    
    def test_login_invalid_credentials(self):
        """Test login with invalid credentials"""
        response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "username": "wrong_user",
            "password": "wrong_pass"
        })
        assert response.status_code == 401, f"Expected 401, got {response.status_code}"
        print("✓ Invalid credentials correctly rejected")


class TestChartOfAccounts:
    """Chart of Accounts tests - Saudi Unified Chart (95 accounts)"""
    
    def test_get_accounts(self):
        """Test getting all accounts - should have 95 accounts"""
        response = requests.get(f"{BASE_URL}/api/accounts")
        assert response.status_code == 200, f"Failed to get accounts: {response.text}"
        accounts = response.json()
        assert isinstance(accounts, list)
        assert len(accounts) >= 95, f"Expected at least 95 accounts, got {len(accounts)}"
        print(f"✓ Retrieved {len(accounts)} accounts")
        
        # Verify account structure
        if accounts:
            acc = accounts[0]
            assert "account_code" in acc
            assert "account_name_ar" in acc
            assert "account_name_en" in acc
            assert "account_type" in acc
            print(f"✓ Account structure verified")
    
    def test_account_types_exist(self):
        """Verify all account types exist: asset, liability, equity, revenue, expense"""
        response = requests.get(f"{BASE_URL}/api/accounts")
        assert response.status_code == 200
        accounts = response.json()
        
        account_types = set(acc["account_type"] for acc in accounts)
        expected_types = {"asset", "liability", "equity", "revenue", "expense"}
        
        for expected in expected_types:
            assert expected in account_types, f"Missing account type: {expected}"
        print(f"✓ All account types present: {account_types}")


class TestCustomers:
    """Customer CRUD tests"""
    
    def test_create_and_get_customer(self):
        """Test creating a customer and retrieving it"""
        unique_id = generate_unique_id()
        customer_data = {
            "customer_code": f"TEST_CUST_{unique_id}",
            "customer_name": f"Test Customer {unique_id}",
            "phone": "0501234567",
            "email": f"test_{unique_id}@example.com",
            "address": "Test Address",
            "is_active": True
        }
        
        # Create customer
        response = requests.post(f"{BASE_URL}/api/customers", json=customer_data)
        assert response.status_code == 200, f"Failed to create customer: {response.text}"
        created = response.json()
        assert created["customer_code"] == customer_data["customer_code"]
        print(f"✓ Customer created: {customer_data['customer_code']}")
        
        # Get all customers and verify
        response = requests.get(f"{BASE_URL}/api/customers")
        assert response.status_code == 200
        customers = response.json()
        customer_codes = [c["customer_code"] for c in customers]
        assert customer_data["customer_code"] in customer_codes
        print(f"✓ Customer verified in list")
        
        # Cleanup
        requests.delete(f"{BASE_URL}/api/customers/{customer_data['customer_code']}")


class TestJournalEntries:
    """Journal Entry tests"""
    
    def test_create_journal_entry(self):
        """Test creating a balanced journal entry"""
        unique_id = generate_unique_id()
        entry_data = {
            "entry_number": f"TEST_JE_{unique_id}",
            "entry_date": "2026-01-15T00:00:00Z",
            "description": f"Test Journal Entry {unique_id}",
            "lines": [
                {"account_code": "11110", "description": "Cash debit", "debit": 1000.00, "credit": 0},
                {"account_code": "41100", "description": "Sales credit", "debit": 0, "credit": 1000.00}
            ],
            "total_debit": 1000.00,
            "total_credit": 1000.00
        }
        
        response = requests.post(f"{BASE_URL}/api/journal-entries", json=entry_data)
        assert response.status_code == 200, f"Failed to create journal entry: {response.text}"
        created = response.json()
        assert created["entry_number"] == entry_data["entry_number"]
        assert created["total_debit"] == 1000.00
        assert created["total_credit"] == 1000.00
        print(f"✓ Journal entry created: {entry_data['entry_number']}")
    
    def test_get_journal_entries(self):
        """Test getting all journal entries"""
        response = requests.get(f"{BASE_URL}/api/journal-entries")
        assert response.status_code == 200, f"Failed to get journal entries: {response.text}"
        entries = response.json()
        assert isinstance(entries, list)
        print(f"✓ Retrieved {len(entries)} journal entries")
    
    def test_unbalanced_entry_rejected(self):
        """Test that unbalanced entries are rejected"""
        unique_id = generate_unique_id()
        entry_data = {
            "entry_number": f"TEST_UNBAL_{unique_id}",
            "entry_date": "2026-01-15T00:00:00Z",
            "description": "Unbalanced entry",
            "lines": [
                {"account_code": "11110", "description": "Cash", "debit": 1000.00, "credit": 0},
                {"account_code": "41100", "description": "Sales", "debit": 0, "credit": 500.00}
            ],
            "total_debit": 1000.00,
            "total_credit": 500.00
        }
        
        response = requests.post(f"{BASE_URL}/api/journal-entries", json=entry_data)
        assert response.status_code == 400, f"Expected 400 for unbalanced entry, got {response.status_code}"
        print("✓ Unbalanced entry correctly rejected")


class TestReceiptVouchers:
    """Receipt Voucher tests"""
    
    def test_create_receipt_voucher(self):
        """Test creating a receipt voucher"""
        unique_id = generate_unique_id()
        voucher_data = {
            "voucher_number": f"TEST_RV_{unique_id}",
            "voucher_date": "2026-01-15T00:00:00Z",
            "customer_code": "",
            "received_from": f"Test Customer {unique_id}",
            "amount": 5000.00,
            "payment_method": "cash",
            "account_code": "11110",
            "description": f"Test receipt {unique_id}"
        }
        
        response = requests.post(f"{BASE_URL}/api/receipt-vouchers", json=voucher_data)
        assert response.status_code == 200, f"Failed to create receipt voucher: {response.text}"
        created = response.json()
        assert created["voucher_number"] == voucher_data["voucher_number"]
        assert created["amount"] == 5000.00
        print(f"✓ Receipt voucher created: {voucher_data['voucher_number']}")
    
    def test_get_receipt_vouchers(self):
        """Test getting all receipt vouchers"""
        response = requests.get(f"{BASE_URL}/api/receipt-vouchers")
        assert response.status_code == 200, f"Failed to get receipt vouchers: {response.text}"
        vouchers = response.json()
        assert isinstance(vouchers, list)
        print(f"✓ Retrieved {len(vouchers)} receipt vouchers")


class TestPaymentVouchers:
    """Payment Voucher tests"""
    
    def test_create_payment_voucher(self):
        """Test creating a payment voucher"""
        unique_id = generate_unique_id()
        voucher_data = {
            "voucher_number": f"TEST_PV_{unique_id}",
            "voucher_date": "2026-01-15T00:00:00Z",
            "paid_to": f"Test Supplier {unique_id}",
            "amount": 3000.00,
            "payment_method": "bank_transfer",
            "account_code": "11120",
            "description": f"Test payment {unique_id}"
        }
        
        response = requests.post(f"{BASE_URL}/api/payment-vouchers", json=voucher_data)
        assert response.status_code == 200, f"Failed to create payment voucher: {response.text}"
        created = response.json()
        assert created["voucher_number"] == voucher_data["voucher_number"]
        assert created["amount"] == 3000.00
        print(f"✓ Payment voucher created: {voucher_data['voucher_number']}")
    
    def test_get_payment_vouchers(self):
        """Test getting all payment vouchers"""
        response = requests.get(f"{BASE_URL}/api/payment-vouchers")
        assert response.status_code == 200, f"Failed to get payment vouchers: {response.text}"
        vouchers = response.json()
        assert isinstance(vouchers, list)
        print(f"✓ Retrieved {len(vouchers)} payment vouchers")


class TestInvoices:
    """Invoice tests"""
    
    def test_create_invoice(self):
        """Test creating an invoice with VAT"""
        unique_id = generate_unique_id()
        
        # First create a customer
        customer_code = f"TEST_INV_CUST_{unique_id}"
        customer_data = {
            "customer_code": customer_code,
            "customer_name": f"Invoice Test Customer {unique_id}",
            "phone": "0501234567",
            "is_active": True
        }
        requests.post(f"{BASE_URL}/api/customers", json=customer_data)
        
        # Create invoice
        invoice_data = {
            "invoice_number": f"TEST_INV_{unique_id}",
            "invoice_date": "2026-01-15T00:00:00Z",
            "customer_code": customer_code,
            "items": [
                {"description": "Product A", "quantity": 2, "unit_price": 100.00, "total": 200.00},
                {"description": "Product B", "quantity": 1, "unit_price": 300.00, "total": 300.00}
            ],
            "subtotal": 500.00,
            "vat_rate": 15.0,
            "vat_amount": 75.00,
            "total_amount": 575.00,
            "notes": "Test invoice"
        }
        
        response = requests.post(f"{BASE_URL}/api/invoices", json=invoice_data)
        assert response.status_code == 200, f"Failed to create invoice: {response.text}"
        created = response.json()
        assert created["invoice_number"] == invoice_data["invoice_number"]
        assert created["total_amount"] == 575.00
        assert created["vat_rate"] == 15.0
        print(f"✓ Invoice created: {invoice_data['invoice_number']} with VAT 15%")
        
        # Cleanup
        requests.delete(f"{BASE_URL}/api/customers/{customer_code}")
    
    def test_get_invoices(self):
        """Test getting all invoices"""
        response = requests.get(f"{BASE_URL}/api/invoices")
        assert response.status_code == 200, f"Failed to get invoices: {response.text}"
        invoices = response.json()
        assert isinstance(invoices, list)
        print(f"✓ Retrieved {len(invoices)} invoices")


class TestReports:
    """Report generation tests"""
    
    def test_trial_balance(self):
        """Test trial balance report"""
        response = requests.get(f"{BASE_URL}/api/reports/trial-balance")
        assert response.status_code == 200, f"Failed to get trial balance: {response.text}"
        data = response.json()
        assert "trial_balance" in data
        assert "total_debit" in data
        assert "total_credit" in data
        print(f"✓ Trial balance retrieved - Debit: {data['total_debit']}, Credit: {data['total_credit']}")
    
    def test_dashboard_stats(self):
        """Test dashboard statistics"""
        response = requests.get(f"{BASE_URL}/api/dashboard/stats")
        assert response.status_code == 200, f"Failed to get dashboard stats: {response.text}"
        data = response.json()
        assert "total_accounts" in data
        assert "total_customers" in data
        assert "total_invoices" in data
        print(f"✓ Dashboard stats - Accounts: {data['total_accounts']}, Customers: {data['total_customers']}")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
