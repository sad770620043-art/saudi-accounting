"""
Test suite for new features:
1. License Alerts API (GET /api/super-admin/license-alerts)
2. Cost Centers CRUD (GET/POST/PUT/DELETE /api/cost-centers)
3. Projects CRUD (GET/POST/PUT/DELETE /api/projects)
4. Reports by Cost Center (GET /api/reports/by-cost-center)
5. Reports by Project (GET /api/reports/by-project)
"""

import pytest
import requests
import os
from datetime import datetime, timedelta

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

# Test data prefixes for cleanup
TEST_PREFIX = "TEST_"


class TestLicenseAlerts:
    """Test license alerts endpoint for Owner Panel"""
    
    def test_license_alerts_endpoint_returns_200(self):
        """GET /api/super-admin/license-alerts should return 200"""
        response = requests.get(f"{BASE_URL}/api/super-admin/license-alerts")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        print("PASS: License alerts endpoint returns 200")
    
    def test_license_alerts_response_structure(self):
        """License alerts response should have correct structure"""
        response = requests.get(f"{BASE_URL}/api/super-admin/license-alerts")
        assert response.status_code == 200
        
        data = response.json()
        assert "total_alerts" in data, "Missing total_alerts field"
        assert "critical" in data, "Missing critical count"
        assert "high" in data, "Missing high count"
        assert "medium" in data, "Missing medium count"
        assert "alerts" in data, "Missing alerts array"
        assert isinstance(data["alerts"], list), "alerts should be a list"
        print(f"PASS: License alerts structure correct - {data['total_alerts']} total alerts")
    
    def test_license_alerts_severity_levels(self):
        """Alerts should have correct severity levels"""
        response = requests.get(f"{BASE_URL}/api/super-admin/license-alerts")
        assert response.status_code == 200
        
        data = response.json()
        for alert in data["alerts"]:
            assert "severity" in alert, "Alert missing severity"
            assert alert["severity"] in ["critical", "high", "medium"], f"Invalid severity: {alert['severity']}"
            assert "tenant_id" in alert, "Alert missing tenant_id"
            assert "company_name_ar" in alert, "Alert missing company_name_ar"
            assert "days_remaining" in alert, "Alert missing days_remaining"
            assert "message_ar" in alert, "Alert missing message_ar"
        print(f"PASS: All {len(data['alerts'])} alerts have correct severity levels")


class TestCostCentersCRUD:
    """Test Cost Centers CRUD operations"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Setup test data"""
        self.test_center = {
            "center_code": f"{TEST_PREFIX}CC001",
            "center_name_ar": "مركز تكلفة اختباري",
            "center_name_en": "Test Cost Center",
            "parent_code": "",
            "description": "Test description",
            "is_active": True
        }
    
    def test_get_cost_centers_returns_200(self):
        """GET /api/cost-centers should return 200"""
        response = requests.get(f"{BASE_URL}/api/cost-centers")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        assert isinstance(response.json(), list), "Response should be a list"
        print(f"PASS: GET cost-centers returns 200 with {len(response.json())} centers")
    
    def test_create_cost_center(self):
        """POST /api/cost-centers should create a new cost center"""
        # First delete if exists
        requests.delete(f"{BASE_URL}/api/cost-centers/{self.test_center['center_code']}")
        
        response = requests.post(f"{BASE_URL}/api/cost-centers", json=self.test_center)
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        
        data = response.json()
        assert "message" in data or "center_code" in data, "Response should contain message or center_code"
        print(f"PASS: Created cost center {self.test_center['center_code']}")
    
    def test_create_duplicate_cost_center_fails(self):
        """POST /api/cost-centers with duplicate code should fail"""
        # Ensure center exists
        requests.post(f"{BASE_URL}/api/cost-centers", json=self.test_center)
        
        # Try to create duplicate
        response = requests.post(f"{BASE_URL}/api/cost-centers", json=self.test_center)
        assert response.status_code == 400, f"Expected 400 for duplicate, got {response.status_code}"
        print("PASS: Duplicate cost center creation rejected")
    
    def test_update_cost_center(self):
        """PUT /api/cost-centers/{code} should update the cost center"""
        # Ensure center exists
        requests.delete(f"{BASE_URL}/api/cost-centers/{self.test_center['center_code']}")
        requests.post(f"{BASE_URL}/api/cost-centers", json=self.test_center)
        
        # Update
        updated_center = self.test_center.copy()
        updated_center["center_name_ar"] = "مركز تكلفة محدث"
        updated_center["description"] = "Updated description"
        
        response = requests.put(
            f"{BASE_URL}/api/cost-centers/{self.test_center['center_code']}", 
            json=updated_center
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        print("PASS: Cost center updated successfully")
    
    def test_delete_cost_center(self):
        """DELETE /api/cost-centers/{code} should delete the cost center"""
        # Ensure center exists
        requests.post(f"{BASE_URL}/api/cost-centers", json=self.test_center)
        
        response = requests.delete(f"{BASE_URL}/api/cost-centers/{self.test_center['center_code']}")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        # Verify deletion
        get_response = requests.get(f"{BASE_URL}/api/cost-centers")
        centers = get_response.json()
        codes = [c['center_code'] for c in centers]
        assert self.test_center['center_code'] not in codes, "Center should be deleted"
        print("PASS: Cost center deleted successfully")


class TestProjectsCRUD:
    """Test Projects CRUD operations"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Setup test data"""
        self.test_project = {
            "project_code": f"{TEST_PREFIX}PRJ001",
            "project_name_ar": "مشروع اختباري",
            "project_name_en": "Test Project",
            "client_name": "Test Client",
            "start_date": "2025-01-01",
            "end_date": "2025-12-31",
            "budget": 100000.0,
            "status": "active",
            "description": "Test project description",
            "is_active": True
        }
    
    def test_get_projects_returns_200(self):
        """GET /api/projects should return 200"""
        response = requests.get(f"{BASE_URL}/api/projects")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        assert isinstance(response.json(), list), "Response should be a list"
        print(f"PASS: GET projects returns 200 with {len(response.json())} projects")
    
    def test_create_project(self):
        """POST /api/projects should create a new project"""
        # First delete if exists
        requests.delete(f"{BASE_URL}/api/projects/{self.test_project['project_code']}")
        
        response = requests.post(f"{BASE_URL}/api/projects", json=self.test_project)
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        
        data = response.json()
        assert "message" in data or "project_code" in data, "Response should contain message or project_code"
        print(f"PASS: Created project {self.test_project['project_code']}")
    
    def test_create_duplicate_project_fails(self):
        """POST /api/projects with duplicate code should fail"""
        # Ensure project exists
        requests.post(f"{BASE_URL}/api/projects", json=self.test_project)
        
        # Try to create duplicate
        response = requests.post(f"{BASE_URL}/api/projects", json=self.test_project)
        assert response.status_code == 400, f"Expected 400 for duplicate, got {response.status_code}"
        print("PASS: Duplicate project creation rejected")
    
    def test_update_project(self):
        """PUT /api/projects/{code} should update the project"""
        # Ensure project exists
        requests.delete(f"{BASE_URL}/api/projects/{self.test_project['project_code']}")
        requests.post(f"{BASE_URL}/api/projects", json=self.test_project)
        
        # Update
        updated_project = self.test_project.copy()
        updated_project["project_name_ar"] = "مشروع محدث"
        updated_project["budget"] = 150000.0
        updated_project["status"] = "completed"
        
        response = requests.put(
            f"{BASE_URL}/api/projects/{self.test_project['project_code']}", 
            json=updated_project
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        print("PASS: Project updated successfully")
    
    def test_delete_project(self):
        """DELETE /api/projects/{code} should delete the project"""
        # Ensure project exists
        requests.post(f"{BASE_URL}/api/projects", json=self.test_project)
        
        response = requests.delete(f"{BASE_URL}/api/projects/{self.test_project['project_code']}")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        # Verify deletion
        get_response = requests.get(f"{BASE_URL}/api/projects")
        projects = get_response.json()
        codes = [p['project_code'] for p in projects]
        assert self.test_project['project_code'] not in codes, "Project should be deleted"
        print("PASS: Project deleted successfully")
    
    def test_project_status_values(self):
        """Projects should support different status values"""
        statuses = ["active", "completed", "on_hold", "cancelled"]
        
        for status in statuses:
            project = self.test_project.copy()
            project["project_code"] = f"{TEST_PREFIX}PRJ_{status}"
            project["status"] = status
            
            # Delete if exists
            requests.delete(f"{BASE_URL}/api/projects/{project['project_code']}")
            
            response = requests.post(f"{BASE_URL}/api/projects", json=project)
            assert response.status_code == 200, f"Failed to create project with status {status}"
            
            # Cleanup
            requests.delete(f"{BASE_URL}/api/projects/{project['project_code']}")
        
        print("PASS: All project status values work correctly")


class TestReportsByCostCenter:
    """Test reports by cost center endpoint"""
    
    def test_reports_by_cost_center_returns_200(self):
        """GET /api/reports/by-cost-center should return 200"""
        response = requests.get(f"{BASE_URL}/api/reports/by-cost-center")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        assert isinstance(response.json(), list), "Response should be a list"
        print(f"PASS: Reports by cost center returns 200 with {len(response.json())} entries")
    
    def test_reports_by_cost_center_structure(self):
        """Reports by cost center should have correct structure"""
        # First create a cost center
        test_center = {
            "center_code": f"{TEST_PREFIX}CC_REPORT",
            "center_name_ar": "مركز تقرير",
            "center_name_en": "Report Center",
            "is_active": True
        }
        requests.delete(f"{BASE_URL}/api/cost-centers/{test_center['center_code']}")
        requests.post(f"{BASE_URL}/api/cost-centers", json=test_center)
        
        response = requests.get(f"{BASE_URL}/api/reports/by-cost-center")
        assert response.status_code == 200
        
        data = response.json()
        if len(data) > 0:
            entry = data[0]
            assert "center_code" in entry, "Missing center_code"
            assert "center_name_ar" in entry, "Missing center_name_ar"
            assert "total_debit" in entry, "Missing total_debit"
            assert "total_credit" in entry, "Missing total_credit"
            assert "net_amount" in entry, "Missing net_amount"
            print("PASS: Reports by cost center has correct structure")
        else:
            print("PASS: Reports by cost center returns empty list (no cost centers)")
        
        # Cleanup
        requests.delete(f"{BASE_URL}/api/cost-centers/{test_center['center_code']}")


class TestReportsByProject:
    """Test reports by project endpoint"""
    
    def test_reports_by_project_returns_200(self):
        """GET /api/reports/by-project should return 200"""
        response = requests.get(f"{BASE_URL}/api/reports/by-project")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        assert isinstance(response.json(), list), "Response should be a list"
        print(f"PASS: Reports by project returns 200 with {len(response.json())} entries")
    
    def test_reports_by_project_structure(self):
        """Reports by project should have correct structure"""
        # First create a project
        test_project = {
            "project_code": f"{TEST_PREFIX}PRJ_REPORT",
            "project_name_ar": "مشروع تقرير",
            "project_name_en": "Report Project",
            "budget": 50000.0,
            "status": "active",
            "is_active": True
        }
        requests.delete(f"{BASE_URL}/api/projects/{test_project['project_code']}")
        requests.post(f"{BASE_URL}/api/projects", json=test_project)
        
        response = requests.get(f"{BASE_URL}/api/reports/by-project")
        assert response.status_code == 200
        
        data = response.json()
        if len(data) > 0:
            entry = data[0]
            assert "project_code" in entry, "Missing project_code"
            assert "project_name_ar" in entry, "Missing project_name_ar"
            assert "total_debit" in entry, "Missing total_debit"
            assert "total_credit" in entry, "Missing total_credit"
            assert "net_amount" in entry, "Missing net_amount"
            assert "budget" in entry, "Missing budget"
            assert "budget_used_percent" in entry, "Missing budget_used_percent"
            print("PASS: Reports by project has correct structure")
        else:
            print("PASS: Reports by project returns empty list (no projects)")
        
        # Cleanup
        requests.delete(f"{BASE_URL}/api/projects/{test_project['project_code']}")


class TestCleanup:
    """Cleanup test data"""
    
    def test_cleanup_test_data(self):
        """Clean up all test data created during tests"""
        # Get all cost centers and delete test ones
        response = requests.get(f"{BASE_URL}/api/cost-centers")
        if response.status_code == 200:
            for center in response.json():
                if center['center_code'].startswith(TEST_PREFIX):
                    requests.delete(f"{BASE_URL}/api/cost-centers/{center['center_code']}")
        
        # Get all projects and delete test ones
        response = requests.get(f"{BASE_URL}/api/projects")
        if response.status_code == 200:
            for project in response.json():
                if project['project_code'].startswith(TEST_PREFIX):
                    requests.delete(f"{BASE_URL}/api/projects/{project['project_code']}")
        
        print("PASS: Test data cleanup completed")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
