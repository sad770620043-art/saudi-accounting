"""
Test cases for Quarterly Comparison and Historical Data features
Tests:
- GET /api/reports/quarterly/comparison - Returns comparison data for last 4 quarters
- GET /api/historical-data - Returns all saved historical data
- POST /api/historical-data - Saves year data with quarterly breakdown
- DELETE /api/historical-data/{year} - Deletes historical data
"""
import pytest
import requests
import os
from datetime import datetime

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

class TestQuarterlyComparisonEndpoint:
    """Tests for GET /api/reports/quarterly/comparison"""
    
    def test_comparison_returns_200(self):
        """Test that comparison endpoint returns 200 status"""
        response = requests.get(f"{BASE_URL}/api/reports/quarterly/comparison?year=2025&quarter=1")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        print("PASS: Comparison endpoint returns 200")
    
    def test_comparison_response_structure(self):
        """Test that comparison response has correct structure"""
        response = requests.get(f"{BASE_URL}/api/reports/quarterly/comparison?year=2025&quarter=1")
        data = response.json()
        
        # Check top-level structure
        assert "current_period" in data, "Missing current_period"
        assert "comparison" in data, "Missing comparison"
        
        # Check current_period structure
        assert "year" in data["current_period"], "Missing year in current_period"
        assert "quarter" in data["current_period"], "Missing quarter in current_period"
        
        # Check comparison is a list
        assert isinstance(data["comparison"], list), "comparison should be a list"
        print("PASS: Comparison response has correct structure")
    
    def test_comparison_returns_4_quarters(self):
        """Test that comparison returns data for 4 quarters"""
        response = requests.get(f"{BASE_URL}/api/reports/quarterly/comparison?year=2025&quarter=4")
        data = response.json()
        
        assert len(data["comparison"]) == 4, f"Expected 4 quarters, got {len(data['comparison'])}"
        print("PASS: Comparison returns 4 quarters")
    
    def test_comparison_quarter_structure(self):
        """Test that each quarter in comparison has correct fields"""
        response = requests.get(f"{BASE_URL}/api/reports/quarterly/comparison?year=2025&quarter=1")
        data = response.json()
        
        required_fields = ["year", "quarter", "label", "revenue", "expense", "net_profit", "is_current", "has_data"]
        
        for quarter in data["comparison"]:
            for field in required_fields:
                assert field in quarter, f"Missing field {field} in quarter data"
        print("PASS: Each quarter has correct fields")
    
    def test_comparison_current_quarter_marked(self):
        """Test that current quarter is correctly marked"""
        response = requests.get(f"{BASE_URL}/api/reports/quarterly/comparison?year=2025&quarter=2")
        data = response.json()
        
        current_quarters = [q for q in data["comparison"] if q["is_current"]]
        assert len(current_quarters) == 1, "Should have exactly one current quarter"
        assert current_quarters[0]["year"] == 2025, "Current quarter year should be 2025"
        assert current_quarters[0]["quarter"] == 2, "Current quarter should be Q2"
        print("PASS: Current quarter is correctly marked")
    
    def test_comparison_chronological_order(self):
        """Test that quarters are in chronological order"""
        response = requests.get(f"{BASE_URL}/api/reports/quarterly/comparison?year=2025&quarter=4")
        data = response.json()
        
        # Check that quarters are in ascending order
        for i in range(len(data["comparison"]) - 1):
            current = data["comparison"][i]
            next_q = data["comparison"][i + 1]
            current_date = current["year"] * 4 + current["quarter"]
            next_date = next_q["year"] * 4 + next_q["quarter"]
            assert current_date < next_date, "Quarters should be in chronological order"
        print("PASS: Quarters are in chronological order")
    
    def test_comparison_growth_rates_on_current(self):
        """Test that growth rates are calculated for current quarter"""
        response = requests.get(f"{BASE_URL}/api/reports/quarterly/comparison?year=2025&quarter=4")
        data = response.json()
        
        current_quarter = [q for q in data["comparison"] if q["is_current"]][0]
        
        # Growth rates should be present on current quarter
        assert "revenue_growth" in current_quarter, "Missing revenue_growth on current quarter"
        assert "expense_growth" in current_quarter, "Missing expense_growth on current quarter"
        print("PASS: Growth rates calculated for current quarter")
    
    def test_comparison_different_years(self):
        """Test comparison works for different years"""
        for year in [2024, 2025, 2026]:
            response = requests.get(f"{BASE_URL}/api/reports/quarterly/comparison?year={year}&quarter=1")
            assert response.status_code == 200, f"Failed for year {year}"
            data = response.json()
            assert data["current_period"]["year"] == year
        print("PASS: Comparison works for different years")


class TestHistoricalDataEndpoints:
    """Tests for historical data CRUD operations"""
    
    @pytest.fixture(autouse=True)
    def cleanup(self):
        """Cleanup test data after each test"""
        yield
        # Delete test data
        requests.delete(f"{BASE_URL}/api/historical-data/2023")
        requests.delete(f"{BASE_URL}/api/historical-data/2022")
    
    def test_get_historical_data_returns_200(self):
        """Test that GET historical-data returns 200"""
        response = requests.get(f"{BASE_URL}/api/historical-data")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        print("PASS: GET historical-data returns 200")
    
    def test_get_historical_data_returns_list(self):
        """Test that GET historical-data returns a list"""
        response = requests.get(f"{BASE_URL}/api/historical-data")
        data = response.json()
        assert isinstance(data, list), "Response should be a list"
        print("PASS: GET historical-data returns a list")
    
    def test_post_historical_data_creates_record(self):
        """Test that POST historical-data creates a new record"""
        test_data = {
            "year": 2023,
            "total_revenue": 300000,
            "total_expense": 200000,
            "closing_cash_balance": 50000,
            "closing_bank_balance": 100000,
            "notes": "Test data for 2023",
            "q1_revenue": 70000, "q1_expense": 45000,
            "q2_revenue": 75000, "q2_expense": 50000,
            "q3_revenue": 80000, "q3_expense": 55000,
            "q4_revenue": 75000, "q4_expense": 50000
        }
        
        response = requests.post(f"{BASE_URL}/api/historical-data", json=test_data)
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert "message" in data, "Response should have message"
        assert data["year"] == 2023, "Year should be 2023"
        print("PASS: POST historical-data creates record")
    
    def test_post_historical_data_calculates_net_profit(self):
        """Test that POST historical-data calculates net profit"""
        test_data = {
            "year": 2022,
            "total_revenue": 250000,
            "total_expense": 180000
        }
        
        response = requests.post(f"{BASE_URL}/api/historical-data", json=test_data)
        assert response.status_code == 200
        
        # Verify net profit was calculated
        get_response = requests.get(f"{BASE_URL}/api/historical-data")
        data = get_response.json()
        year_2022 = next((d for d in data if d["year"] == 2022), None)
        
        assert year_2022 is not None, "Year 2022 data should exist"
        assert year_2022["net_profit"] == 70000, f"Net profit should be 70000, got {year_2022['net_profit']}"
        print("PASS: POST historical-data calculates net profit")
    
    def test_post_historical_data_upserts(self):
        """Test that POST historical-data updates existing record"""
        # Create initial record
        test_data = {
            "year": 2023,
            "total_revenue": 300000,
            "total_expense": 200000
        }
        requests.post(f"{BASE_URL}/api/historical-data", json=test_data)
        
        # Update the record
        updated_data = {
            "year": 2023,
            "total_revenue": 350000,
            "total_expense": 220000
        }
        response = requests.post(f"{BASE_URL}/api/historical-data", json=updated_data)
        assert response.status_code == 200
        
        # Verify update
        get_response = requests.get(f"{BASE_URL}/api/historical-data")
        data = get_response.json()
        year_2023 = next((d for d in data if d["year"] == 2023), None)
        
        assert year_2023["total_revenue"] == 350000, "Revenue should be updated"
        assert year_2023["total_expense"] == 220000, "Expense should be updated"
        print("PASS: POST historical-data upserts existing record")
    
    def test_delete_historical_data_removes_record(self):
        """Test that DELETE historical-data removes record"""
        # Create a record first
        test_data = {"year": 2023, "total_revenue": 100000, "total_expense": 80000}
        requests.post(f"{BASE_URL}/api/historical-data", json=test_data)
        
        # Delete the record
        response = requests.delete(f"{BASE_URL}/api/historical-data/2023")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        # Verify deletion
        get_response = requests.get(f"{BASE_URL}/api/historical-data")
        data = get_response.json()
        year_2023 = next((d for d in data if d["year"] == 2023), None)
        
        assert year_2023 is None, "Year 2023 should be deleted"
        print("PASS: DELETE historical-data removes record")
    
    def test_delete_nonexistent_returns_404(self):
        """Test that DELETE nonexistent year returns 404"""
        response = requests.delete(f"{BASE_URL}/api/historical-data/1999")
        assert response.status_code == 404, f"Expected 404, got {response.status_code}"
        print("PASS: DELETE nonexistent year returns 404")


class TestHistoricalDataInComparison:
    """Tests for historical data integration with comparison"""
    
    @pytest.fixture(autouse=True)
    def setup_and_cleanup(self):
        """Setup test data and cleanup after"""
        # Create test historical data
        test_data = {
            "year": 2024,
            "total_revenue": 400000,
            "total_expense": 280000,
            "q1_revenue": 80000, "q1_expense": 55000,
            "q2_revenue": 95000, "q2_expense": 65000,
            "q3_revenue": 110000, "q3_expense": 75000,
            "q4_revenue": 115000, "q4_expense": 85000,
            "notes": "Test data for comparison"
        }
        requests.post(f"{BASE_URL}/api/historical-data", json=test_data)
        yield
        # Cleanup
        requests.delete(f"{BASE_URL}/api/historical-data/2024")
    
    def test_comparison_uses_historical_data(self):
        """Test that comparison uses historical data when no journal entries exist"""
        response = requests.get(f"{BASE_URL}/api/reports/quarterly/comparison?year=2025&quarter=1")
        data = response.json()
        
        # Find Q4 2024 in comparison
        q4_2024 = next((q for q in data["comparison"] if q["year"] == 2024 and q["quarter"] == 4), None)
        
        assert q4_2024 is not None, "Q4 2024 should be in comparison"
        assert q4_2024["has_data"] == True, "Q4 2024 should have data from historical"
        assert q4_2024["revenue"] == 115000, f"Q4 2024 revenue should be 115000, got {q4_2024['revenue']}"
        assert q4_2024["expense"] == 85000, f"Q4 2024 expense should be 85000, got {q4_2024['expense']}"
        print("PASS: Comparison uses historical data")
    
    def test_comparison_shows_has_data_flag(self):
        """Test that comparison correctly shows has_data flag"""
        response = requests.get(f"{BASE_URL}/api/reports/quarterly/comparison?year=2025&quarter=1")
        data = response.json()
        
        for quarter in data["comparison"]:
            if quarter["revenue"] > 0 or quarter["expense"] > 0:
                assert quarter["has_data"] == True, f"Quarter with data should have has_data=True"
            else:
                assert quarter["has_data"] == False, f"Quarter without data should have has_data=False"
        print("PASS: has_data flag is correct")


class TestHistoricalDataStructure:
    """Tests for historical data response structure"""
    
    def test_historical_data_has_required_fields(self):
        """Test that historical data records have all required fields"""
        response = requests.get(f"{BASE_URL}/api/historical-data")
        data = response.json()
        
        if len(data) > 0:
            required_fields = [
                "year", "total_revenue", "total_expense", "net_profit",
                "closing_cash_balance", "closing_bank_balance", "notes",
                "q1_revenue", "q1_expense", "q2_revenue", "q2_expense",
                "q3_revenue", "q3_expense", "q4_revenue", "q4_expense"
            ]
            
            for record in data:
                for field in required_fields:
                    assert field in record, f"Missing field {field} in historical data"
            print("PASS: Historical data has all required fields")
        else:
            print("SKIP: No historical data to verify structure")
    
    def test_historical_data_sorted_by_year_desc(self):
        """Test that historical data is sorted by year descending"""
        response = requests.get(f"{BASE_URL}/api/historical-data")
        data = response.json()
        
        if len(data) > 1:
            for i in range(len(data) - 1):
                assert data[i]["year"] >= data[i + 1]["year"], "Data should be sorted by year descending"
            print("PASS: Historical data sorted by year descending")
        else:
            print("SKIP: Not enough data to verify sorting")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
